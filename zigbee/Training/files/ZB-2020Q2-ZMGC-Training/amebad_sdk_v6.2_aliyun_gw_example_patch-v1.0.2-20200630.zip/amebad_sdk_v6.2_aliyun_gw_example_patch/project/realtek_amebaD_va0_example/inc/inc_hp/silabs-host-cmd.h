/***************************************************************************//**
 * @file silabs-host-cmd.h
 * @brief host command definition for gateway interface
 *******************************************************************************
 * # License
 * <b>Copyright 2019 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#ifndef __Z3_GW_HOST_CMD_H__
#define __Z3_GW_HOST_CMD_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

/*******************************************************************************
 * Miscellaneous definitions.
 *******************************************************************************/
#define MAX_EUI64_LEN           (8)
#define MAX_ZCL_DATA_SIZE       (255)
#define MAX_LOG_BUFFER_SIZE     (255)
#define MAX_LINK_KEY_SIZE       (16)
#define MAX_CLUSTERS_SIZE       (20)
#define MAX_ENDPOINTS_SIZE      (10)
#define MAX_OCTET_STRING_SIZE   (8)

#define GW_UP_QUEUE_NAME        "up_queue"
#define GW_DOWN_QUEUE_NAME      "down_queue"
#define NCP_STACK_VERSION       "6.6.5\0"

#ifndef BOOL
  #define BOOL                  uint8_t
#endif
#ifndef NULL
  #define NULL                  (0)
#endif
#ifndef BASE_TYPE
  #define BASE_TYPE             uint32_t
#endif

#define OS_ABS_HANDLE           uint16_t
#define INVALID_OS_ABS_HANDLE   (0xFFFF)
#define NULL_MANUFACTURER_CODE  (0x0000)

/*******************************************************************************
 * flash space allocation definition, the following settings are based on a 
 * 4M ext-flash and the host firmware size is smaller than 0x180000
 *******************************************************************************/
#define FLASH_ADDR_OTA_IMAGE_START        0x180000
#define FLASH_OTA_IMAGE_SIZE              0x80000
#define FLASH_OTA_IMAGE_NUMBER            1
#define FLASH_ADDR_NCP_IMAGE_START        0x380000
#define FLASH_NCP_IMAGE_SIZE              0x80000
#define FLASH_ADDR_DEVICE_TABLE_START     0x200000
#define FLASH_DEVICE_TABLE_SIZE           0x1000 
#define FLASH_ADDR_IAS_ZONE_START         (FLASH_ADDR_DEVICE_TABLE_START + FLASH_DEVICE_TABLE_SIZE)
#define FLASH_ADDR_IAS_ZONE_SIZE          0x1000 

/*******************************************************************************
 * ID definitions for top-down and bottom-up messages.
 *******************************************************************************/
/*
 * @brief Message IDs from connectivity layer to ZNet stack.
 * 
 * Each command ID should be associated with a data type, except the following has a NULL type:
 * - LEAVE_NWK. Relate to EmberAPI <tt>network leave</tt>.
 * - CLOSE_JOIN. Relate to EmberAPI <tt>plugin network-creator-security close-network</tt>.
 * - DEV_INFO_QUERY. Gateway local operation.
 * - GET_NWK. Get nerwork status.
 * - OTA_FILE_RELOAD reload the server after new file(s) is(are) added to ota-file directory. 
 */
typedef enum {
  CREATE_NWK,             ///< Cordinator creates a network.
  LEAVE_NWK,              ///< Cordinator leaves the network.
  GET_NWK,                ///< get newtork status and network settings.
  OPEN_JOIN,              ///< Start joining. Type of joining is specified in #OpenJoin_t::joinType.
  CLOSE_JOIN,             ///< Stop joining.
  DEV_LEAVE_NWK,          ///< Force a device leaving a network.
  DEV_TABLE_DEL,          ///< manually delete an entry from the device table.
  DEV_DISC,               ///< Force conducting device discovery if related dev-info (incl. endpoints and firmware versions) is missing.
  SET_ASSN,               ///< Set association before attribute-reading/reporting.
  SET_REPORT,             ///< Set attribute-reporting conditions.
  CLR_ASSN,               ///< Clear association.
  ATTR_WRITE,             ///< Write an attribute value.
  ATTR_READ,              ///< Read an attribute value.
  CMD_CTRL,               ///< Control an attribute based on ZCL cluster commands.
  ZCL_SEND,               ///< Send message with raw ZCL message.
  DEV_INFO_QUERY,         ///< Query info of joined devices. Could end up with a stream of #DevInfo_t messages.
  OTA_IMAGE_NOTIFY,       ///< Notify an end device about the current image file.
  OTA_FILE_RELOAD,        ///< reload the server after new file(s) is(are) added to ota-file directory.
  NCP_UPDATE,             ///< update NCP with a gbl file. 
  ENBALE_PRINTOUT_LOG,    ///< enable/disable sending printout messages upward
  MISC_MGMT_CMD_MAX,      ///< Sanity check.
} TopDownMsgId_t;

/*
 * @brief Message IDs from ZNet stack to connectivity layer. Each command ID should be 
 * associated with a data type.
 */
typedef enum {
  NWK_SETTINGS, 
  NWK_STATUS,
  DEV_JOINED,
  DEV_LEFT,
  DEV_DISC_RET,           ///< Return value for #DEV_DISC.
  DEV_STATUS_CHANGED,
  OPS_RSP,                ///< Responses for ctrl/setting operations.
  ATTR_MSG,               ///< Attribute value for reading or reporting.
  DEV_INFO,               ///< Could be unsolicated messages when bootup, or triggered by #DEV_DB_QUERY.
  CMD_RECV,               ///< Get ZCL cluster commands from end device associated to the gateway.
  ZCL_MSG,                ///< Get ZCL packet to the gateway
  SET_ASSN_RSP,           ///< Respnse message for SET_ASSN
  SET_REPORT_RSP,         ///< Response message for SET_REPORT
  IAS_ZONE_DISC,          ///< ias zone server device discovered
  OTA_STATUS,             ///< ota status report message
  NCP_UPDATE_RSP,         ///< update NCP response. 
  NCP_RESET_STATUS,       ///< will return ncp status everytime ncp is reset.
  PRINTOUT_LOG,           ///< divert the gateway app printout messages upward
  BOTTOM_UP_RSP_MAX,      ///< Sanity check.
} BottomUpMsgId_t;

/*******************************************************************************
 * Message structure passed via message queues.
 *******************************************************************************/
/*
 * @brief Message structure used in the top-down message queue.
 */
typedef struct _TopDownMsg_t {
  uint8_t id;             ///< This #id is not intend to differentiate id types. A type cast might be required.
  void * data;
  uint32_t seq;
} TopDownMsg_t;

/*
 * @brief Message structure used in the bottom-up message queue.
 */
typedef struct _TopDownMsg_t BottomUpMsg_t;

/*******************************************************************************
 * Supporting types for data structure.
 *******************************************************************************/
/** 
 * @brief Joining type for #OPEN_JOIN.
 */
typedef enum {
  USER_DEFINED_LINK_KEY_ONLY,
  DEFAULT_LINK_KEY_ONLY,
  MIX_CODE_KEY,
} NwkJoinType_t;

typedef enum {
  NO_NWK,                   ///< NCP contains no network. Factory reset may be required.
  NWK_DOWN,                 ///< Network down for the moment.
  NWK_UP,                   ///< Network is up and running.
} NwkStatusType_t;

typedef enum {
  CLIENT,
  SERVER,
} ClusterType_t;

typedef enum {
  ASSN_RSP,                 ///< Responses for either #SET_ASSN or #CLR_ASSN.
  ATTR_RSP,                 ///< Responses for attribute-related operations.                 
} OpsRspType_t;

typedef enum {
  UNICAST,
  MULTICAST,
  BROADCAST,
} SendType_t;

typedef enum {
  JOINED,
  UNRESPONSIVE,
  LEAVE_SENT,
  LEFT,
} DevState_t;

typedef enum {
  IMAGE_SLOT0 = 0,
  //IMAGE_SLOT1, //currently we make this for 2M flash, 
                 //which can only accomodate 1 slot
  MAX_IMAGE_SLOT = 1,
} ImageSlot_t;

typedef struct _Eui64_t {
  uint8_t uuid[MAX_EUI64_LEN];
} Eui64_t;

/*
 * @brief The #eui64 value could be a specific value or a wildcard value (all 0xF).
 * Each link key should be associated with a eui64.
 */
typedef struct _LinkKey_t {
  uint8_t linkKey[MAX_LINK_KEY_SIZE];
  Eui64_t eui64;
} LinkKey_t;

typedef struct _ImageInfo_t {
  uint32_t fwVersion;
  uint16_t imageType;
  uint16_t manufacturerId;
} ImageInfo_t;

typedef struct _AttrReportSetting_t {
  uint16_t minReportTime;
  uint16_t maxReportTime;
  uint16_t attributeId;
  uint16_t manufacturerId; //please input set it NULL_MANUFACTURER_CODE
                           //if it is not manufacturer cluster
  uint8_t  dataType;
  uint8_t  reportableChange[MAX_OCTET_STRING_SIZE];  ///< Bytes in MSB fashion, e.g., 0x1234 in byte order is [0x34, 0x12].
} AttrReportSetting_t;

typedef struct _ClusterInfo_t {
  uint16_t      clusterId;
  uint16_t      manufacturerId; //please input set it NULL_MANUFACTURER_CODE
                                //if it is not manufacturer cluster
  ClusterType_t clusterType;
} ClusterInfo_t;

typedef struct _DevEndPoint_t {
  uint8_t endpoint;
  uint16_t devType;
  ClusterInfo_t clusters[MAX_CLUSTERS_SIZE];
  uint8_t clusterNum;       ///< Number of valid clusters in #clusters.
} DevEndPoint_t;

typedef struct _zclPacket_t {
  uint16_t clusterId;
  uint8_t endpoint;
  uint8_t frame[MAX_ZCL_DATA_SIZE];
  uint16_t len;
} ZclPacket_t;
/*******************************************************************************
 * Data structures for #TopDownMsgId_t and #BottomUpMsgId_t.
 *******************************************************************************/
/*
 * @brief Relate to #CREATE_NWK. 
 * 
 * @note Related EmberAPI:
 * [0]: <tt>network leave</tt>
 * [1]: <tt>plugin network-creator form</tt>
 */
typedef struct _CreateNwk_t {
  uint8_t  random;          ///< Ignore the rest settings if random is enabled.
  uint16_t panId;
  uint16_t channel;
  int16_t  power;
} CreateNwk_t;

/*
 * @brief Relate to #DEV_LEAVE_NWK.
 * 
 * @note Related EmberAPI:
 * [0]: <tt>zdo leave</tt>
 * 
 * @note UGL does not define join/rejoin behavior. Leave the option here in case needed.
 */
typedef struct _DevLeaveNwk_t {
  Eui64_t eui64;
  uint8_t allowRejoin;      ///< Allow(1)/Disallow(0) rejoin.
} DevLeaveNwk_t;
    
 /* @brief Relate to #DEV_TABLE_DEL.
  */
typedef struct _devTableDel_t {
  Eui64_t eui64;
} DevTableDel_t;

/*
 * @brief Relate to #OPEN_JOIN.
 * 
 * @note Related EmberAPI:
 * [0]: <tt>plugin network-creator-security clear-joining-link-keys</tt>
 * [1]: <tt>plugin network-creator-security set-joining-link-key</tt>
 * [2]: <tt>plugin network-creator-security open-with-key</tt>
 * [3]: <tt>plugin network-creator start</tt>
 */
typedef struct _OpenJoin_t {
  NwkJoinType_t joinType;
  LinkKey_t userLinkKey;   ///< This value is only valid if #joinType equals to #USER_DEFINED_LINK_KEY_ONLY.
  uint8_t discEnabled;     ///< Enable(1)/Disbale(0) automatic device discovery.
} OpenJoin_t;

/*
 * @brief Relate to #DEV_DISC.
 */
typedef struct _DevDisc_t {
  Eui64_t eui64;
} DevDisc_t;

/*
 * @brief Relate to #SET_ASSN.
 * 
 * @note Related EmberAPI:
 * [0]: <tt>zdo bind</tt>
 * [1]: <tt>plugin device-table send</tt>
 */
typedef struct _SetAssn_t {
  Eui64_t  destEui64;           ///< Refers to NCP Eui64.
  Eui64_t  remoteEui64;         ///< Refers to remote node Eui64.
  uint16_t clusterId;
  uint8_t  srcEndpoint;         ///< Refers to remote node endpoint.
  uint8_t  destEndpoint;        ///< Refers to NCP endpoint.
} SetAssn_t;

/*
 * @brief Relate to #SET_REPORT.
 *
 * @note Related EmberAPI:
 * [0]: <tt>zcl global send-me-a-report</tt>
 * [1]: <tt>plugin device-table send</tt>
 */
typedef struct _SetReport_t {
  Eui64_t  eui64;
  uint8_t  endpoint;
  ClusterInfo_t clusterInfo;
  AttrReportSetting_t setAttrReport;
} SetReport_t;

/*
 * @brief Relate to #CLR_ASSN.
 * 
 * @note Related EmberAPI:
 * [0]: <tt>zdo unbind</tt>
 * [1]: <tt>plugin device-table send</tt>
 */
typedef struct _SetAssn_t ClrAssn_t;

 /*
  * @brief Relate to #ATTR_WRITE.
  * 
  * @note Related EmberAPI:
  * [0]: <tt>zcl global direction</tt>. Direction determination is left to lower layer.
  * [1]: <tt>zcl global write</tt>
  * [2]: <tt>plugin device-table send</tt>
  */
typedef struct _AttrWrite_t {
  Eui64_t  eui64;
  ClusterInfo_t clusterInfo;
  uint32_t attrType;
  uint16_t attrId;
  uint8_t  data[MAX_ZCL_DATA_SIZE];
  uint8_t  dataLen;
  uint8_t  endpoint;
} AttrWrite_t;

/*
 * @brief Relate to #ATTR_READ.
 * 
 * @note Related EmberAPI:
 * [0]: <tt>zcl global direction</tt>. Direction determination is left to lower layer.
 * [1]: <tt>zcl global read</tt>
 * [2]: <tt>plugin device-table send</tt>
 */
typedef struct _AttrRead_t {
  Eui64_t  eui64;
  ClusterInfo_t clusterInfo;
  uint16_t attrId;
  uint8_t  endpoint;
} AttrRead_t;

/*
 * @brief Relate to #CMD_CTRL.
 * 
 * @note Related EmberAPI:
 * [0]: ZCL cluster commands, e.g,<tt>zcl on-off on</tt>
 * [1]: <tt>plugin device-table send</tt>
 */
typedef struct _CmdCtrl_t {
  SendType_t sendType;
  Eui64_t  eui64;                   ///< Valid only when #UNICAST.
  uint8_t  endpoint;                ///< Valid only when #UNICAST.
  uint16_t destination;               ///< Valid only when #MULTICAST or #BROADCAST
  uint16_t clusterId;               ///< ZCL cluster Id.
  uint8_t  cmdId;                   ///< ZCL command Id of the related cluster.
  uint8_t  data[MAX_ZCL_DATA_SIZE];
  uint8_t  dataLen;
} CmdCtrl_t;

/*
 * @brief Relate to #OTA_IMAGE_NOTIFY.
 */
typedef struct _OtaNotify_t {
  Eui64_t eui64;
  uint16_t manufacturerId;
  uint16_t imageTypeId;
  uint32_t firmwareVersion;
} OtaNotify_t;

/* @brief Relate to #ZCL_SEND.
 */
typedef struct _zclSend_t {
  Eui64_t     eui64;                ///< Target Eui64.(only valid for unicast)
  ZclPacket_t packet;
  uint16_t    destination;          ///< multicast id or broadcast address
  SendType_t  sendType;             ///<  UNICAST or
                                    ///   MULTICAST or
                                    ///   BROADCAST
                                    //  for multicast fill in multicastId/groupId
                                    //  to destination; for broadcast fill in 
                                    //  broadcast address to destination. Ignore
                                    //  destination for unicast
} ZclSend_t;

/* @brief Relate to #NCP_UPDATE.
 */
typedef struct _ncpUpdateFile_t {
  uint32_t fileSize;                       ///< ncp gbl file size. please be noted that
                                           ///< ncp upgrade gbl file must be written to 
                                           ///< FLASH_ADDR_NCP_IMAGE_START defined above.
                                           ///< the file size is limited to 0x50000(327,680)
} NcpUpdateFile_t;

/* @brief Relate to #ENBALE_PRINTOUT_LOG.
 */
typedef struct _printoutLogEn_t {
  uint8_t enable;                   ///< 0: disable otherwise enable
} PrintoutLogEn_t;

/*
 * @brief Relate to #NWK_SETTINGS.
 */
typedef struct _NwkSettings_t {
  Eui64_t  ncpEui64;
  uint16_t panId;
  uint16_t channel;
  int16_t  power;
  const char * ncpStackVersion;     ///< Global stack version.
} NwkSettings_t;

/*
 * @brief Relate to #NWK_STATUS. Could be unsolicited messages.
 */
typedef struct _NwkStatus_t {
  NwkStatusType_t status;
} NwkStatus_t;

/*
 * @brief Relate to #DEV_JOINED. Could be unsolicited messages.
 */
typedef struct _DevJoined_t {
  Eui64_t eui64;
  DevState_t devState;
  ImageInfo_t version;                            ///< The data is valid only when #discEnabled is set.
  DevEndPoint_t endPoints[MAX_ENDPOINTS_SIZE];    ///< The data is valid only when #discEnabled is set.
  uint8_t endpointNum;                            ///< The data is valid only when #discEnabled is set.
} DevJoined_t;

/*
 * @brief Relate to #DEV_DISC_RET.
 * 
 * @note #DevDiscRet_t::endpoints, #DevDiscRet_t::endpointNum and #DevDiscRet_t::version should be valid.
 */
typedef struct _DevJoined_t DevDiscRet_t;

/*
 * @brief Relate to #DEV_LEFT. Could be unsolicited messages.
 */
typedef struct _DevDisc_t DevLeft_t;

/*
 * @brief Relate to #DEV_STATUS_CHANGED. Could be unsolicited messages.
 */
typedef struct _DevStatusChanged_t {
  Eui64_t eui64;
  DevState_t devState;
} DevStatusChanged_t;

/*
 * @brief Relate to #ATTR_MSG. Could be unsolicited messages.
 */
typedef struct _AttrMsg_t {
  Eui64_t  eui64;
  uint32_t attrType;
  uint16_t clusterId;
  uint16_t attrId;
  uint16_t manufacturerId;         ///< this field will be filled with NULL_MANUFACTURER_CODE
                                  ///< if the message is not manufacturer specifc
  uint8_t  data[MAX_ZCL_DATA_SIZE];
  uint8_t  dataLen;
  uint8_t  endpoint;
} AttrMsg_t;

/*
 * @brief Relate to #OPS_RSP. Could be unsolicited messages.
 */
typedef struct _OpsRsp_t {
  Eui64_t destEui64;
  uint8_t destEndpoint;
  uint8_t status;
  OpsRspType_t msgType;
} OpsRsp_t;

/*
 * @brief Relate to #DEV_INFO. Could be unsolicited messages.
 */
typedef struct _DevInfo_t {
  Eui64_t eui64;
  uint8_t endpoint;
} DevInfo_t;

/* @brief Relate to #CMD_RECV.
 */
typedef struct _CmdRecv_t {
  Eui64_t  eui64;                     ///< Source Eui64.
  uint16_t clusterId;
  uint16_t manufacturerId;             ///< this field will be filled with NULL_MANUFACTURER_CODE
                                      ///< if the message is not manufacturer specifc
  uint8_t  endpoint;                  ///< Source endpoint.
  uint8_t  cmdId;                     ///< ZCL command id.
  uint8_t  data[MAX_ZCL_DATA_SIZE];
  uint8_t  dataLen;
} CmdRecv_t;

/* @brief Relate to #ZCL_MSG.
 */
typedef struct _zclMsg_t {
  Eui64_t  eui64;                     ///< Source Eui64.
  ZclPacket_t packet;
} ZclMsg_t;

/* @brief Relate to #SET_ASSN_RSP.
 */
typedef struct _setAssnRsp_t {
  Eui64_t  eui64;                               ///< Source Eui64.
  uint8_t  endpoint;                            ///< Source endpoint.
  uint16_t clusterId;
  uint8_t  status;                              ///<0 : success, otherwise failure
} SetAssnRsp_t;

/* @brief Relate to #SET_REPORT_RSP.
 */
typedef SetAssnRsp_t SetReportRsp_t;

/* @brief Relate to #IAS_ZONE_DISC.
 */
typedef struct _iasZoneDisc_t {
  Eui64_t  eui64;                               ///< ias zone server Eui64.
  uint16_t zoneType;                            ///< zone type defined in ZCL spec.
  uint8_t zoneState;                            ///< 0: not enrolled, 1: enrolled.
  uint8_t endpoint;                             ///< zone id of the enrolled zone.
  uint8_t zoneId;
} IasZoneDisc_t;

/* @brief Relate to #OTA_STATUS.
 */
typedef struct _otaStatus_t {
  Eui64_t  eui64;                               ///< Eui64 of the upgrading device.
  uint32_t bytesSent;                           ///< bytes sent so far, only valid when status = 1(started)
  uint32_t firmwareVer;                         ///< firmware version of the image
  uint16_t manufacturerId;                      ///< manufacturer Id of the image
  uint16_t imageTypeId;                         ///< image Id of the image
  uint8_t status;                               ///< 0: finised; 1: started; 2: failed;
} OtaStatus_t;

/*
 * @brief Relate to #NCP_UPDATE_RSP.
 */
typedef struct _ncpUpdateRsp_t {
  uint8_t status;                              ///<0 : success, otherwise failure
} NcpUpdateRsp_t;

/*
 * @brief Relate to #NCP_RESET_STATUS.
 */
typedef struct _ncpResetStatus_t {
  uint8_t status;                              ///<0 : success, otherwise failure
} NcpResetStatus_t;

/* @brief Relate to #PRINTOUT_LOG.
 */
typedef struct _printoutLog_t {
  char printBuf[MAX_LOG_BUFFER_SIZE];
} PrintoutLog_t;

//data for format for commands
//Group:
//  addGroup:              data[0]:group id Lower byte
//                         data[1]:group id Higher byte
//                         data[2]:group name length(<=16 bytes)
//                         data[3]...data[n]: group name
//                          
//  removeGroup:           data[0]:group id Lower byte
//                         data[1]:group id Higher byte
//OnOff:
//  on :                    no data;
//  off:                    no data;
//  toggle:                 no data;
//
//Level Control:
//  movetolevel:            data[0]:level;
//                          data[1]:transitionTime Lower byte;
//                          data[2]:transitionTime Higher byte;
//                          data[3]:optionMask;
//                          data[4]:optionOverride;
//                          ----------------------------------------------------
//  move:                   data[0]:moveMode;
//                          data[1]:rate;
//                          data[2]:optionMask;
//                          data[3]:optionOverride;
//                          ----------------------------------------------------
//  step:                   data[0]:stepMode;
//                          data[1]:stepSize;
//                          data[2]:transitionTime Lower byte;
//                          data[3]:transitionTime Higher byte;
//                          data[4]:optionMask;
//                          data[5]:optionOverride;
//                          ----------------------------------------------------
//  stop:                   data[0]:optionMask;
//                          data[1]:optionOverride;
//
//Color Control:
//  movetocolor:            data[0]:colorX Lower byte;
//                          data[1]:colorX Higer byte;
//                          data[2]:colorY Lower byte;
//                          data[3]:colorY Higher byte;
//                          data[4]:transitionTime Lower byte;
//                          data[5]:transitionTime Higher byte;
//                          data[6]:optionMask;
//                          data[7]:optionOverride;
//                          ----------------------------------------------------
//  movecolor:              data[0]:rateX Lower byte;
//                          data[1]:rateY Higer byte;
//                          data[2]:optionMask;
//                          data[3]:optionOverride;
//                          ----------------------------------------------------
//  movetohueandsaturation: data[0]:hue;
//                          data[1]:saturation;
//                          data[2]:transitionTime Lower byte;
//                          data[3]:transitionTime Higher byte;
//                          data[4]:optionMask;
//                          data[5]:optionOverride;
//                          ----------------------------------------------------
//  movetocolortemperature: data[0]:colorTemperature Lower byte;
//                          data[1]:colorTemperature Higher byte;
//                          data[2]:transitionTime Lower byte;
//                          data[3]:transitionTime Higher byte;
//                          data[4]:optionMask;
//                          data[5]:optionOverride;
//                          ----------------------------------------------------
//  stepcolor:              data[0]:stepX Lower byte;
//                          data[1]:stepX Higher byte;
//                          data[2]:stepY Lower byte;
//                          data[3]:stepY Higher byte;
//                          data[4]:transitionTime Lower byte;
//                          data[5]:transitionTime Higher byte;
//                          data[6]:optionMask;
//                          data[7]:optionOverride;
/*******************************************************************************
 * Api to load the library
 ******************************************************************************/
bool startGateway(int argc, char *argv[]);

#ifdef __cplusplus
}
#endif

#endif //__Z3_GW_HOST_CMD_H__
