/*******************************************************************************
 * hashing-cli.c
 *
 * This program hashes the Zigbee Smart Energy install code and CRC and
 * prints the result.  It is designed to reproduce the same results
 * as specified in the Zigbee Smart Energy specification.
 *
 * The Zigbee Matyas-Meyer-Oseas Hash function (MMO Hash) is implemented here,
 * along with the CRC-16 functionality.  AES-128 is a prerequisite for
 * MMO Hash but is not provided here, instead I used the Rijndael implementation
 * which is in the public domain.  It is included in this directory.
 *
 * Author(s): Robert Alexander <rob.alexander@ember.com>
 *
 ******************************************************************************/

#include <stdio.h>
//#include <platform/platform_stdlib.h>
#include <stdlib.h>  // for malloc()
#include <stdarg.h>  // for va_list, va_start()
#include <getopt.h>  // for getopt_long()
#define __USE_GNU
#include <string.h>  // for strncpy(), strnlen()
#include <assert.h>  // for assert()

#include "rijndael/rijndael-api-fst.h"
#include "rijndael/rijndael-alg-fst.h"

//------------------------------------------------------------------------------
// Globals

typedef unsigned char byte;

#define SECURITY_BLOCK_SIZE 16

static int DEBUG = 0;

static cipherInstance myCipher;

//------------------------------------------------------------------------------
// Forward Declarations

static void deriveKey(byte* installCode, 
                      int length,
                      int calculatedCrc,
                      byte* result);

static int parseHexByteString(char* argumentName, 
                              char* inputString, 
                              byte* returnData, 
                              int maxByteLength);
static byte convertHexCharToByte(unsigned char c);
static void convertByteToHexChars(byte data, char result[2]);
static void printHexBytes(byte* data, int length);
static char* convertBytesToHexString(byte* data, int length);


#define WARNING 0
#define ERROR   1
static void printToStderr(int error, const char* formatString, ...);
#define warn(string, ...) printToStderr(WARNING, string, __VA_ARGS__)
#define error(string, ...) printToStderr(ERROR, string, __VA_ARGS__)

static void debugPrint(const char* formatString, ...);

static void aesHash(byte *data,
                    byte totalLength,
                    byte *result);
static void standAloneEncryptBlock(byte key[SECURITY_BLOCK_SIZE],
                                   byte block[SECURITY_BLOCK_SIZE]);
static unsigned short crc16(byte* data_p, unsigned short length);


#define MY_ASSERT(test) myAssert((test), __FILE__, __LINE__)

//------------------------------------------------------------------------------
// Functions

// Because assert() may be compiled out, we use our own here.
// The asserts used in our code are important and cannot be ignored since
// there is no recovery from the error.
void myAssert(int test, const char* file, int line)
{
  if (!test) {
    fprintf(stderr, "\n\rFATAL:  assert failed in '%s' on line %d\n",
            file,
            line);
    exit(-1);
  }
}

#if defined(WIN32)
size_t strnlen(const char* s, size_t maxlen)
{
  size_t i;
  for (i = 0; i < maxlen; i++) {
    if (s[i] == '\0') {
      break;
    }
  }
  return i;
}
#endif

int installCodeToLinkKey(int installCodeLength, unsigned char *installCode, unsigned char *hashResult)
{
  int calculatedCrc;
  
  MY_ASSERT(installCode != NULL);
  MY_ASSERT(hashResult != NULL);

  printf("\n\rInstall Code: ");
  printHexBytes(installCode, installCodeLength);
  printf("\n\r");
  calculatedCrc = crc16(installCode, installCodeLength);
  printf("Calculated CRC: (>)0x%04X\n", calculatedCrc);

  deriveKey(installCode, installCodeLength, calculatedCrc, hashResult);

  return 0;    
    
}


static void deriveKey(byte* installCode, 
                      int length,
                      int calculatedCrc,
                      byte* result)
{
  byte installCodeAndCrc[18];
  memcpy(installCodeAndCrc, installCode, length);
  installCodeAndCrc[length] = (byte)(calculatedCrc & 0xFF);
  installCodeAndCrc[length+1] = (byte)(calculatedCrc >> 8);
  
  printf("\n\rByte Concatenation: ");
  printHexBytes(installCodeAndCrc, length + 2);
  printf("\n\r");

  aesHash(installCodeAndCrc, length + 2, result);
  printf("Hash Result:        ");
  printHexBytes(result, SECURITY_BLOCK_SIZE);
  printf("\n\r");
}



// Transform a string of hex characters into an array of bytes.
// Returns number of bytes parsed on success, or 0 on error.
static int parseHexByteString(char* argumentName, 
                              char* inputString, 
                              byte* returnData, 
                              int maxByteLength)
{
  int i;
  int length = strnlen(inputString, (maxByteLength * 2)
                       + 1    // NULL terminator
                       + 2);  // '0x' prefix
  debugPrint("Parsing argument for '%s'\n", argumentName);

  if (length >= 2 
      && inputString[0] == '0'
      && (inputString[1] == 'x' || inputString[1] == 'X')) {
    // Skip '0x' prefix
    inputString += 2;
    length -= 2;
  }

  if (length > (maxByteLength * 2)) {
    error("%s cannot be longer than %d\n", maxByteLength);
    return 0;
  }

  if (length % 2 != 0) {
    error("%s must be an even number of hex characters.\n", argumentName);
    return 0;
  }

  int byteArrayIndex = 0;
  for (i = 0; i < length; i+= 2) {
    byte a = convertHexCharToByte(inputString[i]);
    byte b = convertHexCharToByte(inputString[i+1]);
    if (a != 0xFF && b != 0xFF) {
      returnData[byteArrayIndex] = (a << 4) | b;
      byteArrayIndex++;
    } else {
      error("Invalid hex character '%C' for %s\n", 
            (a == 0xFF
             ? inputString[i]
             : inputString[i+1]),
            argumentName);
      return 0;
    }
  }
  return length / 2;
}

static byte convertHexCharToByte(unsigned char c)
{
  if (c >= 'A' && c <= 'F') {
    return c - 'A' + 0x0A;
  } else if (c >= 'a' && c <= 'f') {
    return c - 'a' + 0x0A;
  } else if (c >= '0' && c <= '9') {
    return c - '0';
  }
  return 0xFF;
}

static void convertByteToHexChars(byte data, char result[2])
{
  char string[3];            // we need 3 bytes due to the '\0' added by 
  snprintf(string,           //  snprintf()
           3, 
           "%02X", 
           data);
  memcpy(result, string, 2); // but we don't want to pass back the '\0'
}

static void printToStderr(int error, const char* formatString, ...)
{
  va_list vargs;
  fprintf(stderr, "%s: ", (error
                           ? "Error"
                           : "Warning"));
  va_start(vargs, formatString);
  vfprintf(stderr, formatString, vargs);
  va_end(vargs);
}

static void debugPrint(const char* formatString, ...)
{
  if (DEBUG) {
    va_list vargs;
    printf("Debug: ");
    va_start(vargs, formatString);
    vprintf(formatString, vargs);
    va_end(vargs);
  }
}

static void printHexBytes(byte* data, int length)
{
  char* string = convertBytesToHexString(data, length);
  printf("%s", string);
  free(string);
}

static char* convertBytesToHexString(byte* data, int length)
{
  char* string = (char*)malloc((length * 2) + 1);
  int i;
  MY_ASSERT(string != NULL);
  for (i = 0; i < length; i++) {
    convertByteToHexChars(data[i], &(string[i * 2]));
  }
  string[length * 2] = '\0';
  return string;
}



// B.6 Block-cipher-based cryptographic hash function.
//
// This is a method of deriving a hash function from a block encryption
// function.  ZigBee uses AES-128 as the encryption function.
//
// First pad the data out to a multiple of 16 bytes with a binary 1 followed by
// all zeros.  Append the length of the input (in bits) at the end of the
// padding.
//
// Encrypt the first 16 byte chunk using a NULL key, and XOR with the 
//   unencrypted data chunk.
// Encrypt the other 16 byte chunks using the previous result as the
//   key, and XOR with the unencrypted data chunk.

// Our limited function assumes the following:
//   The 'result' value points to an area of memory 16 bytes in length.

static void aesHashNextBlock(byte *block, byte *result)
{
  byte i;
  
  byte key[SECURITY_BLOCK_SIZE];
  memcpy(key, result, SECURITY_BLOCK_SIZE);
  memcpy(result, block, SECURITY_BLOCK_SIZE);
  standAloneEncryptBlock(key, result);
    
  for (i = 0; i < SECURITY_BLOCK_SIZE; i++)
    result[i] ^= block[i];
}

// The hashed data must be in the following form
// ... data ... 0x80 0x00 ... 0x00 LOW_BYTE(dataBits) HIGH_BYTE(dataBits)
// where enough 0x00's are added to make the entire length be a multiple
// of 16.  The last two bytes give the size of the original data in bits.

static void aesHash(byte *data,
                    byte totalLength,
                    byte *result)
{
  byte temp[SECURITY_BLOCK_SIZE];
  byte moreDataLength = totalLength;

  memset(result, 0, SECURITY_BLOCK_SIZE);  // Hash of 0 is all zeros
  
  for (;
       SECURITY_BLOCK_SIZE <= moreDataLength;
       data += SECURITY_BLOCK_SIZE, moreDataLength -= SECURITY_BLOCK_SIZE)
    aesHashNextBlock(data, result);

  memset(temp, 0, SECURITY_BLOCK_SIZE);
  memcpy(temp, data, moreDataLength);
  temp[moreDataLength] = 0x80;
    
  if (SECURITY_BLOCK_SIZE - moreDataLength < 3) {
    aesHashNextBlock(temp, result);
    memset(temp, 0, SECURITY_BLOCK_SIZE);
  }
  
  temp[SECURITY_BLOCK_SIZE - 2] = totalLength >> 5;
  temp[SECURITY_BLOCK_SIZE - 1] = totalLength << 3;
  
  aesHashNextBlock(temp, result);
}

// The single entry point into the implementation specific method 
// of performing AES-128.  In this case I use the Rijndael implementation.
static void standAloneEncryptBlock(byte key[SECURITY_BLOCK_SIZE],
                                   byte block[SECURITY_BLOCK_SIZE])
{
  static int cipherInitialized = FALSE;
  byte outBlock[SECURITY_BLOCK_SIZE];
  keyInstance myKey;

  // Key is expected to be in ASCII hex
  char keyMaterial[SECURITY_BLOCK_SIZE * 2];
  char* string = convertBytesToHexString(key, SECURITY_BLOCK_SIZE);
  strncpy(keyMaterial, string, SECURITY_BLOCK_SIZE * 2);
  free(string);

  if (!cipherInitialized) {
    // ZigBee defines the IV for AES Encrypt to be zero, per the Spec. section
    // B.1 Block-Cipher-Based Cryptographic Hash Function
    MY_ASSERT(cipherInit(&myCipher,
                      MODE_CBC,
                      NULL));     // Initialization Vector
    cipherInitialized = TRUE;
  }

  MY_ASSERT(0 <= makeKey(&myKey,
                      DIR_ENCRYPT,
                      SECURITY_BLOCK_SIZE * 8,
                      keyMaterial));

  MY_ASSERT(0 <= blockEncrypt(&myCipher,
                           &myKey,
                           block,
                           SECURITY_BLOCK_SIZE * 8,
                           outBlock));
                           
  memcpy(block, outBlock, SECURITY_BLOCK_SIZE);
}

// CRC code obtained from:
//   http://drdobbs.com/embedded/199904926

/**************************************************************************
//
// crc16 - generate a ccitt 16 bit cyclic redundancy check (crc)
//
//      The code in this module generates the crc for a block of data.
//
**************************************************************************/

/*
//                                   
// The CCITT CRC 16 polynomial is X^16 + X^12 + X^5 + 1.
// In binary, this is the bit pattern 1 0001 0000 0010 0001, and in hex it
//  is 0x11021.
// A 17 bit register is simulated by testing the MSB before shifting
//  the data, which affords us the luxury of specifiy the polynomial as a
//  16 bit value, 0x1021.
// Due to the way in which we process the CRC, the bits of the polynomial
//  are stored in reverse order. This makes the polynomial 0x8408.
*/
#define POLY 0x8408

/*
// note: when the crc is included in the message, the valid crc is:
//      0xF0B8, before the compliment and byte swap,
//      0x0F47, after compliment, before the byte swap,
//      0x470F, after the compliment and the byte swap.
*/

int     crc_ok = 0x470F;

/**************************************************************************
//
// crc16() - generate a 16 bit crc
//
//
// PURPOSE
//      This routine generates the 16 bit remainder of a block of
//      data using the ccitt polynomial generator.
//
// CALLING SEQUENCE
//      crc = crc16(data, len);
//
// PARAMETERS
//      data    <-- address of start of data block
//      len     <-- length of data block
//
// RETURNED VALUE
//      crc16 value. data is calcuated using the 16 bit ccitt polynomial.
//
// NOTES
//      The CRC is preset to all 1's to detect errors involving a loss
//        of leading zero's.
//      The CRC (a 16 bit value) is generated in LSB MSB order.
//      Two ways to verify the integrity of a received message
//        or block of data:
//        1) Calculate the crc on the data, and compare it to the crc
//           calculated previously. The location of the saved crc must be
//           known.
/         2) Append the calculated crc to the end of the data. Now calculate
//           the crc of the data and its crc. If the new crc equals the
//           value in "crc_ok", the data is valid.
//
// PSEUDO CODE:
//      initialize crc (-1)
//      DO WHILE count NE zero
//        DO FOR each bit in the data byte, from LSB to MSB
//          IF (LSB of crc) EOR (LSB of data)
//            crc := (crc / 2) EOR polynomial
//          ELSE
//            crc := (crc / 2)
//          FI
//        OD
//      OD
//      1's compliment and swap bytes in crc
//      RETURN crc
//
**************************************************************************/

static unsigned short crc16(byte* data_p, unsigned short length)
{
  unsigned char i;
  unsigned int data;
  unsigned long crc;
       
  crc = 0xFFFF;
       
  if (length == 0)
    return (~crc);
       
  do {
    for (i = 0, data = (unsigned int)0xff & *data_p++;
         i < 8;
         i++, data >>= 1) {
      if ((crc & 0x0001) ^ (data & 0x0001))
        crc = (crc >> 1) ^ POLY;
      else
        crc >>= 1;
    }
  } while (--length);
       
  crc = ~crc;
       
  data = crc;
       
  return (crc);
}

// for testing
/*
void testHashing(void)
{
  printf("Testing AES-128\n");
  {
    // These values were found in FIPS 197 Appendix C - Example Vectors,
    // C.1 AES-128
    byte plainText[] =  { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
                          0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF };
    byte aesKeyTest[] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                          0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F };
    byte encryptOutput[] = { 0x69, 0xC4, 0xE0, 0xD8, 0x6A, 0x7B, 0x04, 0x30, 
                             0xD8, 0xCD, 0xB7, 0x80, 0x70, 0xb4, 0xC5, 0x5A };
    printf("\n\rPlain Text: ");
    printHexBytes(plainText, SECURITY_BLOCK_SIZE);
    printf("\n\r");
    printf("AES Key:    ");
    printHexBytes(aesKeyTest, SECURITY_BLOCK_SIZE);
    printf("\n\r");
    printf("Expected Output: ");
    printHexBytes(encryptOutput, SECURITY_BLOCK_SIZE);
    printf("\n\r");

    standAloneEncryptBlock(aesKeyTest, plainText);
    printf("Actual Output:   ");
    printHexBytes(plainText, SECURITY_BLOCK_SIZE);
    printf("\n\r");
    MY_ASSERT(0 == memcmp(plainText, encryptOutput, SECURITY_BLOCK_SIZE));
  }
  
  printf("\n\rTesting MMO-Hash\n");
  {
    // These values were specified in the ZigBee Spec Rev17, 
    // C.5 Cryptographic Hash Function (Test Vector Set 1 and 2)
    byte testIn0[] = { 0xC0 };
    byte testOut0[] =
      { 0xAE, 0x3A, 0x10, 0x2A, 0x28, 0xD4, 0x3E, 0xE0,
        0xD4, 0xA0, 0x9E, 0x22, 0x78, 0x8B, 0x20, 0x6C };
    byte testIn1[] = 
      { 0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 
        0xC8, 0xC9, 0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF };
    byte testOut1[] = 
      { 0xA7, 0x97, 0x7E, 0x88, 0xBC, 0x0B, 0x61, 0xE8, 
        0x21, 0x08, 0x27, 0x10, 0x9A, 0x22, 0x8F, 0x2D };

    byte* testInput[] =  { testIn0, testIn1 };
    byte testSizes[] = { sizeof(testIn0), sizeof(testIn1) };
    byte* testOutput[] = { testOut0, testOut1 };
    byte result[SECURITY_BLOCK_SIZE];
    int i;
    memset(result, 0, SECURITY_BLOCK_SIZE);

    for (i = 0; i < 2; i++) {
      printf("Input %d: ", (i+1));
      printHexBytes(testInput[i], testSizes[i]);
      printf("\n\r");
      aesHash(testInput[i], testSizes[i], result);
      printf("Expected Output: ");
      printHexBytes(testOutput[i], SECURITY_BLOCK_SIZE);
      printf("\n\r");
      printf("Actual Output:   ");
      printHexBytes(result, SECURITY_BLOCK_SIZE);
      printf("\n\r");
      MY_ASSERT(0 == memcmp(testOutput[i], result, SECURITY_BLOCK_SIZE));
    }
  }

  printf("\n\rTesting Install code calculations\n");
  {
    // These are specified in Zigbee document 075356r15, section 5.4.8.1.2
    byte installCode6Byte[] = {
      0x83, 0xFE, 0xD3, 0x40, 0x7A, 0x93
    };
    byte installCode8Byte[] = { 
      0x83, 0xFE, 0xD3, 0x40, 0x7A, 0x93, 0x97, 0x38
    };
    byte installCode12Byte[] = {
      0x83, 0xFE, 0xD3, 0x40, 0x7A, 0x93, 0x97, 0x23, 
      0xA5, 0xC6, 0x39, 0xFF
    };
    byte installCode16Byte[] = {
      0x83, 0xFE, 0xD3, 0x40, 0x7A, 0x93, 0x97, 0x23, 
      0xA5, 0xC6, 0x39, 0xB2, 0x69, 0x16, 0xD5, 0x05
    };
    byte* installCodes[] = {
      installCode6Byte,
      installCode8Byte,
      installCode12Byte,
      installCode16Byte
    };
    int installCodeLengths[] = { 6, 8, 12, 16 };
    byte derivedLinkKeys[][16] = {
      { 0xCD, 0x4F, 0xA0, 0x64, 0x77, 0x3F, 0x46, 0x94, 
        0x1E, 0xC9, 0x86, 0xC0, 0x99, 0x63, 0xD1, 0xA8 },
      { 0xA8, 0x33, 0xA7, 0x74, 0x34, 0xF3, 0xBF, 0xBD, 
        0x7A, 0x7A, 0xB9, 0x79, 0x42, 0x14, 0x92, 0x87 },
      { 0x58, 0xC1, 0x82, 0x8C, 0xF7, 0xF1, 0xC3, 0xFE, 
        0x29, 0xE7, 0xB1, 0x02, 0x4A, 0xD8, 0x4B, 0xFA },
      { 0x66, 0xB6, 0x90, 0x09, 0x81, 0xE1, 0xEE, 0x3C, 
        0xA4, 0x20, 0x6B, 0x6B, 0x86, 0x1C, 0x02, 0xBB }
    };
    byte hashResult[18];
    int i;
    for (i = 0; i < 4; i++) {
      //deriveKey(installCodes[i], 
      //          installCodeLengths[i],
      //          crc16(installCodes[i], installCodeLengths[i]),
      //          hashResult);
      installCodeToLinkKey(installCodeLengths[i], installCodes[i], hashResult);
      printf("Expected Result:    ");
      printHexBytes(derivedLinkKeys[i], 16);
      printf("\n\r");
      MY_ASSERT(0 == memcmp(hashResult, derivedLinkKeys[i], installCodeLengths[i]));
    }
  }

  printf("\n\rAll tests passed.\n");
}
*/
