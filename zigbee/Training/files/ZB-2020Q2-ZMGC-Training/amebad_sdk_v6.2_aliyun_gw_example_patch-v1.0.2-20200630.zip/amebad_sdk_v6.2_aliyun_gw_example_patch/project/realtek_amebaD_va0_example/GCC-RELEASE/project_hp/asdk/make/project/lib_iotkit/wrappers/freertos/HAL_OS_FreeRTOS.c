/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "FreeRTOS.h"
#include "queue.h"
#include "cmsis_os.h"

#include "infra_types.h"
#include "infra_defs.h"
#include "wrappers_defs.h"

#define HAL_SEM_MAX_COUNT           (10)
#define HAL_SEM_INIT_COUNT          (0)

#define DEFAULT_THREAD_NAME         "linkkit_task"
#define DEFAULT_THREAD_SIZE         (256)
#define TASK_STACK_ALIGN_SIZE       (4)

extern char _product_key[IOTX_PRODUCT_KEY_LEN + 1];
extern char _product_secret[IOTX_PRODUCT_SECRET_LEN + 1];
extern char _device_name[IOTX_DEVICE_NAME_LEN + 1];
extern char _device_secret[IOTX_DEVICE_SECRET_LEN + 1];

char _firmware_version[IOTX_FIRMWARE_VER_LEN] = "app-1.0.0-20190101.1000";

/**
 * @brief Deallocate memory block
 *
 * @param[in] ptr @n Pointer to a memory block previously allocated with platform_malloc.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_Free(void *ptr)
{
    vPortFree(ptr);
}

/**
 * @brief Allocates a block of size bytes of memory, returning a pointer to the beginning of the block.
 *
 * @param [in] size @n specify block size in bytes.
 * @return A pointer to the beginning of the block.
 * @see None.
 * @note Block value is indeterminate.
 */
void *HAL_Malloc(uint32_t size)
{
    return pvPortMalloc(size);
}


/**
 * @brief Create a mutex.
 *
 * @retval NULL : Initialize mutex failed.
 * @retval NOT_NULL : The mutex handle.
 * @see None.
 * @note None.
 */
void *HAL_MutexCreate(void)
{
    QueueHandle_t sem;

    sem = xSemaphoreCreateMutex();
    if (0 == sem) {
        return NULL;
    }

    return sem;
}

/**
 * @brief Destroy the specified mutex object, it will release related resource.
 *
 * @param [in] mutex @n The specified mutex.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_MutexDestroy(void *mutex)
{
    QueueHandle_t sem;
    if (mutex == NULL) {
        return;
    }
    sem = (QueueHandle_t)mutex;
    vSemaphoreDelete(sem);
}

/**
 * @brief Waits until the specified mutex is in the signaled state.
 *
 * @param [in] mutex @n the specified mutex.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_MutexLock(void *mutex)
{
    BaseType_t    ret;
    QueueHandle_t sem;
    if (mutex == NULL) {
        return;
    }

    sem = (QueueHandle_t)mutex;
    ret = xSemaphoreTake(sem, 0xffffffff);
    while (pdPASS != ret) {
        ret = xSemaphoreTake(sem, 0xffffffff);
    }
}

/**
 * @brief Releases ownership of the specified mutex object..
 *
 * @param [in] mutex @n the specified mutex.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_MutexUnlock(void *mutex)
{
    QueueHandle_t sem;
    if (mutex == NULL) {
        return;
    }
    sem = (QueueHandle_t)mutex;
    (void)xSemaphoreGive(sem);
}

/**
 * @brief Writes formatted data to stream.
 *
 * @param [in] fmt: @n String that contains the text to be written, it can optionally contain embedded format specifiers
     that specifies how subsequent arguments are converted for output.
 * @param [in] ...: @n the variable argument list, for formatted and inserted in the resulting string replacing their respective specifiers.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_Printf(const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    fflush(stdout);
}

/**
 * @brief   create a semaphore
 *
 * @return semaphore handle.
 * @see None.
 * @note The recommended value of maximum count of the semaphore is 255.
 */
void *HAL_SemaphoreCreate(void)
{
    QueueHandle_t sem = 0;

    sem = xSemaphoreCreateCounting(HAL_SEM_MAX_COUNT, HAL_SEM_INIT_COUNT);
    if (0 == sem) {
        return NULL;
    }

    return sem;
}

/**
 * @brief   destory a semaphore
 *
 * @param[in] sem @n the specified sem.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_SemaphoreDestroy(void *sem)
{
    QueueHandle_t queue;

    if (sem == NULL) {
        return;
    }
    queue = (QueueHandle_t)sem;

    vSemaphoreDelete(queue);
}

/**
 * @brief   signal thread wait on a semaphore
 *
 * @param[in] sem @n the specified semaphore.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_SemaphorePost(void *sem)
{
    QueueHandle_t queue;
    if (sem == NULL) {
        return;
    }
    queue = (QueueHandle_t)sem;
    (void)xSemaphoreGive(queue);
}

/**
 * @brief   wait on a semaphore
 *
 * @param[in] sem @n the specified semaphore.
 * @param[in] timeout_ms @n timeout interval in millisecond.
     If timeout_ms is PLATFORM_WAIT_INFINITE, the function will return only when the semaphore is signaled.
 * @return
   @verbatim
   =  0: The state of the specified object is signaled.
   =  -1: The time-out interval elapsed, and the object's state is nonsignaled.
   @endverbatim
 * @see None.
 * @note None.
 */
int HAL_SemaphoreWait(void *sem, uint32_t timeout_ms)
{
    BaseType_t ret = 0;
    QueueHandle_t queue;
    if (sem == NULL) {
        return -1;
    }

    queue = (QueueHandle_t)sem;
    ret = xSemaphoreTake(queue, timeout_ms);
    if (pdPASS != ret) {
        return -1;
    }
    return 0;
}

/**
 * @brief Sleep thread itself.
 *
 * @param [in] ms @n the time interval for which execution is to be suspended, in milliseconds.
 * @return None.
 * @see None.
 * @note None.
 */
void HAL_SleepMs(uint32_t ms)
{
    osDelay(ms);
}
/**
 * @brief Writes formatted data to string.
 *
 * @param [out] str: @n String that holds written text.
 * @param [in] len: @n Maximum length of character will be written
 * @param [in] fmt: @n Format that contains the text to be written, it can optionally contain embedded format specifiers
     that specifies how subsequent arguments are converted for output.
 * @param [in] ...: @n the variable argument list, for formatted and inserted in the resulting string replacing their respective specifiers.
 * @return bytes of character successfully written into string.
 * @see None.
 * @note None.
 */
int HAL_Snprintf(char *str, const int len, const char *fmt, ...)
{
    va_list args;
    int rc;

    va_start(args, fmt);
    rc = vsnprintf(str, len, fmt, args);
    va_end(args);
    return rc;
}

int HAL_Vsnprintf(char *str, const int len, const char *format, va_list ap)
{
    return vsnprintf(str, len, format, ap);
}

void HAL_Srandom(uint32_t seed)
{
    return;
}

uint32_t HAL_Random(uint32_t region)
{
    //platform_utils.c: uint32_t platform_random(uint32_t max);
    //uint32_t seed =  * ((volatile uint32_t *) 0xe000e018) ;      //system tick current value
    //srand(seed); //dummy
    return rand() % region;
}

/**
 * @brief  create a thread
 *
 * @param[out] thread_handle @n The new thread handle, memory allocated before thread created and return it, free it after thread joined or exit.
 * @param[in] start_routine @n A pointer to the application-defined function to be executed by the thread.
        This pointer represents the starting address of the thread.
 * @param[in] arg @n A pointer to a variable to be passed to the start_routine.
 * @param[in] hal_os_thread_param @n A pointer to stack params.
 * @param[out] stack_used @n if platform used stack buffer, set stack_used to 1, otherwise set it to 0.
 * @return
   @verbatim
     = 0: on success.
     = -1: error occur.
   @endverbatim
 * @see None.
 * @note None.
 */
int HAL_ThreadCreate(
            void **thread_handle,
            void *(*work_routine)(void *),
            void *arg,
            hal_os_thread_param_t *hal_os_thread_param,
            int *stack_used)
{
    char *name;
    int stacksize;
    osThreadDef_t thread_def;

    osThreadId handle;

    if (thread_handle == NULL) {
        return -1;
    }

    if (work_routine == NULL) {
        return -1;
    }

    if (hal_os_thread_param == NULL) {
        return -1;
    }
    if (stack_used == NULL) {
        return -1;
    }

    if (stack_used != NULL) {
        *stack_used = 0;
    }

    if (!hal_os_thread_param->name) {
        name = DEFAULT_THREAD_NAME;
    } else {
        name = hal_os_thread_param->name;
    }

    stacksize = (hal_os_thread_param->stack_size < DEFAULT_THREAD_SIZE) ?
        DEFAULT_THREAD_SIZE : hal_os_thread_param->stack_size;

    thread_def.name = name;
    thread_def.pthread = (os_pthread)work_routine;
    thread_def.tpriority = (osPriority)hal_os_thread_param->priority;
    thread_def.instances = 0;
    thread_def.stacksize = (uint32_t)stacksize;

    handle = osThreadCreate(&thread_def, arg);
    if (NULL == handle) {
        return -1;
    }
    *thread_handle = (void *)handle;

    //HAL_TRACE("Task \"%s\" created. (osThreadId=%x, stacksize=%d, priority=%d)\n", name, (int)handle, stacksize, hal_os_thread_param->priority);

    return 0;
}

void HAL_ThreadDelete(void *thread_handle)
{
    if (thread_handle == NULL) {
        HAL_ERR_TRACE("Task want to destroy is NULL!\n");
        return;
    }
    if (osThreadTerminate((osThreadId)thread_handle) != osOK) {
        HAL_ERR_TRACE("Task delete failed. (osThreadId=%x)\n", (int)thread_handle);
        return;
    }
    //HAL_TRACE("Task deleted. (osThreadId=%x)\n", (int)thread_handle);
}

// static FILE *fp;
// #define otafilename "/tmp/alinkota.bin"
void HAL_Firmware_Persistence_Start(void)
{
    // fp = fopen(otafilename, "w");
    return;
}

int HAL_Firmware_Persistence_Write(char *buffer, uint32_t length)
{
    // unsigned int written_len = 0;
    // written_len = fwrite(buffer, 1, length, fp);

    // if (written_len != length) {
    //     return -1;
    // }

    return 0;
}

int HAL_Firmware_Persistence_Stop(void)
{
    // if (fp != NULL) {
    //     fclose(fp);
    // }

    /* check file md5, and burning it to flash ... finally reboot system */

    return 0;
}

/**
 * @brief Retrieves the number of milliseconds that have elapsed since the system was boot.
 *
 * @return the number of milliseconds.
 * @see None.
 * @note None.
 */
uint64_t HAL_UptimeMs(void)
{
    return (uint64_t)xTaskGetTickCount();
}

int HAL_GetPartnerID(char *pid_str)
{
    memset(pid_str, 0x0, IOTX_PARTNER_ID_LEN);
    strcpy(pid_str, "c-sdk-3.0.1-pid");
    return strlen(pid_str);
}

int HAL_GetModuleID(char *mid_str)
{
    memset(mid_str, 0x0, IOTX_MODULE_ID_LEN);
    strcpy(mid_str, "c-sdk-3.0.1-mid");
    return strlen(mid_str);
}

int HAL_SetProductKey(char *product_key)
{
    int len = strlen(product_key);

    if (len > IOTX_PRODUCT_KEY_LEN) {
        return -1;
    }
    memset(_product_key, 0x0, IOTX_PRODUCT_KEY_LEN + 1);
    strncpy(_product_key, product_key, len);

    return len;
}

int HAL_SetDeviceName(char *device_name)
{
    int len = strlen(device_name);

    if (len > IOTX_DEVICE_NAME_LEN) {
        return -1;
    }
    memset(_device_name, 0x0, IOTX_DEVICE_NAME_LEN + 1);
    strncpy(_device_name, device_name, len);

    return len;
}

int HAL_SetProductSecret(char *product_secret)
{
    int len = strlen(product_secret);

    if (len > IOTX_PRODUCT_SECRET_LEN) {
        return -1;
    }
    memset(_product_secret, 0x0, IOTX_PRODUCT_SECRET_LEN + 1);
    strncpy(_product_secret, product_secret, len);

    return len;
}

int HAL_SetDeviceSecret(char *device_secret)
{
    int len = strlen(device_secret);

    if (len > IOTX_DEVICE_SECRET_LEN) {
        return -1;
    }
    memset(_device_secret, 0x0, IOTX_DEVICE_SECRET_LEN + 1);
    strncpy(_device_secret, device_secret, len);

    return len;
}

/**
 * @brief Get product key from user's system persistent storage
 *
 * @param [ou] product_key: array to store product key, max length is IOTX_PRODUCT_KEY_LEN
 * @return  the actual length of product key
 */
int HAL_GetProductKey(char product_key[IOTX_PRODUCT_KEY_LEN + 1])
{
    int len = strlen(_product_key);
    memset(product_key, 0x0, IOTX_PRODUCT_KEY_LEN + 1);

    strncpy(product_key, _product_key, len);

    return len;
}

/**
 * @brief Get device name from user's system persistent storage
 *
 * @param [ou] device_name: array to store device name, max length is IOTX_DEVICE_NAME_LEN
 * @return the actual length of device name
 */
int HAL_GetDeviceName(char device_name[IOTX_DEVICE_NAME_LEN + 1])
{
    int len = strlen(_device_name);
    memset(device_name, 0x0, IOTX_DEVICE_NAME_LEN + 1);

    strncpy(device_name, _device_name, len);

    return strlen(device_name);
}

/**
 * @brief Get product secret from user's system persistent storage
 *
 * @param [ou] product_secret: array to store product secret, max length is IOTX_PRODUCT_SECRET_LEN
 * @return the actual length of product secret
 */
int HAL_GetProductSecret(char product_secret[IOTX_PRODUCT_SECRET_LEN + 1])
{
    int len = strlen(_product_secret);
    memset(product_secret, 0x0, IOTX_PRODUCT_SECRET_LEN + 1);

    strncpy(product_secret, _product_secret, len);

    return len;
}

/**
 * @brief Get device secret from user's system persistent storage
 *
 * @param [ou] device_secret: array to store device secret, max length is IOTX_DEVICE_SECRET_LEN
 * @return the actual length of device secret
 */
int HAL_GetDeviceSecret(char device_secret[IOTX_DEVICE_SECRET_LEN + 1])
{
    int len = strlen(_device_secret);
    memset(device_secret, 0x0, IOTX_DEVICE_SECRET_LEN + 1);

    strncpy(device_secret, _device_secret, len);

    return len;
}

extern void sys_reset(void);
void HAL_Reboot(void)
{
    sys_reset();
}

#include "netif.h"
extern struct netif xnetif[];
unsigned char* LwIP_GetIP(struct netif *pnetif);
uint32_t HAL_Wifi_Get_IP(char ip_str[NETWORK_ADDR_LEN], const char *ifname)
{
    strncpy(ip_str, (const char *)LwIP_GetIP(&xnetif[0]),NETWORK_ADDR_LEN);
}

/**
 * @brief Get firmware version
 *
 * @param [ou] version: array to store firmware version, max length is IOTX_FIRMWARE_VER_LEN
 * @return the actual length of firmware version
 */
int HAL_GetFirmwareVersion(char *version)
{
    int len = strlen(_firmware_version);
    memset(version, 0x0, IOTX_FIRMWARE_VER_LEN);
    strncpy(version, _firmware_version, IOTX_FIRMWARE_VER_LEN);
    version[len] = '\0';
    return strlen(version);
}

typedef struct
{
	uint8_t              used;
    uint8_t              running;
    uint32_t             leftms;
    uint32_t             interval;
	timer_callback       callback;
	void				*callback_arg;
}HalTmrHandle_S;

static HalTmrHandle_S  g_hal_timer_array[16];
static void *          g_timer_taskid = NULL;
static void *          g_timer_mutex = NULL;

void *HAL_Timer_Task(void *para)
{
    uint64_t lasttick = HAL_UptimeMs();

    (void)para;

    while (1) {
        uint8_t i;

        //update left
        uint64_t passed = HAL_UptimeMs() - lasttick;
        for (i = 0; i < 16; i++) {
            if (TRUE != g_hal_timer_array[i].used || TRUE != g_hal_timer_array[i].running) {
                continue;
            }

            HAL_MutexLock(g_timer_mutex);
            if (g_hal_timer_array[i].leftms <= passed) {
                g_hal_timer_array[i].leftms = 0;
            } else {
                g_hal_timer_array[i].leftms -= passed;
            }
            HAL_MutexUnlock(g_timer_mutex);

            if (0 == g_hal_timer_array[i].leftms) {
                //HAL_TRACE("timer timeout, ind:%d, arg_pointer:%p", i, g_hal_timer_array[i].callback_arg);
                HAL_MutexLock(g_timer_mutex);
                g_hal_timer_array[i].leftms  = g_hal_timer_array[i].interval;
                g_hal_timer_array[i].running = FALSE;
                HAL_MutexUnlock(g_timer_mutex);

                if (NULL != g_hal_timer_array[i].callback) {
                    g_hal_timer_array[i].callback(g_hal_timer_array[i].callback_arg);
                }
            }
        }

        lasttick += passed;
        HAL_SleepMs(10);
    }
}

int HAL_Timer_Task_Init(void)
{
    int                   ret;
    int                   stack = NULL;
    hal_os_thread_param_t param;

    memset((void *)g_hal_timer_array, 0, sizeof(g_hal_timer_array));

    g_timer_mutex = HAL_MutexCreate();
    if (NULL == g_timer_mutex) {
        HAL_ERR_TRACE("Timer mutex create failed !!!!");
        return -1;
    }

    memset(&param, 0, sizeof(param));
    param.priority   = 7;
    param.stack_size = 8 * 1024;
    param.name       = "wrap_timer";
    //HAL_TRACE("HAL_ThreadCreate, name:%s", param.name);
    ret = HAL_ThreadCreate(&g_timer_taskid,
                           HAL_Timer_Task,
                           NULL,
                           &param,
                           &stack);
    if (0 != ret) {
        HAL_ERR_TRACE("Timer thread create failed !!!!");
        HAL_MutexDestroy(g_timer_mutex);
        return ret;
    }

    return 0;
}

void *HAL_Timer_Create(const char *name, timer_callback func, void *user_data)
{
    uint8_t i;

    (void)name;

    for (i = 0; i < 16; i++) {
        if (TRUE != g_hal_timer_array[i].used) {
            HAL_MutexLock(g_timer_mutex);
            memset(&g_hal_timer_array[i], 0, sizeof(HalTmrHandle_S));
            g_hal_timer_array[i].callback     = func;
            g_hal_timer_array[i].callback_arg = user_data;
            g_hal_timer_array[i].running      = FALSE;
            g_hal_timer_array[i].used         = TRUE;
            HAL_MutexUnlock(g_timer_mutex);
            //HAL_TRACE("name:%s, ind:%d, arg_pointer:%p", name, i, user_data);
            return &g_hal_timer_array[i];
        }
    }

    HAL_ERR_TRACE("failed");
    return NULL;
}

int HAL_Timer_Start(void *timer, int ms)
{
    HalTmrHandle_S *ptimer = (HalTmrHandle_S *)timer;

    //HAL_TRACE("timer:%p, ms:%d", timer, ms);
    HAL_MutexLock(g_timer_mutex);
    ptimer->interval = ms;
    ptimer->leftms   = ms;
    ptimer->running  = TRUE;
    HAL_MutexUnlock(g_timer_mutex);

    return 0;
}

int HAL_Timer_Stop(void *timer)
{
    HalTmrHandle_S *ptimer = (HalTmrHandle_S *)timer;

    HAL_MutexLock(g_timer_mutex);
    ptimer->running = FALSE;
    HAL_MutexUnlock(g_timer_mutex);

    return 0;
}

int HAL_Timer_Delete(void *timer)
{
    HalTmrHandle_S *ptimer = (HalTmrHandle_S *)timer;

    HAL_MutexLock(g_timer_mutex);
    ptimer->used = FALSE;
    HAL_MutexUnlock(g_timer_mutex);

    return 0;
}




