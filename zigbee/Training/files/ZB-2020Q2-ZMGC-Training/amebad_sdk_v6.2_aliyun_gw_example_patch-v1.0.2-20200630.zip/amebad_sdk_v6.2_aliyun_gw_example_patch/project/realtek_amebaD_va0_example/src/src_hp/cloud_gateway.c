#include <stdbool.h>
#include "cloud_gateway.h"
#include "cloud_gateway_interface.h"

#if BOARD_IO_ENABLE && CLOUD_GATEWAY_ENABLE
// button polling and handle
#define KEY_POLLING_INTERVAL        40 //ms
#define ZIGBEE_PERMIT_JOIN_TIMEOUT  180 //seconds
#endif

#if CLOUD_GATEWAY_ENABLE

#define USER_EXAMPLE_YIELD_TIMEOUT_MS 200
#define EXAMPLE_SUBDEV_ADD_NUM 4
#define EXAMPLE_SUBDEV_MAX_NUM 4
#define DEV_INFO_META_MAX_LEN EXAMPLE_SUBDEV_ADD_NUM

// flash
#define FLASH_STORE_START_TAG_CLOUD     0xD3ADBE3F
#define FLASH_STORE_END_TAG_CLOUD       0xB33FDEAD
#define FLASH_ADDR_DEV_PROD_TYPE_START  0x3E0000

/*********************************************************************************
 * typedef
 ********************************************************************************/
/*
 * Message structure for cloud msg.
 */
typedef enum {
    CLOUD_CREATE_NWK,
    CLOUD_LEAVE_NWK,
    CLOUD_PERMIT_JOIN,
    CLOUD_CLOSE_JOIN,
    CLOUD_DEL_DEV,
    CLOUD_PROP_SET,
    CLOUD_CMD_MAX,
} FromCloudMsgId_t;

typedef enum {
    CLOUD_PROP_PERMIT_JOIN,
    CLOUD_PROP_ON_OFF,
    CLOUD_PROP_BRIGHTNESS,
    CLOUD_PROP_COLOR_TEMP,
    CLOUD_PROP_MAX,
} FromCloudPropId_t;

typedef enum {
    PRODUCT_TYPE_LIGHT,
    PRODUCT_TYPE_SWITCH,
    PRODUCT_TYPE_MAX,
} ProductType_t;

typedef enum {
    ADD_DEV_PROD_TYPE,
    DEL_DEV_PROD_TYPE,
    DEL_ALL_PROD_TYPE,
} DevProdTypeUpdateOperation_t;

/*
 * Data structure used for from_cloud_msg_t
 */
typedef struct _CloudDelDev_t {
    uint16_t dev_id;
    uint8_t  endpoint;
    EUI64_T  eui64;
} CloudDelDev_t;

typedef struct _cloud_permit_join_t {
    uint8_t install_code[INSTALL_CODE_SIZE_MAX];
    uint8_t install_code_length;
    EUI64_T eui64;
} cloud_permit_join_t;

/*
 * Data structure used for property setting
 */
typedef struct _CloudPropSet_t {
    uint16_t propId;
    uint16_t value;
    uint8_t  endpoint;
    EUI64_T  eui64;
} CloudPropSet_t;

/*
 * Data structure used for dev meta & info
 */
typedef struct {
    EUI64_T                 eui64;
    uint8_t                 prod_type;
    uint8_t                 endpoint;
    uint16_t                deviceid;
    const CLOUD_DEV_META_T *pmeta_info;
} cloud_dev_info_meta_t;

/*
 *  dev type stored in flash used for triple-unit-group assignment after gw reboot
 */
typedef struct _DevProdTypeInfo_t {
    EUI64_T eui64;
    uint8_t prod_type;
    uint8_t valid;
} DevProdTypeInfo_t;

/*
 * Data structure used for cloud GW context
 */
typedef struct {
    int     auto_add_subdev;
    int     master_devid;
    int     cloud_connected;
    int     master_initialized;
    int     subdev_index;
    int     permit_join;
    EUI64_T master_eui64;
    void *g_user_dispatch_thread;
    void *g_cloud_msg_thread;
    void *g_stack_msg_thread;
    int   g_user_dispatch_thread_running;
} user_example_ctx_t;
#endif //CLOUD_GATEWAY_ENABLE

/*********************************************************************************
*	global
*********************************************************************************/
/*
 * thread handle
 */
void *cloud_gateway_init_thread_handle = NULL;

#if !CLOUD_GATEWAY_ENABLE
char _product_key[IOTX_PRODUCT_KEY_LEN + 1];
char _product_secret[IOTX_PRODUCT_SECRET_LEN + 1];
char _device_name[IOTX_DEVICE_NAME_LEN + 1];
char _device_secret[IOTX_DEVICE_SECRET_LEN + 1];
#else
/*
 * context
 */
static user_example_ctx_t g_user_example_ctx;

/*
 * for storing the dev info and meta pairs
 */
cloud_dev_info_meta_t dev_info_meta[DEV_INFO_META_MAX_LEN];
char *product_type_cloud_define[PRODUCT_TYPE_MAX] = {
    "a1cSTtZ7TXM",
    "a1pDuSGqiOf",
};
DevProdTypeInfo_t dev_prod_type_4_bkp[EXAMPLE_SUBDEV_ADD_NUM];

/*
 * pre-defined gateway meta info
 */
#if defined(EXT_TRIPLE_ELEMENT_GROUP)
#include "ext_triple_element.h"
#else

// Silabs Z3 gateway example 3-element-group for https://living.aliyun.com
/*** Please substitude your gateway 3-element-goup Here ***/ 
#ifdef DYNAMIC_REGISTER
char _product_key[IOTX_PRODUCT_KEY_LEN + 1]       = "a1ZETBPbycq";
char _product_secret[IOTX_PRODUCT_SECRET_LEN + 1] = "L68wCVXYUaNg1Ey9";
char _device_name[IOTX_DEVICE_NAME_LEN + 1]       = "example1";
char _device_secret[IOTX_DEVICE_SECRET_LEN + 1]   = "";
#else
    #ifdef DEVICE_MODEL_ENABLED
    char _product_key[IOTX_PRODUCT_KEY_LEN + 1]       = "a1VtEtCqVsx";
    char _product_secret[IOTX_PRODUCT_SECRET_LEN + 1] = "bbr85gLslEx0GSYn";
    char _device_name[IOTX_DEVICE_NAME_LEN + 1]       = "alink_gw_0001";
    char _device_secret[IOTX_DEVICE_SECRET_LEN + 1]   = "IoL5eEaE1YoC3vZWeEEnuUP7HrrpDw8F";
    #else
    char _product_key[IOTX_PRODUCT_KEY_LEN + 1]       = "a1MZxOdcBnO";
    char _product_secret[IOTX_PRODUCT_SECRET_LEN + 1] = "h4I4dneEFp7EImTv";
    char _device_name[IOTX_DEVICE_NAME_LEN + 1]       = "test_01";
    char _device_secret[IOTX_DEVICE_SECRET_LEN + 1]   = "t9GmMf2jb3LgWfXBaZD2r3aJrfVWBv56";
    #endif
#endif

/*
 * pre-defined dev meta
 */
// Silabs Z3 device example 3-element-gourps for https://living.aliyun.com
const CLOUD_DEV_META_T subdevArr[EXAMPLE_SUBDEV_MAX_NUM] = {
    {
        "a1cSTtZ7TXM",
        "66HP98S8G6f5GlrB",
        "alilink_light_0001",
        "ys3PgPFBuFoSpizlhxSJSQL5WIl3XYG4",
    },
    {
        "a1cSTtZ7TXM",
        "66HP98S8G6f5GlrB",
        "alilink_light_0002",
        "MQeuOAymX7IgeDARtAlWx4IiRCzArzpP",
    },
    {
        "a1cSTtZ7TXM",
        "66HP98S8G6f5GlrB",
        "alilink_light_0003",
        "1O8A5lI1DtjbaPfa2TD5dnRzvw1o1A4r",
    },
    {
        "a1pDuSGqiOf",
        "T0IWt2HYZqfhzFHK",
        "alink_wallswitch_0001",
        "2egYRt9PlIZNeL5yMKcVsKLIXAGUxvAq",
    },
};
#endif //EXT_TRIPLE_ELEMENT_GROUP
#endif //CLOUD_GATEWAY_ENABLE

#if BOARD_IO_ENABLE && CLOUD_GATEWAY_ENABLE
static uint8_t g_f_permit_join;
static uint8_t g_f_close_join;
static uint8_t g_f_factory_rst;
static uint8_t g_f_factory_rst_zigbee;
static uint8_t g_f_factory_rst_state;
static uint32_t g_zigbee_pjoin_count;

void *button_polling_thread_handle = NULL;

/*
 * forward declaraion
 */
static user_example_ctx_t *user_example_get_ctx(void);
static int16_t permit_join(void *data);
static int16_t close_join(void *data);
static int16_t leave_nwk(void *data);
static int16_t form_nwk(void *data);
static int16_t dev_logout(uint16_t devid, bool f_del_topo);
static void user_post_property(uint16_t devid, char *property_payload);

/*********************************************************************************
*	Button polling thread and handle
*********************************************************************************/
static void button_evt_polloing_center(void)
{
    // button polling and handle any key events
    switch(get_button_poll_event(KEY_POLLING_INTERVAL)) {
        case KEY_CONFIG_PRESSED:
            if (!(user_example_get_ctx()->permit_join)) {
                USER_TRACE("Key-event: permit join\n");
                g_f_permit_join = 1;
                g_zigbee_pjoin_count = ZIGBEE_PERMIT_JOIN_TIMEOUT*1000/KEY_POLLING_INTERVAL;
            } else {
                USER_TRACE("Key-event: close join\n");
                //close join
                g_f_close_join = 1;
            }
            break;
        case KEY_CONFIG_PRESSING_3S:
            led_control(LED_FATCTORY_RESET_ZIGBEE_STARTUP);
            break;
        case KEY_CONFIG_PRESSED_HELD_3S:
            g_f_factory_rst_state = 1;
            //close join if network openned
            if (user_example_get_ctx()->permit_join) {
                g_f_close_join = 1;
            }
            led_control(LED_FATCTORY_RESET_ZIGBEE);
            USER_TRACE("Key-event: FactoryReset Zigbee\n");
            g_f_factory_rst_zigbee = 1;
            break;
        case KEY_CONFIG_PRESSED_HELD_8S:
            g_f_factory_rst_state = 1;
            //close join if network openned
            if (user_example_get_ctx()->permit_join) {
                g_f_close_join = 1;
            }
            led_control(LED_FATCTORY_RESET_ZIGBEE_WIFI_STARTUP);
            USER_TRACE("Key-event: FactoryReset Zigbee and WiFi\n");
            g_f_factory_rst = 1;
            break;
        default:
            break;
    };

    // zigbee permit join timeout handle
    if (user_example_get_ctx()->permit_join && g_zigbee_pjoin_count > 0) {
        if (--g_zigbee_pjoin_count == 0) {
            USER_TRACE("PermitJoin timout\n");
            //close join
            g_f_close_join = 1;
        }
    }
}

static void reload_pjoin_timer(void)
{
    g_zigbee_pjoin_count = ZIGBEE_PERMIT_JOIN_TIMEOUT*1000/KEY_POLLING_INTERVAL;
}

static void *button_poling_thread(void *arg)
{
    /*Wait WIFI init complete*/
    while (is_wifi_connected() == false) {
        thread_sleep_ms(500);
    }
    while (true) {
        if (!g_f_factory_rst_state) {
            button_evt_polloing_center();
        }
        // sleep for poll interval
        thread_sleep_ms(KEY_POLLING_INTERVAL);
    }

    USER_TRACE("button_polling_thread exit!\n");
    thread_delete(button_polling_thread_handle);

    return NULL;
}

static void button_evt_hdl(void)
{
    cloud_permit_join_t zigbee_pjoin;
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    if (g_f_permit_join) {
        g_f_permit_join = 0;
        //permit join using default global link-key
        zigbee_pjoin.install_code_length = 0;
        permit_join(&zigbee_pjoin);
    }

    if (g_f_close_join) {
        g_f_close_join = 0;
        close_join(NULL);
    }

    if (g_f_factory_rst_zigbee) {
        g_f_factory_rst_zigbee = 0;
        // only reset zigbee nwk.
        leave_nwk(NULL);
        thread_sleep_ms(1500);
        // create nwk
        form_nwk(NULL);
        thread_sleep_ms(200);
        led_control(LED_FATCTORY_RESET_ZIGBEE_END);
        printf("user_example_ctx->cloud_connected:%d", user_example_ctx->cloud_connected);
        if (user_example_ctx->cloud_connected == 1) {
            led_control(LED_CLOUD_CONNECTED);
        }
        if (is_wifi_connected()) {
            led_control(LED_WIFI_CONNECTED);
            // to avoid WIFI LED and ZB LED blinking together
            thread_sleep_ms(500);
        }
        led_control(LED_ZB_NWK_ON);

        g_f_factory_rst_state = 0;
    }

    if (g_f_factory_rst) {
        g_f_factory_rst = 0;
        // for LED: all LEDs remain on for 1s 
        thread_sleep_ms(1000);
        led_control(LED_FATCTORY_RESET_ZIGBEE_WIFI);
        // Force devices leave network and inform cloud.
        // After all devices left, GW leaves network too.
        leave_nwk(NULL);

        dev_logout(user_example_ctx->master_devid, false);

        // erase wifi fastconnect data
        erase_wifi_fastcon_data();

        thread_sleep_ms(1300);
        // create nwk
        form_nwk(NULL);
        thread_sleep_ms(200);
    
        led_control(LED_FATCTORY_RESET_ZIGBEE_WIFI_END);
    }
}
#endif //BOARD_IO_ENABLE && CLOUD_GATEWAY_ENABLE

void start_button_polling(void)
{
#if BOARD_IO_ENABLE && CLOUD_GATEWAY_ENABLE
    int stacksize = 0;
    int res;
    os_thread_params_t button_thread = {OS_THREAD_PRIO_NORMAL, NULL, 1024, 0, "button_polling_thread"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", button_thread.name, button_thread.stack_size, button_thread.priority);
    res = thread_create(&button_polling_thread_handle, button_poling_thread, NULL, &button_thread, &stacksize);
    if (res < 0) {
        USER_TRACE("%s thread_create failed\n", __FUNCTION__);
    }
#endif //BOARD_IO_ENABLE && CLOUD_GATEWAY_ENABLE
}

#if CLOUD_GATEWAY_ENABLE
/*********************************************************************************
*	Utility
*********************************************************************************/
static user_example_ctx_t *user_example_get_ctx(void)
{
    return &g_user_example_ctx;
}

void cloud_permit_join_set_ctx(uint16_t value)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();
    user_example_ctx->permit_join = value;
}

void byte_array_swap(char *data, uint16_t len)
{
    uint16_t i    = 0;
    char     temp = 0;

    for (i = 0; i < len / 2; i++) {
        temp              = data[i];
        data[i]           = data[len - i - 1];
        data[len - i - 1] = temp;
    }
}

static unsigned char convert_hex_char_to_byte(unsigned char c)
{
    if (c >= 'A' && c <= 'F') {
        return c - 'A' + 0x0A;
    } else if (c >= 'a' && c <= 'f') {
        return c - 'a' + 0x0A;
    } else if (c >= '0' && c <= '9') {
        return c - '0';
    }
    return 0xFF;
}

// Transform a string of hex characters into an array of bytes.
// Returns number of bytes parsed on success, or -1 on error.
static int16_t parse_hex_byte_string(char *input_string, char *return_data, int16_t max_byte_length)
{
    uint16_t i;
    int16_t  length = strnlen(input_string, (max_byte_length * 2) + 1  // NULL terminator
                                               + 2);                  // '0x' prefix

    if (length >= 2 && input_string[0] == '0' && (input_string[1] == 'x' || input_string[1] == 'X')) {
        // Skip '0x' prefix
        input_string += 2;
        length -= 2;
    }

    if (length > (max_byte_length * 2)) {
        ERROR_TRACE("Input string cannot be longer than %d\n", max_byte_length * 2);
        return -1;
    }

    if (length % 2 != 0) {
        ERROR_TRACE("Input string must be an even number of hex characters.\n");
        return -1;
    }

    int byte_array_index = 0;
    for (i = 0; i < length; i += 2) {
        unsigned char a = convert_hex_char_to_byte((unsigned char)input_string[i]);
        unsigned char b = convert_hex_char_to_byte((unsigned char)input_string[i + 1]);
        if (a != 0xFF && b != 0xFF) {
            return_data[byte_array_index] = (a << 4) | b;
            byte_array_index++;
        } else {
            ERROR_TRACE("Invalid hex character '%C' for input string\n",
                        (a == 0xFF
                             ? input_string[i]
                             : input_string[i + 1]));
            return -1;
        }
    }
    return length / 2;
}

static int16_t user_master_dev_available(void)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    if (user_example_ctx->cloud_connected && user_example_ctx->master_initialized) {
        return 1;
    }

    return 0;
}

static uint8_t get_dev_prod_type_by_cluster(DevJoined_t *dev_joined, uint8_t *endpoint)
{
    for (uint8_t i = 0; i < dev_joined->endpointNum; i++) {
        for (uint8_t j = 0; j < dev_joined->endPoints[i].clusterNum; j++) {
            if (dev_joined->endPoints[i].clusters[j].clusterId == 6
                && dev_joined->endPoints[i].clusters[j].clusterType == CLIENT) {
                    *endpoint = dev_joined->endPoints[i].endpoint;
                    return PRODUCT_TYPE_SWITCH;
            }
        }
    }
    // default as light
    return PRODUCT_TYPE_LIGHT;
}

static int16_t search_by_dev_info(EUI64_T *eui64, uint8_t endpoint);
static uint8_t get_dev_prod_type_by_eui64(EUI64_T *peui64)
{
    int16_t ind;

    ind = search_by_dev_info(peui64, 1);
    if (-1 == ind) {
        ERROR_TRACE("Can't find the eui64 matched device!");
        return -1;
    }
    return dev_info_meta[ind].prod_type;
}

static uint8_t get_dev_prod_type(char *prod_type_cloud_define)
{
    for (uint8_t i = 0; i < PRODUCT_TYPE_MAX; i++) {
        if (0 == strncmp(prod_type_cloud_define, product_type_cloud_define[i], IOTX_PRODUCT_KEY_LEN)) {
            return i;
        }
    }
    // default as light
    return 0;
}

static void dev_info_meta_init(void)
{
    for (uint16_t i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        dev_info_meta[i].pmeta_info = NULL;
        dev_info_meta[i].prod_type  = get_dev_prod_type(subdevArr[i].product_key);
    }
}

static int16_t search_by_dev_info(EUI64_T *eui64, uint8_t endpoint)
{
    for (uint16_t i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        if (NULL != dev_info_meta[i].pmeta_info && 0 == memcmp(&dev_info_meta[i].eui64,eui64,EUI64_LEN)) {
            //&& dev_info_meta[i].endpoint == endpoint) {  // currently do not consider endpoint

            return i;
        }
    }
    return -1;
}

static int16_t search_by_dev_name(char *name_str, uint16_t const length)
{
    for (uint16_t i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        if (NULL != dev_info_meta[i].pmeta_info && 0 == strncmp((const char *)(dev_info_meta[i].pmeta_info->device_name), (const char *)name_str, length)) {
            return i;
        }
    }
    return -1;
}

static int16_t search_available_meta(uint8_t prod_type)
{
    for (int16_t i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        if (NULL == dev_info_meta[i].pmeta_info && prod_type == dev_info_meta[i].prod_type ) {
            return i;
        }
    }
    return -1;
}

static int16_t cloud_get_dev_address_from_devid(int16_t devid, EUI64_T *peui64, uint8_t *pendpoint)
{
    /*
    int        res = 0;    
    char       product_key[IOTX_PRODUCT_KEY_LEN + 1] = {0};
    char       device_name[IOTX_DEVICE_NAME_LEN + 1] = {0};
    char       device_secret[IOTX_DEVICE_SECRET_LEN + 1] = {0};
    uint8_t   val[EUI64_LEN + 1];

    res = dm_mgr_search_device_by_devid(devid, product_key, device_name, device_secret);
    if (res < SUCCESS_RETURN) {
        return res;
    }

    if (EUI64_LEN + 1 != sscanf(device_name, "%02X%02X%02X%02X%02X%02X%02X%02X_%d", &val[0], &val[1], &val[2], &val[3],
                                                                                     &val[4], &val[5], &val[6], &val[7],
                                                                                     &val[8])) {
        ERROR_TRACE("Invalid devicename=[%s]", device_name);
        return -1;
    }

    eui64.uuid[0] = (uint8_t)val[7];
    eui64.uuid[1] = (uint8_t)val[6];
    eui64.uuid[2] = (uint8_t)val[5];
    eui64.uuid[3] = (uint8_t)val[4];
    eui64.uuid[4] = (uint8_t)val[3];
    eui64.uuid[5] = (uint8_t)val[2];
    eui64.uuid[6] = (uint8_t)val[1];
    eui64.uuid[7] = (uint8_t)val[0];
    *pendpoint = (uint8_t)val[8];

    return 0;
    */
    for (uint16_t i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        //printf("i:%d, devid:%d, dev_info_meta[i].deviceid:%d\n",i, devid, dev_info_meta[i].deviceid);
        if (devid == dev_info_meta[i].deviceid) {
            memcpy(peui64, &dev_info_meta[i].eui64, EUI64_LEN);
            *pendpoint = dev_info_meta[i].endpoint;
            return 0;
        }
    }
    return -1;
}

int16_t get_devid_by_eui(EUI64_T *peui64)
{
    int16_t ind = search_by_dev_info(peui64, 0);
    if (ind == -1) {
        ERROR_TRACE("Can't find the eui64 matched device!");
        return -1;
    }
    return dev_info_meta[ind].deviceid;
}

static uint8_t get_dev_prod_type_from_bkp(EUI64_T *peui64)
{
    uint8_t prod_type = PRODUCT_TYPE_MAX;

    for (uint16_t i = 0; i < EXAMPLE_SUBDEV_ADD_NUM; i++) {
        if (0 == memcmp(&dev_prod_type_4_bkp[i].eui64, peui64, EUI64_LEN)
            && dev_prod_type_4_bkp[i].valid == 1) {
            prod_type = dev_prod_type_4_bkp[i].prod_type;
            break;
        }
    }

    if (prod_type >= PRODUCT_TYPE_MAX) {
        prod_type = PRODUCT_TYPE_LIGHT;
        ERROR_TRACE("Can't find the eui64 matched device or prod type out of range! Force it to be LIGHT.");
    }
    return prod_type;
}

static void dev_prod_type_save(void)
{
    flash_t flash;
    uint32_t tag, startAddr, bufferSize;
    tag = FLASH_STORE_START_TAG_CLOUD;
    startAddr = FLASH_ADDR_DEV_PROD_TYPE_START;
    device_mutex_lock(RT_DEV_LOCK_FLASH);
    flash_erase_sector(&flash, startAddr);
    flash_stream_write(&flash, startAddr, 4, (uint8_t *)&tag);
    startAddr += 4;
    bufferSize = sizeof(dev_prod_type_4_bkp);
    USER_TRACE("write buf size: %d\r\n", bufferSize);
    flash_stream_write(&flash,
                        startAddr,
                        bufferSize,
                        dev_prod_type_4_bkp);
    startAddr += bufferSize;
    tag = FLASH_STORE_END_TAG_CLOUD;
    flash_stream_write(&flash, startAddr, 4, (uint8_t *)&tag);
    device_mutex_unlock(RT_DEV_LOCK_FLASH);
}

static void dev_prod_type_store_update(EUI64_T *peui64, uint8_t prodType, uint8_t operation)
{
    int16_t i;
    int8_t need_flash = -1;
    int16_t ind_same  = -1;
    int16_t ind_empty = -1;

    if (operation == ADD_DEV_PROD_TYPE) {
        for (i = 0; i < EXAMPLE_SUBDEV_ADD_NUM; i++) {
            // chk if there's already the same dev in the bkp
            if (0 == memcmp(&dev_prod_type_4_bkp[i].eui64, peui64, EUI64_LEN)
                && dev_prod_type_4_bkp[i].valid == 1) {
                ind_same = i;
                break;
            }
            // search for the 1st empty place
            if (ind_empty == -1) {
                if (dev_prod_type_4_bkp[i].valid == 0) {
                    ind_empty = i;
                }
            }
        }
        if (ind_same != -1) {
            USER_TRACE("Found the same eui64, ind: %d, prod type: %d", ind_same, prodType);
            if (dev_prod_type_4_bkp[ind_same].prod_type != prodType) {
                dev_prod_type_4_bkp[ind_same].prod_type = prodType;
                need_flash                      =  1;
            }
        } else if (ind_empty != -1) {
            USER_TRACE("Found empty place for storing, ind: %d, prod type: %d", ind_empty, prodType);
            memcpy(&dev_prod_type_4_bkp[ind_empty].eui64, peui64, EUI64_LEN);
            dev_prod_type_4_bkp[ind_empty].prod_type = prodType;
            dev_prod_type_4_bkp[ind_empty].valid    = 1;
            need_flash                      = 1;
        } else {
            ERROR_TRACE("Can't find empty place for storing");
        }
    } else if (operation == DEL_DEV_PROD_TYPE) {
        for (i = 0; i < EXAMPLE_SUBDEV_ADD_NUM; i++) {
            if (0 == memcmp(&dev_prod_type_4_bkp[i].eui64, peui64, EUI64_LEN)
                && dev_prod_type_4_bkp[i].valid == 1) {
                dev_prod_type_4_bkp[i].valid = 0;
                need_flash = 1;
            }
        }
    } else {
        memset((char *)dev_prod_type_4_bkp, 0, sizeof(dev_prod_type_4_bkp));
        need_flash = 1;
    }
    if (need_flash == 1) {
        dev_prod_type_save();
    }

    //for (i = 0; i < EXAMPLE_SUBDEV_ADD_NUM; i++) {
    //    USER_TRACE("dev EUI64: %x%x%x%x%x%x%x%x, prod: %d, valid: %d", dev_prod_type_4_bkp[i].eui64.uuid[0], dev_prod_type_4_bkp[i].eui64.uuid[1],
    //               dev_prod_type_4_bkp[i].eui64.uuid[2],dev_prod_type_4_bkp[i].eui64.uuid[3],dev_prod_type_4_bkp[i].eui64.uuid[4],
    //               dev_prod_type_4_bkp[i].eui64.uuid[5],dev_prod_type_4_bkp[i].eui64.uuid[6],dev_prod_type_4_bkp[i].eui64.uuid[7],
    //               dev_prod_type_4_bkp[i].prod_type, dev_prod_type_4_bkp[i].valid);
    //}
}

static void dev_prod_type_load(void)
{
    flash_t flash;
    uint32_t tag, startAddr;

    startAddr = FLASH_ADDR_DEV_PROD_TYPE_START;
    device_mutex_lock(RT_DEV_LOCK_FLASH);
    flash_stream_read(&flash, startAddr, 4, (uint8_t *)&tag);
    if (tag != FLASH_STORE_START_TAG_CLOUD) {
        ERROR_TRACE("Wrong start tag\r\n");
        device_mutex_unlock(RT_DEV_LOCK_FLASH);
        return;
    }

    startAddr += 4;
    flash_stream_read(&flash,
                      startAddr,
                      sizeof(dev_prod_type_4_bkp),
                      dev_prod_type_4_bkp);

    startAddr += sizeof(dev_prod_type_4_bkp);
    flash_stream_read(&flash, startAddr, 4, (uint8_t *)&tag);
    device_mutex_unlock(RT_DEV_LOCK_FLASH);

    if (tag != FLASH_STORE_END_TAG_CLOUD) {
        ERROR_TRACE("Wrong end tag\r\n");
    }

    for (int8_t i = 0; i < EXAMPLE_SUBDEV_ADD_NUM; i++) {
        USER_TRACE("dev EUI64: %x%x%x%x%x%x%x%x, prod: %d, valid: %d", dev_prod_type_4_bkp[i].eui64.uuid[0], dev_prod_type_4_bkp[i].eui64.uuid[1],
                   dev_prod_type_4_bkp[i].eui64.uuid[2],dev_prod_type_4_bkp[i].eui64.uuid[3],dev_prod_type_4_bkp[i].eui64.uuid[4],
                   dev_prod_type_4_bkp[i].eui64.uuid[5],dev_prod_type_4_bkp[i].eui64.uuid[6],dev_prod_type_4_bkp[i].eui64.uuid[7],
                   dev_prod_type_4_bkp[i].prod_type, dev_prod_type_4_bkp[i].valid);
    }

} 

/*********************************************************************************
*	Forward property setting msg to cloud msg center
*********************************************************************************/
static int16_t cloud_property_set(uint16_t prop_id, int16_t devid, uint16_t value, bool f_fill_id)
{
    int16_t         res = 0;
    EUI64_T         eui64;
    uint8_t         endpoint;
    CloudPropSet_t *data = NULL;

    if (f_fill_id) {
        res = cloud_get_dev_address_from_devid(devid, &eui64, &endpoint);
        if (0 != res) {
            ERROR_TRACE("get zigbee address fail");
            return res;
        }
    }

    data = user_malloc(sizeof(CloudPropSet_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed");
        return -1;
    }
    memset(data, 0, sizeof(CloudPropSet_t));
    data->propId = prop_id;
    data->value  = value;
    if (f_fill_id) {
        data->endpoint = endpoint;
        memcpy(&data->eui64, &eui64, EUI64_LEN);
    }

    if (sendMsg((void *)data, CLOUD_PROP_SET, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }

    return 0;
}

static int16_t cloud_lightswitch_property_set(int devid, lite_cjson_t *item)
{
    USER_TRACE("To send msg to cloud msg center to set light switch: dev_id:%d, on_off:%d\n", devid, item->value_int);
    if (cloud_property_set(CLOUD_PROP_ON_OFF, devid, item->value_int, true) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

static int16_t cloud_brightness_property_set(int devid, lite_cjson_t *item)
{
    uint16_t val;
    uint8_t  brightness;

    val        = item->value_int;
    brightness = (uint8_t)(val * 255.0 / 100);

    USER_TRACE("To send msg to cloud msg center to set brightness: dev_id:%d, brightness:%d\n", devid, brightness);
    if (cloud_property_set(CLOUD_PROP_BRIGHTNESS, devid, brightness, true) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

static int16_t cloud_colorTemperature_property_set(int devid, lite_cjson_t *item)
{
    uint16_t val = 0;
    uint16_t colortemp;

    val = item->value_int;
    if (val == 0) {
        ERROR_TRACE("invalid value");
        return -1;
    }

    colortemp = (int16_t)(1000000 / val);

    USER_TRACE("To send msg to cloud msg center to set colortemp: dev_id:%d, colortemp:%d\n", devid, colortemp);
    if (cloud_property_set(CLOUD_PROP_COLOR_TEMP, devid, colortemp, true) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

static int16_t cloud_permit_joining_property_set(int devid, lite_cjson_t *item)
{
    uint16_t val = 0;

    val = item->value_int;

    USER_TRACE("To send msg to cloud msg center to set permit_join: dev_id:%d, permit_join:%d\n", devid, val);
    if (cloud_property_set(CLOUD_PROP_PERMIT_JOIN, devid, val, false) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

/*********************************************************************************
*	Forward service request msg to cloud msg center
*********************************************************************************/
static int16_t cloud_del_dev(char *name_str, int16_t const length)
{
    CloudDelDev_t *data = NULL;
    int16_t        ind  = search_by_dev_name(name_str, length);
    if (ind == -1) {
        ERROR_TRACE("Can't find the name matched device!");
        return -1;
    }
    USER_TRACE("To send msg to cloud msg center to del dev: %s\n", name_str);

    data = user_malloc(sizeof(CloudDelDev_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memcpy(&data->eui64, &dev_info_meta[ind].eui64, EUI64_LEN);
    data->dev_id   = dev_info_meta[ind].deviceid;
    data->endpoint = dev_info_meta[ind].endpoint;

    if (sendMsg((void *)data, CLOUD_DEL_DEV, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }

    dev_info_meta[ind].pmeta_info = NULL;
    return 0;
}

static int16_t cloud_form_nwk(void)
{
    USER_TRACE("To send msg to cloud msg center to form a network.");

    if (sendMsg((void *)NULL, CLOUD_CREATE_NWK, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

static int16_t cloud_leave_nwk(void)
{
    USER_TRACE("To send msg to cloud msg center to leave a network.");

    if (sendMsg((void *)NULL, CLOUD_LEAVE_NWK, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

static int16_t cloud_permit_join(char *install_code_str, int16_t code_length, char *eui64_str, int16_t eui64_length)
{
    USER_TRACE("To send msg to cloud msg center to permit joining\n");

    cloud_permit_join_t *data = NULL;
    uint16_t             install_code_len, eui64_len;
    uint8_t              install_code_string[INSTALL_CODE_STRING_SIZE_MAX];
    uint8_t              eui64_string[EUI64_STRING_SIZE];

    data = user_malloc(sizeof(cloud_permit_join_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memset(data, 0, sizeof(cloud_permit_join_t));

    if (0 != code_length) {
        if (install_code_str == NULL || eui64_str == NULL) {
            ERROR_TRACE("Input pointer is NULL!");
            user_free(data);
            return -1;
        }
        if (code_length >= INSTALL_CODE_STRING_SIZE_MAX) {
            ERROR_TRACE("install code string length is longer than expected:%d", code_length);
            user_free(data);
            return -1;
        }
        if (eui64_length >= EUI64_STRING_SIZE) {
            ERROR_TRACE("eui64 string length is longer than expected:%d", eui64_length);
            user_free(data);
            return -1;
        }
        memset(install_code_string, 0, INSTALL_CODE_STRING_SIZE_MAX);
        memcpy(install_code_string, install_code_str, code_length);
        install_code_len = parse_hex_byte_string((char *)install_code_string, (char *)(data->install_code), INSTALL_CODE_SIZE_MAX);

        if (install_code_len == -1) {
            ERROR_TRACE("Install code parse error.\n");
            user_free(data);
            return -1;
        }

        memset(eui64_string, 0, EUI64_STRING_SIZE);
        memcpy(eui64_string, eui64_str, eui64_length);
        eui64_len = parse_hex_byte_string((char *)eui64_string, (char *)(&data->eui64), EUI64_LEN);
        if (eui64_len != EUI64_LEN) {
            user_free(data);
            ERROR_TRACE("eui64 parsing error.\n");
            return -1;
        }
        // no need to swap
        //byte_array_swap((char *)&data->eui64, EUI64_LEN);
        data->install_code_length = install_code_len;
    } else {
        data->install_code_length = 0;
    }

    if (sendMsg((void *)data, CLOUD_PERMIT_JOIN, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }

    return 0;
}

static int16_t cloud_close_join(void)
{
    USER_TRACE("To send msg to cloud msg center to close joining.");
    //
    if (sendMsg((void *)NULL, CLOUD_CLOSE_JOIN, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }

    return 0;
}

/*********************************************************************************
*	property setting handler used by cloud msg center
*********************************************************************************/
static int16_t lightswitch_property_set(uint16_t value, EUI64_T eui64, uint8_t endpoint)
{
    // send msg to stack
    if (-1 == lightswitch_set_interface(value, eui64, endpoint)) {
        ERROR_TRACE("failed.");
        return -1;
    }
    return 0;
}

static int16_t brightness_property_set(uint16_t value, EUI64_T eui64, uint8_t endpoint)
{
    // send msg to stack
    if (-1 == brightness_set_interface(value, eui64, endpoint)) {
        ERROR_TRACE("failed.");
        return -1;
    }
    return 0;
}

static int16_t colorTemperature_property_set(uint16_t value, EUI64_T eui64, uint8_t endpoint)
{
    // send msg to stack
    if (-1 == colorTemperature_set_interface(value, eui64, endpoint)) {
        ERROR_TRACE("failed.");
        return -1;
    }
    return 0;
}

static int16_t permit_joining_property_set(uint16_t value, EUI64_T eui64, uint8_t endpoint)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();
    // send msg to stack
    if (-1 == permit_join_set_interface(value, eui64, endpoint)) {
        ERROR_TRACE("failed.");
        return -1;
    }
    user_example_ctx->permit_join = value;
    if (value == 1) {
#if BOARD_IO_ENABLE
        reload_pjoin_timer();
#endif
        led_control(LED_ZB_PERMIT_JOIN);
    } else {
        led_control(LED_ZB_CLOSE_JOIN);
    }

    return 0;
}

int16_t (*const property_set_hanle[CLOUD_PROP_MAX])(uint16_t, EUI64_T, uint8_t) = {
    permit_joining_property_set,
    lightswitch_property_set,
    brightness_property_set,
    colorTemperature_property_set,
};

static int16_t property_set(void *data)
{
    CloudPropSet_t *p_prop_set = (CloudPropSet_t *)data;
    if (data == NULL) {
        ERROR_TRACE("data pointer is NULL!");
        return -1;
    }

    if (p_prop_set->propId >= CLOUD_PROP_MAX) {
        ERROR_TRACE("Property ID is out of range: %d", p_prop_set->propId);
        return -1;
    }
    if ((property_set_hanle[p_prop_set->propId])(p_prop_set->value,
                                                 p_prop_set->eui64,
                                                 p_prop_set->endpoint) == -1) {
        ERROR_TRACE("Failed to set property: %d, value: %d", p_prop_set->propId, p_prop_set->value);
        return -1;
    }
    return 0;
}

/*********************************************************************************
*	service request handler used by cloud msg center
*********************************************************************************/
static int16_t dev_logout(uint16_t devid, bool f_del_topo)
{
    int16_t res;
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    // only subdev needs to logout and del topo
    if (user_example_ctx->master_devid != devid) {
        res = iot_cloud_report(devid, TO_CLOUD_MSG_LOGOUT, NULL, 0);

        if (res == FAIL_RETURN) {
            USER_TRACE("subdev logout Failed: devid = %d\n", devid);
            return res;
        }
        USER_TRACE("subdev logout success: devid = %d\n", devid);

        if (f_del_topo) {
            res = iot_cloud_report(devid, TO_CLOUD_MSG_DELETE_TOPO, NULL, 0);
            if (res == FAIL_RETURN) {
                USER_TRACE("subdev del topology Failed: devid = %d\n", devid);
                return res;
            }
            USER_TRACE("subdev del topology success: devid = %d\n", devid);
        }

        if (user_example_ctx->subdev_index > 0) {
            user_example_ctx->subdev_index--;
        }
    }

    res = iot_cloud_close(devid);
    if (res == FAIL_RETURN) {
        USER_TRACE("subdev disconnect Failed\n");
        return res;
    }
    USER_TRACE("subdev disconnect success: devid = %d\n", devid);

    return res;
}

static int16_t del_dev(void *data)
{
    CloudDelDev_t *pdel_dev = (CloudDelDev_t *)data;
    int16_t        res      = 0;
    uint16_t       devid;

    if (data == NULL) {
        ERROR_TRACE("data pointer is NULL!");
        return -1;
    }

    devid = pdel_dev->dev_id;
    USER_TRACE("To send msg to stack to del dev: %d\n", devid);
    del_dev_interface(&pdel_dev->eui64, pdel_dev->endpoint);

    dev_prod_type_store_update(&pdel_dev->eui64, NULL, DEL_DEV_PROD_TYPE);

    // logout and del topo
    res = dev_logout(devid, true);

    if (res == FAIL_RETURN) {
        USER_TRACE("subdev Failed: devid = %d\n", devid);
        return res;
    }

    return 0;
}

static int16_t form_nwk(void *data)
{
    USER_TRACE("To send msg to stack to form a network.");
    //
    form_network_interface();

    return 0;
}

static int16_t leave_nwk(void *data)
{
    USER_TRACE("To send msg to stack to leave a network.");
    //
    leave_network_interface();

    dev_prod_type_store_update(NULL, NULL, DEL_ALL_PROD_TYPE);

    // logout all dev and del topo
    for (uint16_t i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        if (NULL != dev_info_meta[i].pmeta_info) {
            USER_TRACE("devid = %d\n", dev_info_meta[i].deviceid);
            if (FAIL_RETURN == dev_logout(dev_info_meta[i].deviceid, true)) {
                USER_TRACE("logout dev Failed: devid = %d\n", dev_info_meta[i].deviceid);
            }
            dev_info_meta[i].pmeta_info = NULL;
        }
    }

    return 0;
}

static int16_t permit_join(void *data)
{
    cloud_permit_join_t *ppermit_join = (cloud_permit_join_t *)data;

    if (data == NULL) {
        ERROR_TRACE("data pointer is NULL!");
        return -1;
    }

    USER_TRACE("To send msg to stack to permit joining.");
    permit_join_interface(ppermit_join->install_code_length, (uint8_t *)&ppermit_join->install_code, &ppermit_join->eui64);

    user_example_ctx_t *user_example_ctx = user_example_get_ctx();
    user_example_ctx->permit_join        = 1;
#if BOARD_IO_ENABLE
    reload_pjoin_timer();
#endif
    led_control(LED_ZB_PERMIT_JOIN);

    return 0;
}

static int16_t close_join(void *data)
{
    USER_TRACE("To send msg to stack to close joining.");
    close_join_interface();

    user_example_ctx_t *user_example_ctx = user_example_get_ctx();
    user_example_ctx->permit_join        = 0;
    led_control(LED_ZB_CLOSE_JOIN);

    return 0;
}

/*********************************************************************************
*	Cloud event handler
*********************************************************************************/
int user_connected_event_handler(void)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    USER_TRACE("Cloud Connected");

    user_example_ctx->cloud_connected = 1;
    led_control(LED_CLOUD_CONNECTED);

    // workaround sub-devices offline after cloud disconnected then reconnected
    for (int i = 0; i < DEV_INFO_META_MAX_LEN; i++) {
        if (NULL != dev_info_meta[i].pmeta_info) {
            USER_TRACE("%s devid=%d send AOS active to cloud...",
                dev_info_meta[i].pmeta_info->device_name,
                dev_info_meta[i].deviceid);
            iotx_dm_send_aos_active(dev_info_meta[i].deviceid);
        }
    }

    return 0;
}

int user_disconnected_event_handler(void)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    USER_TRACE("Cloud Disconnected");
    led_control(LED_CLOUD_DISCONNECTED);

    user_example_ctx->cloud_connected = 0;

    return 0;
}

int user_property_set_event_handler(const int devid, const char *request, const int request_len)
{
    USER_TRACE("Property Set Received, Devid: %d, Request: %s", devid, request);

    int     res = 0;

    CJSON_T lite, lite_item_id;

    /* Parse Root */
    memset(&lite, 0, sizeof(lite_cjson_t));
    res = cloud_cjson_parse(request, request_len, &lite);
    if (res != SUCCESS_RETURN || !cloud_cjson_is_object(&lite)) {
        USER_TRACE("JSON Parse Error");
        return -1;
    }

    /* light switch  */
    memset(&lite_item_id, 0, sizeof(lite_cjson_t));
    res = cloud_cjson_object_item(&lite, "LightSwitch", strlen("LightSwitch"),
                                  &lite_item_id);
    if (res == SUCCESS_RETURN && cloud_cjson_is_number(&lite_item_id)) {
        cloud_lightswitch_property_set(devid, &lite_item_id);
    }

    /* Brightness  */
    memset(&lite_item_id, 0, sizeof(lite_cjson_t));
    res = cloud_cjson_object_item(&lite, "Brightness", strlen("Brightness"),
                                  &lite_item_id);
    if (res == SUCCESS_RETURN && cloud_cjson_is_number(&lite_item_id)) {
        cloud_brightness_property_set(devid, &lite_item_id);
    }

    /* ColorTemperature  */
    memset(&lite_item_id, 0, sizeof(lite_cjson_t));
    res = cloud_cjson_object_item(&lite, "ColorTemperature", strlen("ColorTemperature"),
                                  &lite_item_id);
    if (res == SUCCESS_RETURN && cloud_cjson_is_number(&lite_item_id)) {
        cloud_colorTemperature_property_set(devid, &lite_item_id);
    }

    /* permit_joining  */
    memset(&lite_item_id, 0, sizeof(lite_cjson_t));
    res = cloud_cjson_object_item(&lite, "permit_joining", strlen("permit_joining"),
                                  &lite_item_id);
    if (res == SUCCESS_RETURN && cloud_cjson_is_number(&lite_item_id)) {
        cloud_permit_joining_property_set(devid, &lite_item_id);
    }

    res = iot_cloud_report(devid, TO_CLOUD_MSG_POST_PROPERTY,
                           (unsigned char *)request, request_len);

    USER_TRACE("Post Property Message ID: %d", res);

    return res;
}

int user_report_reply_event_handler(const int devid, const int msgid, const int code,
                                    const char *reply, const int reply_len)
{
    const char *reply_value     = (reply == NULL) ? ("NULL") : (reply);
    const int   reply_value_len = (reply_len == 0) ? (strlen("NULL")) : (reply_len);
 
    char *reply_data_str = user_malloc(reply_value_len + 1);
    if (reply_data_str == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memset(reply_data_str, 0, reply_value_len + 1);
    strncpy(reply_data_str, reply_value, reply_value_len);

    USER_TRACE("Message Post Reply Received, Devid: %d, Message ID: %d, Code: %d, Reply: %s", 
               devid, msgid, code, reply_data_str);

    user_free(reply_data_str);
    return 0;
}

int user_timestamp_reply_event_handler(const char *timestamp)
{
    USER_TRACE("Current Timestamp: %s", timestamp);

    return 0;
}

int user_initialized(const int devid)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();
    USER_TRACE("Device Initialized, Devid: %d", devid);

    if (user_example_ctx->master_devid == devid) {
        user_example_ctx->master_initialized = 1;
        user_example_ctx->subdev_index++;
    }

    return 0;
}

int user_permit_join_event_handler(const char *product_key, const int time)
{
    USER_TRACE("To send msg to cloud msg center to permit joining\n");

    cloud_permit_join_t *data = NULL;

    data = user_malloc(sizeof(cloud_permit_join_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memset(data, 0, sizeof(cloud_permit_join_t));

    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    USER_TRACE("Product Key: %s, Time: %d", product_key, time);

    user_example_ctx->permit_join = 1;

    if (sendMsg((void *)data, CLOUD_PERMIT_JOIN, CLOUD_MSG_Q) == -1) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }

    return 0;
}

int user_service_request_event_handler(const int devid, const char *serviceid, const int serviceid_len,
                                       const char *request, const int request_len,
                                       char **response, int *response_len)
{
    char *serviceid_data_str = user_malloc(serviceid_len + 1);
    if (serviceid_data_str == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memset(serviceid_data_str, 0, serviceid_len + 1);
    strncpy(serviceid_data_str, serviceid, serviceid_len);

    USER_TRACE("Service Request Received, Service ID: %s, Payload: %s", serviceid_data_str, request);
    user_free(serviceid_data_str);

    int16_t      res = 0;
    lite_cjson_t lite, lite_item_id;

    /* Parse Root */
    memset(&lite, 0, sizeof(lite_cjson_t));
    res = cloud_cjson_parse(request, request_len, &lite);
    if (res != SUCCESS_RETURN || !cloud_cjson_is_object(&lite)) {
        USER_TRACE("JSON Parse Error");
        return -1;
    }

    if (strlen("form_nwk") == serviceid_len && memcmp("form_nwk", serviceid, serviceid_len) == 0) {
        cloud_form_nwk();

    } else if (strlen("leave_nwk") == serviceid_len && memcmp("leave_nwk", serviceid, serviceid_len) == 0) {
        cloud_leave_nwk();

    } else if (strlen("del_dev") == serviceid_len && memcmp("del_dev", serviceid, serviceid_len) == 0) {
        /* Parse parameter */
        res = cloud_cjson_object_item(&lite, "dev_name", strlen("dev_name"), &lite_item_id);
        if (res != SUCCESS_RETURN || !cloud_cjson_is_string(&lite_item_id)) {
            return -1;
        }
        //printf("lite_item_id.value_length:%d, lite_item_id.value:%s\n", lite_item_id.value_length, lite_item_id.value);
        USER_TRACE("dev_name: %*s", lite_item_id.value_length, lite_item_id.value);

        //
        res = cloud_del_dev(lite_item_id.value, lite_item_id.value_length);
        if (res == FAIL_RETURN) {
            ERROR_TRACE("del_dev Failed\n");
            return res;
        }

    } else if (strlen("permit_join") == serviceid_len && memcmp("permit_join", serviceid, serviceid_len) == 0) {
        /* Parse parameter */
        res = cloud_cjson_object_item(&lite, "install_code", strlen("install_code"), &lite_item_id);
        if (res != SUCCESS_RETURN || !cloud_cjson_is_string(&lite_item_id)) {
            return -1;
        }
        lite_cjson_t lite_item_id2;
        res = cloud_cjson_object_item(&lite, "eui64", strlen("eui64"), &lite_item_id2);
        if (res != SUCCESS_RETURN || !cloud_cjson_is_string(&lite_item_id2)) {
            return -1;
        }
        USER_TRACE("install_code: %*s", lite_item_id.value_length, lite_item_id.value);
        USER_TRACE("eui64: %*s", lite_item_id2.value_length, lite_item_id2.value);

        //
        res = cloud_permit_join(lite_item_id.value, lite_item_id.value_length, lite_item_id2.value, lite_item_id2.value_length);
        if (res == FAIL_RETURN) {
            ERROR_TRACE("permit_join Failed\n");
            return res;
        }

    } else if (strlen("close_join") == serviceid_len && memcmp("close_join", serviceid, serviceid_len) == 0) {
        cloud_close_join();
    }

    return 0;
}

/*********************************************************************************
*	Gateway to Cloud service/feedback handler
*********************************************************************************/
static int16_t example_add_subdev(CLOUD_DEV_META_T *meta_info, uint16_t *pdevid)
{
    int16_t res   = 0;
    int16_t devid = -1;

    devid = iot_cloud_open(IOTX_CLOUD_DEV_TYPE_SLAVE, meta_info);
    USER_TRACE("iot_cloud_open(\"%s\") -> devid=%d", meta_info->device_name, devid);
    if (devid == FAIL_RETURN) {
        USER_TRACE("subdev open Failed\n");
        return FAIL_RETURN;
    }
    USER_TRACE("subdev open succeed, devid = %d\n", devid);

    res = iot_cloud_connect(devid);
    USER_TRACE("iot_cloud_connect(\"%s\") -> %d", meta_info->device_name, res);
    if (res == FAIL_RETURN) {
        USER_TRACE("subdev connect Failed\n");
        return res;
    }
    USER_TRACE("subdev connect success: devid = %d\n", devid);

    res = iot_cloud_report(devid, TO_CLOUD_MSG_LOGIN, NULL, 0);
    USER_TRACE("iot_cloud_report(\"%s\") -> %d", meta_info->device_name, res);
    if (res == FAIL_RETURN) {
        USER_TRACE("subdev login Failed\n");
        return res;
    }
    USER_TRACE("subdev login success: devid = %d\n", devid);

    //user_example_ctx_t *user_example_ctx = user_example_get_ctx();
    *pdevid = devid;
    return res;
}

static void user_post_property(uint16_t devid, char *property_payload)
{
    int8_t res = 0;

    res = iot_cloud_report(devid, TO_CLOUD_MSG_POST_PROPERTY,
                           (unsigned char *)property_payload, strlen(property_payload));
    USER_TRACE("Post Property Message ID: %d", res);
}

static void user_deviceinfo_update(void)
{
    int8_t              res                = 0;
    user_example_ctx_t *user_example_ctx   = user_example_get_ctx();
    char *              device_info_update = "[{\"attrKey\":\"abc\",\"attrValue\":\"hello,world\"}]";

    res = iot_cloud_report(user_example_ctx->master_devid, TO_CLOUD_MSG_DEVICEINFO_UPDATE,
                           (unsigned char *)device_info_update, strlen(device_info_update));
    USER_TRACE("Device Info Update Message ID: %d", res);
}

static void user_deviceinfo_delete(void)
{
    int8_t              res                = 0;
    user_example_ctx_t *user_example_ctx   = user_example_get_ctx();
    char *              device_info_delete = "[{\"attrKey\":\"abc\"}]";

    res = iot_cloud_report(user_example_ctx->master_devid, TO_CLOUD_MSG_DEVICEINFO_DELETE,
                           (unsigned char *)device_info_delete, strlen(device_info_delete));
    USER_TRACE("Device Info Delete Message ID: %d", res);
}

/*********************************************************************************
*	Stack msg handler
*********************************************************************************/
static int16_t cloud_nwk_setting(void *data)
{
    PTR_NULL_CHK(data);
    NwkSettings_t *nwk_setting = data;

    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    memcpy(&user_example_ctx->master_eui64, &nwk_setting->ncpEui64, EUI64_LEN);
    USER_TRACE("Got NCP's EUI64: %d%d%d%d%d%d%d%d", user_example_ctx->master_eui64.uuid[0], user_example_ctx->master_eui64.uuid[1],
               user_example_ctx->master_eui64.uuid[2],user_example_ctx->master_eui64.uuid[3],user_example_ctx->master_eui64.uuid[4],
               user_example_ctx->master_eui64.uuid[5],user_example_ctx->master_eui64.uuid[6],user_example_ctx->master_eui64.uuid[7]);

    return 0;
}

static int16_t add_dev_to_cloud(EUI64_T *peui64, uint8_t endpoint, uint8_t prod_type)
{
    uint16_t            devid;
    uint8_t             flag_existed = 0;
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    /* Add subdev */
    if (user_example_ctx->master_initialized && user_example_ctx->subdev_index >= 0) {
        if (user_example_ctx->subdev_index < EXAMPLE_SUBDEV_ADD_NUM) {
            int16_t i = search_by_dev_info(peui64, endpoint);
            if (i == -1) {
                i = search_available_meta(prod_type);
                if (i == -1) {
                    ERROR_TRACE("No available meta to use!");
                    return -1;
                }
                //USER_TRACE("====avail meta ind: %d", i);

            } else {
                flag_existed = 1;
                USER_TRACE("Find the same existed dev info: %d", i);
            }

            USER_TRACE("example_add_subdev(\"%s\")...", subdevArr[i].device_name);
            if (example_add_subdev((CLOUD_DEV_META_T *)&subdevArr[i], &devid) == SUCCESS_RETURN) {
                USER_TRACE("<- example_add_subdev(\"%s\") succeed.\n", subdevArr[i].device_name);
                memcpy(&dev_info_meta[i].eui64, peui64, EUI64_LEN);
                dev_info_meta[i].endpoint   = endpoint;
                dev_info_meta[i].deviceid   = devid;
                dev_info_meta[i].pmeta_info = &subdevArr[i];
                USER_TRACE("user_example_ctx->subdev_index:%d", user_example_ctx->subdev_index);
                USER_TRACE("Got dev name:%s\n", dev_info_meta[i].pmeta_info->device_name);

                // only count once for multi-endpoint dev or already added dev
                if (!flag_existed) {
                    user_example_ctx->subdev_index++;
                }
            } else {
                USER_TRACE("<- example_add_subdev(\"%s\") failed!\n", subdevArr[i].device_name);
            }

            //user_example_ctx->permit_join = 0;
            //USER_TRACE("0:%d, dev_info_meta[0].deviceid:%d, dev_info_meta[0].pmeta_info： %p\n", i, dev_info_meta[0].deviceid, dev_info_meta[0].pmeta_info);
            //USER_TRACE("1:%d, dev_info_meta[1].deviceid:%d, dev_info_meta[1].pmeta_info： %p\n", i, dev_info_meta[1].deviceid, dev_info_meta[1].pmeta_info);
        } else {
            USER_TRACE("Can't add any more device.");
        }
    }

    return 0;
}

static int16_t cloud_add_sub_dev(void *data)
{
    PTR_NULL_CHK(data);
    DevJoined_t *dev_joined = data;

    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    uint8_t srcEndpoint;
    uint8_t prod_type = get_dev_prod_type_by_cluster(dev_joined, &srcEndpoint);
    USER_TRACE("Add sub dev, prod type: %d", prod_type);

    if (prod_type == PRODUCT_TYPE_SWITCH) {
        set_assn_interface(&dev_joined->eui64, 
                           &user_example_ctx->master_eui64,
                           6,
                           srcEndpoint,
                           1);
    }
    dev_prod_type_store_update(&dev_joined->eui64, prod_type, ADD_DEV_PROD_TYPE);

    /* Add subdev */
    if (user_example_ctx->auto_add_subdev == 1 || user_example_ctx->permit_join != 0) {
        if (-1 == add_dev_to_cloud(&(dev_joined->eui64), dev_joined->endPoints[1].endpoint, prod_type)) {
            ERROR_TRACE("failed");
            return -1;
        }
    }

    // adding dev successfully, close joining
    close_join(NULL);

    return 0;
}

static int16_t cloud_dev_left(void *data)
{
    PTR_NULL_CHK(data);
    DevLeft_t *dev_left = data;

    int16_t ind = search_by_dev_info(&(dev_left->eui64), 0);
    if (ind == -1) {
        ERROR_TRACE("Can't find the eui64 matched device!");
        return -1;
    }
    USER_TRACE("To logout the dev: %d\n", dev_info_meta[ind].deviceid);

    dev_prod_type_store_update(&dev_left->eui64, NULL, DEL_DEV_PROD_TYPE);

    // only logout, not del topo
    if (dev_logout(dev_info_meta[ind].deviceid, false) == -1) {
        ERROR_TRACE("dev logout failed.");
        return -1;
    }

    dev_info_meta[ind].pmeta_info = NULL;
    return 0;
}

static int16_t cloud_attr_msg(void *data)
{
    PTR_NULL_CHK(data);

    uint8_t    prod_type;
    AttrMsg_t *attr_msg = data;
    char property_payload[30+1];

    int16_t devid = get_devid_by_eui(&attr_msg->eui64);
    
    if (-1 == devid) {
        ERROR_TRACE("failed");
        return -1;
    }

    memset(property_payload, 0, sizeof(property_payload));
    USER_TRACE("clusterId: %d, attrId: %d, data: %d", attr_msg->clusterId, attr_msg->attrId, attr_msg->data[0]);
    if (attr_msg->clusterId == CLUSTER_ID_ON_OFF) {
        prod_type = get_dev_prod_type_by_eui64(&attr_msg->eui64);
        USER_TRACE("prod type: %d", prod_type);
        if (PRODUCT_TYPE_LIGHT == prod_type) {
            if (attr_msg->attrId == CLUSTER_ON_OFF_ATTR_ID_ON_OFF){
                snprintf(property_payload, 30, "{\"LightSwitch\":%d}", attr_msg->data[0]);
                user_post_property(devid, property_payload);
            }
        } else {

        }
    }

    return 0;
}

//typedef struct _DevInfo_t {
//  Eui64_t eui64;
//  uint8_t endpoint;
//} DevInfo_t;
static int16_t cloud_dev_info_update(void *data)
{
    PTR_NULL_CHK(data);

    DevInfo_t *dev_info = data;
    uint8_t prod_type = get_dev_prod_type_from_bkp(&dev_info->eui64);

    USER_TRACE("sub dev update, prod type: %d", prod_type);

    if (-1 == add_dev_to_cloud(&(dev_info->eui64), dev_info->endpoint, prod_type)) {
        ERROR_TRACE("failed");
        return -1;
    }

    return 0;
}

static int16_t cloud_cmd_recv(void *data)
{
    PTR_NULL_CHK(data);

    uint8_t    prod_type;
    CmdRecv_t *cmd_recv = data;
    char property_payload[30+1];
    static uint8_t switch_toggle = 0;

    int16_t devid = get_devid_by_eui(&cmd_recv->eui64);
    
    if (-1 == devid) {
        ERROR_TRACE("failed");
        return -1;
    }

    memset(property_payload, 0, sizeof(property_payload));
    USER_TRACE("clusterId: %d, attrId: %d", cmd_recv->clusterId, cmd_recv->cmdId);
    if (cmd_recv->clusterId == CLUSTER_ID_ON_OFF) {
        prod_type = get_dev_prod_type_by_eui64(&cmd_recv->eui64);
        if (PRODUCT_TYPE_SWITCH == prod_type) {
            if (cmd_recv->cmdId < CLUSTER_ON_OFF_CMD_ID_TOGGLE){
                snprintf(property_payload, 30, "{\"PowerSwitch_1\":%d}", cmd_recv->cmdId);
                switch_toggle = cmd_recv->cmdId;
             } else {
                switch_toggle = !switch_toggle;
                snprintf(property_payload, 30, "{\"PowerSwitch_1\":%d}", switch_toggle);
            } 
            user_post_property(devid, property_payload);
        } else {
        }
    }

    return 0;
}

/*********************************************************************************
*	msg center
*********************************************************************************/
void cloud_msg_center(void)
{
    FROM_CLOUD_MSG_T cloud_msg;

    if (-1 == recv_msg_from_q(CLOUD_MSG_Q, &cloud_msg)) {
        //USER_TRACE("Can't get msg from Q\r\n");
        return;
    } else {
        //printMsg(&stack_msg);
    }

    switch (cloud_msg.id) {
        case CLOUD_CREATE_NWK:
            form_nwk(cloud_msg.data);
            break;
        case CLOUD_LEAVE_NWK:
            leave_nwk(cloud_msg.data);
            break;
        case CLOUD_PERMIT_JOIN:
            permit_join(cloud_msg.data);
            break;
        case CLOUD_CLOSE_JOIN:
            close_join(cloud_msg.data);
            break;
        case CLOUD_DEL_DEV:
            del_dev(cloud_msg.data);
            break;
        case CLOUD_PROP_SET:
            property_set(cloud_msg.data);
            break;
        default:
            break;
    }

    user_free((void *)cloud_msg.data);
}

void stack_msg_center(void)
{
    FROM_STACK_MSG_T stack_msg;

    if (-1 == recv_msg_from_q(FROM_STACK_MSG_Q, &stack_msg)) {
        //USER_TRACE("Can't get msg from Q\r\n");
        return;
    } else {
        //printMsg(&stack_msg);
    }

    switch (stack_msg.id) {
        case NWK_SETTINGS:
            cloud_nwk_setting(stack_msg.data);
            break;
        case NWK_STATUS:
            break;
        case DEV_JOINED:
            cloud_add_sub_dev(stack_msg.data);
            break;
        case DEV_LEFT:
            cloud_dev_left(stack_msg.data);
            break;
        case DEV_DISC_RET:  ///< Return value for #DEV_DISC.
            break;
        case DEV_STATUS_CHANGED:
            break;
        case OPS_RSP:  ///< Responses for ctrl/setting operations.
            break;
        case ATTR_MSG:
            cloud_attr_msg(stack_msg.data);
            break;
        case DEV_INFO:
            cloud_dev_info_update(stack_msg.data);
            break;
        case CMD_RECV:
            cloud_cmd_recv(stack_msg.data);
            break;
        default:
            break;
    }

    user_free((void *)stack_msg.data);
}

/*********************************************************************************
*	Gateway Threads
*********************************************************************************/
void *user_dispatch_yield(void *args)
{
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    while (user_example_ctx->g_user_dispatch_thread_running) {
        iot_cloud_yield(USER_EXAMPLE_YIELD_TIMEOUT_MS);
        //USER_TRACE("iot_cloud_yield(%dms)\n", USER_EXAMPLE_YIELD_TIMEOUT_MS);
        #if WDT_TIMEOUT_MS
        watchdog_refresh();
        #endif
    }

    return NULL;
}

static void *stack_msg_center_thread(void *arg)
{
    uint64_t time_prev_sec = 0, time_now_sec = 0, time_begin_sec = 0;
    time_begin_sec = user_update_sec();
    while (1) {
        thread_sleep_ms(USER_EXAMPLE_YIELD_TIMEOUT_MS);

        stack_msg_center();

        time_now_sec = user_update_sec();
        if (time_prev_sec == time_now_sec) {
            continue;
        }

        /* Post Proprety Example */
        if (time_now_sec % 11 == 0 && user_master_dev_available()) {
            /* user_post_property(); */
        }

        /* Device Info Update Example */
        if (time_now_sec % 23 == 0 && user_master_dev_available()) {
            /* user_deviceinfo_update(); */
        }

        /* Device Info Delete Example */
        if (time_now_sec % 29 == 0 && user_master_dev_available()) {
            /* user_deviceinfo_delete(); */
        }

        time_prev_sec = time_now_sec;
    }
    return NULL;
}

static void *cloud_msg_center_thread(void *arg)
{
    uint64_t time_prev_sec = 0, time_now_sec = 0, time_begin_sec = 0;
    time_begin_sec = user_update_sec();
    while (1) {
        thread_sleep_ms(USER_EXAMPLE_YIELD_TIMEOUT_MS);

        cloud_msg_center();

#if BOARD_IO_ENABLE
        button_evt_hdl();
#endif //BOARD_IO_ENABLE

        time_now_sec = user_update_sec();
        if (time_prev_sec == time_now_sec) {
            continue;
        }

        /* Post Proprety Example */
        if (time_now_sec % 11 == 0 && user_master_dev_available()) {
            /* user_post_property(); */
        }

        /* Device Info Update Example */
        if (time_now_sec % 23 == 0 && user_master_dev_available()) {
            /* user_deviceinfo_update(); */
        }

        /* Device Info Delete Example */
        if (time_now_sec % 29 == 0 && user_master_dev_available()) {
            /* user_deviceinfo_delete(); */
        }

        time_prev_sec = time_now_sec;
    }

    return NULL;
}
#endif //CLOUD_GATEWAY_ENABLE

static void *cloud_gateway_init_thread(void *arg)
{
    USER_TRACE("Silicon Labs Z3 RTOS GW FW version: %s", SILABS_Z3_RTOS_GW_FW_VER);

    #if CLOUD_GATEWAY_ENABLE
    #if WDT_TIMEOUT_MS
    watchdog_init(WDT_TIMEOUT_MS);
    watchdog_start();
    #endif

    /*Wait WIFI init complete*/
    while (is_wifi_connected() == false) {
        thread_sleep_ms(1000);
        #if WDT_TIMEOUT_MS
        watchdog_refresh();
        #endif
    }
    led_control(LED_WIFI_CONNECTED);
    #endif //CLOUD_GATEWAY_ENABLE

    /* Start Z3 host task */
    (void)startGateway(0, NULL);
    thread_sleep_ms(3000);

    #if CLOUD_GATEWAY_ENABLE

    /* initiate a zigbee nwk if there's not any */
    form_nwk((void*) 0);

    /*********************************************************************************
    *	Start Cloud Gateway
    *********************************************************************************/
    USER_TRACE("Cloud Gateway starts...");

    int user_stacksize = 0;
    int res = 0;
    user_example_ctx_t *user_example_ctx = user_example_get_ctx();

    CLOUD_DEV_META_T    master_meta_info;

    memset(user_example_ctx, 0, sizeof(user_example_ctx_t));

    user_example_ctx->subdev_index    = -1;

    iot_cloud_sdk_set_log_level(CLOUD_SDK_LOG_DEBUG);

    /* Register Callback */
    cloud_handler_register();

    dev_info_meta_init();

    // to get NCP EUI64
    get_network_interface();

    // retrieve the dev's prod type from flash
    dev_prod_type_load();

    get_master_meta(&master_meta_info);
    /* Create Master Device Resources */
    user_example_ctx->master_devid = iot_cloud_open(IOTX_CLOUD_DEV_TYPE_MASTER, &master_meta_info);
    USER_TRACE("iot_cloud_open() -> %d", user_example_ctx->master_devid);
    if (user_example_ctx->master_devid < 0) {
        goto exit_final;
    }

    /* setting login server, method, ... */
    cloud_login_setting();

    /* Start Connect Cloud Server */
    do {
        USER_TRACE("iot_cloud_connect()...");
        res = iot_cloud_connect(user_example_ctx->master_devid);
        //USER_TRACE("iot_cloud_connect() -> %d\n", res);
        if (res < 0) {
            USER_TRACE("iot_cloud_connect failed, retry after 5s...\n");
            thread_sleep_ms(5000);
            #if WDT_TIMEOUT_MS
            watchdog_refresh();
            #endif
        }
    } while (res < 0);

    if (create_cloud_msg_q() == -1) {
        ERROR_TRACE("Creating cloud msg Q failed\n");
        goto exit5;
    }

    os_thread_params_t user_thread = {OS_THREAD_PRIO_NORMAL, NULL, 2 * 1024, 0, "cloud_msg_center_thread"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", user_thread.name, user_thread.stack_size, user_thread.priority);
    res = thread_create(&user_example_ctx->g_cloud_msg_thread, cloud_msg_center_thread, NULL, &user_thread, &user_stacksize);
    if (res < 0) {
        USER_TRACE("Failed.\n");
        goto exit4;
    }
    
    os_thread_params_t user_thread2 = {OS_THREAD_PRIO_NORMAL, NULL, 2 * 1024, 0, "stack_msg_center_thread"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", user_thread2.name, user_thread2.stack_size, user_thread2.priority);
    res = thread_create(&user_example_ctx->g_stack_msg_thread, stack_msg_center_thread, NULL, &user_thread2, &user_stacksize);
    if (res < 0) {
        USER_TRACE("Failed.\n");
        goto exit3;
    }

    //need to set g_user_dispatch_thread_running = 1 before creating g_user_dispatch_thread
    user_example_ctx->g_user_dispatch_thread_running = 1;

    os_thread_params_t user_thread3 = {OS_THREAD_PRIO_NORMAL, NULL, 4 * 1024, 0, "user_dispatch_yield"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", user_thread3.name, user_thread3.stack_size, user_thread3.priority);
    res = thread_create(&user_example_ctx->g_user_dispatch_thread, user_dispatch_yield, NULL, &user_thread3, &user_stacksize);
    if (res < 0) {
        USER_TRACE("Failed.\n");
        goto exit2;
    }

    goto exit_final;

exit1:
    USER_TRACE("Delete thread: user_dispatch_thread: %p\n", user_example_ctx->g_user_dispatch_thread);
    thread_delete(user_example_ctx->g_user_dispatch_thread);

exit2:
    USER_TRACE("Delete thread: stack_msg_thread: %p\n", user_example_ctx->g_stack_msg_thread);
    thread_delete(user_example_ctx->g_stack_msg_thread);

exit3:
    USER_TRACE("Delete thread: cloud_msg_thread: %p\n", user_example_ctx->g_cloud_msg_thread);
    thread_delete(user_example_ctx->g_cloud_msg_thread);

exit4:
    USER_TRACE("Delete msg queue: cloud_msg_g\n");
    remove_cloud_msg_q();

exit5:
    USER_TRACE("iot_cloud_close()\n");
    iot_cloud_close(user_example_ctx->master_devid);
    iot_cloud_sdk_memory_dum(CLOUD_SDK_LOG_DEBUG);
    iot_cloud_sdk_set_log_level(CLOUD_SDK_LOG_DEBUG);
    USER_TRACE("cloud gateway exit!\n");

    #endif //CLOUD_GATEWAY_ENABLE

exit_final:
    thread_delete(cloud_gateway_init_thread_handle);
    #if WDT_TIMEOUT_MS
    watchdog_stop();
    #endif

    return NULL;
}

void start_cloud_gateway(void)
{
    int user_stacksize = 0;
    int res;
    os_thread_params_t user_thread = {OS_THREAD_PRIO_NORMAL, NULL, 6 * 1024, 0, "cloud_gateway_init_thread"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", user_thread.name, user_thread.stack_size, user_thread.priority);
    res = thread_create(&cloud_gateway_init_thread_handle, cloud_gateway_init_thread, NULL, &user_thread, &user_stacksize);
    if (res < 0) {
        USER_TRACE("%s thread_create failed\n", __FUNCTION__);
    }
}

/*********************************************************************************
*	wifi Threads
*********************************************************************************/
//os_thread_params_t:
//    hal_os_thread_priority_t priority;   /* initial thread priority */
//    void *stack_addr;                    /* thread stack address malloced by caller, use system stack by . */
//    int   stack_size;                    /* stack size requirements in bytes; 0 is default stack size */
//    int   detach_state;                  /* 0: not detached state; otherwise: detached state. */
//    char *name;
#if WIFI_PROVISION_ENABLE
extern void *start_wifi_prov_thread_handle;

void start_wifi_provision(void)
{
    int                user_stacksize = 0;
    int                res;
    os_thread_params_t user_thread = {OS_THREAD_PRIO_NORMAL, NULL, 2 * 1024, 0, "wifi_provisioning_thread"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", user_thread.name, user_thread.stack_size, user_thread.priority);
    res = thread_create(&start_wifi_prov_thread_handle, start_wifi_prov_thread, NULL, &user_thread, &user_stacksize);
    if (res < 0) {
        USER_TRACE("%s thread_create failed\n", __FUNCTION__);
    }
}
#endif //WIFI_PROVISION_ENABLE

