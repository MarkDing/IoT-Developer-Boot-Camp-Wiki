
#include "cloud_gateway.h"
#include "cloud_gateway_interface.h"

#include "dm_manager.h"
#include "dm_wrapper.h"

#if CLOUD_GATEWAY_ENABLE
#include "msg.h"
#include "hashing.h"
#endif //CLOUD_GATEWAY_ENABLE

// from wifi_conf.h
extern int wifi_get_channel(int *channel);

/*********************************************************************************
 *	Dynamic memory
 *********************************************************************************/
void *user_malloc(size_t size)
{
    return HAL_Malloc(size);
}

void user_free(void *ptr)
{
    if (ptr == NULL) return;

    HAL_Free(ptr);
}

/*********************************************************************************
 *	time counting
 *********************************************************************************/
uint64_t user_update_sec(void)
{
    static uint64_t time_start_ms = 0;

    if (time_start_ms == 0) {
        time_start_ms = HAL_UptimeMs();
    }

    return (HAL_UptimeMs() - time_start_ms) / 1000;
}

/*********************************************************************************
 *	OS related
 *********************************************************************************/
void thread_sleep_ms(uint32_t ms)
{
    HAL_SleepMs(ms);
}

int thread_create(void **thread_handle,
                  void *(*work_routine)(void *),
                  void *arg,
                  os_thread_params_t *os_thread_params,
                  int *stack_used)
{
    hal_os_thread_param_t hal_os_thread_param = {0, NULL, 0, 0, NULL};
    hal_os_thread_param.priority              = os_thread_params->priority;
    hal_os_thread_param.stack_size            = os_thread_params->stack_size;
    hal_os_thread_param.name                  = os_thread_params->name;
    return HAL_ThreadCreate(thread_handle, work_routine, NULL, &hal_os_thread_param, stack_used);
}

void thread_delete(void *thread_handle)
{
    HAL_ThreadDelete(thread_handle);
}

#if CLOUD_GATEWAY_ENABLE
/*********************************************************************************
 *	cjson parse
 *********************************************************************************/
int cloud_cjson_parse(const char *src, int src_len, CJSON_T *lite)
{
    return lite_cjson_parse(src, src_len, lite);
}

int cloud_cjson_object_item(CJSON_T *lite, const char *key, int key_len, CJSON_T *lite_item)
{
    return lite_cjson_object_item(lite, key, key_len, lite_item);
}

int cloud_cjson_is_object(CJSON_T *lite)
{
    return lite_cjson_is_object(lite);
}

int cloud_cjson_is_string(CJSON_T *lite)
{
    return lite_cjson_is_string(lite);
}

int cloud_cjson_is_number(CJSON_T *lite)
{
    return lite_cjson_is_number(lite);
}

/*********************************************************************************
 *	Cloud SDK related
 *********************************************************************************/
static char PRODUCT_KEY[IOTX_PRODUCT_KEY_LEN + 1]       = {0};
static char PRODUCT_SECRET[IOTX_PRODUCT_SECRET_LEN + 1] = {0};
static char DEVICE_NAME[IOTX_DEVICE_NAME_LEN + 1]       = {0};
static char DEVICE_SECRET[IOTX_DEVICE_SECRET_LEN + 1]   = {0};

int  user_connected_event_handler(void);
int  user_disconnected_event_handler(void);
int  user_property_set_event_handler(const int devid, const char *request, const int request_len);
int  user_report_reply_event_handler(const int devid, const int msgid, const int code, const char *reply,
                                     const int reply_len);
int  user_timestamp_reply_event_handler(const char *timestamp);
int  user_initialized(const int devid);
int  user_permit_join_event_handler(const char *product_key, const int time);
int  user_service_request_event_handler(const int devid, const char *serviceid, const int serviceid_len,
                                        const char *request, const int request_len, char **response, int *response_len);
void cloud_handler_register(void)
{
    IOT_RegisterCallback(ITE_CONNECT_SUCC, user_connected_event_handler);
    IOT_RegisterCallback(ITE_DISCONNECTED, user_disconnected_event_handler);
    IOT_RegisterCallback(ITE_PROPERTY_SET, user_property_set_event_handler);
    IOT_RegisterCallback(ITE_REPORT_REPLY, user_report_reply_event_handler);
    IOT_RegisterCallback(ITE_TIMESTAMP_REPLY, user_timestamp_reply_event_handler);
    IOT_RegisterCallback(ITE_INITIALIZE_COMPLETED, user_initialized);
    IOT_RegisterCallback(ITE_PERMIT_JOIN, user_permit_join_event_handler);
    IOT_RegisterCallback(ITE_SERVICE_REQUEST, user_service_request_event_handler);
}

void cloud_login_setting(void)
{
    int domain_type      = 0;
    int dynamic_register = 0;
    int post_event_reply = 0;

    /* Choose Login Server */
    domain_type = IOTX_CLOUD_REGION_SHANGHAI;
    IOT_Ioctl(IOTX_IOCTL_SET_DOMAIN, (void *)&domain_type);
    USER_TRACE("IOT_Ioctl(IOTX_IOCTL_SET_DOMAIN = %d)", domain_type);

    /* Choose Login Method */
    dynamic_register = 0;
    IOT_Ioctl(IOTX_IOCTL_SET_DYNAMIC_REGISTER, (void *)&dynamic_register);
    USER_TRACE("IOT_Ioctl(IOTX_IOCTL_SET_DYNAMIC_REGISTER = %d)", dynamic_register);

    /* Choose Whether You Need Post Property/Event Reply */
    post_event_reply = 0;
    IOT_Ioctl(IOTX_IOCTL_RECV_EVENT_REPLY, (void *)&post_event_reply);
    USER_TRACE("IOT_Ioctl(IOTX_IOCTL_RECV_EVENT_REPLY = %d)", post_event_reply);
}

int iot_cloud_report(int devid, to_cloud_msg_type_t msg_type, unsigned char *payload, int payload_len)
{
    return IOT_Linkkit_Report(devid, msg_type, payload, payload_len);
}

int iot_cloud_open(iotx_cloud_dev_type_t dev_type, CLOUD_DEV_META_T *meta_info)
{
    return IOT_Linkkit_Open(dev_type, meta_info);
}

int iot_cloud_connect(int devid)
{
    return IOT_Linkkit_Connect(devid);
}

int iot_cloud_close(int devid)
{
    return IOT_Linkkit_Close(devid);
}

void iot_cloud_yield(int timeout_ms)
{
    IOT_Linkkit_Yield(timeout_ms);
}

int16_t get_master_meta(CLOUD_DEV_META_T *pmaster_meta)
{
    if (NULL == pmaster_meta) return -1;

    HAL_GetProductKey(PRODUCT_KEY);
    HAL_GetProductSecret(PRODUCT_SECRET);
    HAL_GetDeviceName(DEVICE_NAME);
    HAL_GetDeviceSecret(DEVICE_SECRET);

    memset(pmaster_meta, 0, sizeof(CLOUD_DEV_META_T));
    memcpy(pmaster_meta->product_key, PRODUCT_KEY, strlen(PRODUCT_KEY));
    memcpy(pmaster_meta->product_secret, PRODUCT_SECRET, strlen(PRODUCT_SECRET));
    memcpy(pmaster_meta->device_name, DEVICE_NAME, strlen(DEVICE_NAME));
    memcpy(pmaster_meta->device_secret, DEVICE_SECRET, strlen(DEVICE_SECRET));

    return 0;
}

void iot_cloud_sdk_set_log_level(iot_cloud_sdk_log_level_t level)
{
    IOT_SetLogLevel(level);
}

void iot_cloud_sdk_memory_dum(iot_cloud_sdk_log_level_t level)
{
    IOT_DumpMemoryStats(level);
}

/*********************************************************************************
 *	messaging between threads
 *********************************************************************************/
#define CLOUD_MSG_Q_NAME      "cloud_msg_q"
#define FROM_CLOUD_MSG_Q_SIZE 10

MsgObj *g_cloud_msg_q = NULL;

int16_t create_cloud_msg_q(void)
{
    USER_TRACE("createMsg(%s)...", CLOUD_MSG_Q_NAME);
    g_cloud_msg_q = createMsg(FROM_CLOUD_MSG_Q_SIZE, sizeof(FROM_CLOUD_MSG_T), CLOUD_MSG_Q_NAME);
    if (NULL == g_cloud_msg_q) {
        ERROR_TRACE("createMsg(%s) failed!", CLOUD_MSG_Q_NAME);
        return -1;
    }
    return 0;
}

void remove_cloud_msg_q(void)
{
    removeMsg(g_cloud_msg_q);
}

int16_t return_q_name(msg_g_t msg_q, char **name_str)
{
    if (FROM_STACK_MSG_Q == msg_q) {
        *name_str = GW_UP_QUEUE_NAME;
    } else if (CLOUD_MSG_Q == msg_q) {
        *name_str = CLOUD_MSG_Q_NAME;
    } else if (TO_STACK_MSG_Q == msg_q) {
        *name_str = GW_DOWN_QUEUE_NAME;
    } else {
        ERROR_TRACE("wrong msg q type\r\n");
        return -1;        
    } 
    return 0;    
}

int16_t sendMsg(void *data, uint8_t id, msg_g_t msg_q)
{
    TopDownMsg_t  msg;
    MsgObj       *obj;
    char         *name_str;

    if (-1 == return_q_name(msg_q, &name_str)) {
        ERROR_TRACE("wrong msg q type\r\n");
        return -1;
    }

    obj      = findMsgByName(name_str);
    msg.id   = id;
    msg.data = data;
    msg.seq  = 0;
    if (obj->send(obj, &msg, 0) == false) {
        ERROR_TRACE("msg send error\r\n");
        return -1;
    }
    return 0;
}

int16_t recv_msg_from_q(msg_g_t msg_q, FROM_CLOUD_MSG_T *msg)
{
    MsgObj *recvObj;
    char   *name_str;

    if (msg == NULL) {
        ERROR_TRACE("msg pointer is NULL\r\n");
        return -1;
    }

    if (-1 == return_q_name(msg_q, &name_str)) {
        ERROR_TRACE("wrong msg q type\r\n");
        return -1;
    }

    if (NULL == (recvObj = findMsgByName(name_str))) {
        ERROR_TRACE("Can find name matched msg Q\r\n");
        return -1;
    }

    if (recvObj->recv(recvObj, msg, 0) == false) {
        // USER_TRACE("Q empty\r\n");
        return -1;
    }

    return 0;
}

/*********************************************************************************
 *	stack function related
 *********************************************************************************/
#define VALUE_STR_LEN                4   // 3 digits + \0

static int cmd_ctrl(Eui64_t *peui64,
                    uint16_t clusterId,
                    uint8_t cmdId,
                    SendType_t type,
                    uint16_t addr,
                    uint8_t * value,
                    uint8_t len)
{
    CmdCtrl_t  *data;
    const char *clusterName, *cmdName;

    data = user_malloc(sizeof(CmdCtrl_t));
    if (NULL == data) {
        ERROR_TRACE("malloc failed!!");
        return -1;
    }
    data->sendType = type;
    memcpy(data->eui64.uuid, peui64, MAX_EUI64_LEN);
    data->endpoint = 1;  // only ep 1 is supported currently
    data->destination = addr;
    data->clusterId = clusterId;
    data->cmdId = cmdId;
    memcpy(data->data, value, len);
    data->dataLen = len;

    if (-1 == sendMsg((void *)data, CMD_CTRL, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }
    return 0;
}

int16_t form_network_interface(void)
{
    const uint8_t faraway_ch_list[] = { 24, 24, 24, 24, 24, 24, 11, 11, 11, 11, 11 };
    CreateNwk_t *data;
    int wifi_ch = 0;

    data = user_malloc(sizeof(CreateNwk_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    data->random = 1;
    // lookup the far-away Zigbee channel w.r.t. the STA Wi-Fi channel
    if (wifi_get_channel(&wifi_ch)==0 && wifi_ch>=1 && wifi_ch<=11) {
        data->random = 0;
        //random pandId 0x0000~0xFFFF
        data->panId   = (uint16_t)(rand()%65536);
        data->channel = (uint16_t)faraway_ch_list[wifi_ch-1];
        data->power   = 20; //max 20dBm
        USER_TRACE("wf_ch=%d, zb_ch=%d, panId=0x%04x, zb_pwr=%d\r\n", 
                wifi_ch, data->channel, data->panId, data->power);
    }
    if (-1 == sendMsg((void *)data, CREATE_NWK, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        led_control(LED_ZB_NWK_OFF);
        return -1;
    }
    led_control(LED_ZB_NWK_ON);
    return 0;
}

int16_t leave_network_interface(void)
{
    if (-1 == sendMsg(NULL, LEAVE_NWK, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }
    led_control(LED_ZB_NWK_OFF);
    return 0;
}

int16_t get_network_interface(void)
{
    if (-1 == sendMsg(NULL, GET_NWK, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        return -1;
    }
    return 0;
}

int16_t permit_join_interface(uint16_t install_code_len, uint8_t *install_code, EUI64_T *eui64)
{
    OpenJoin_t *data = NULL;

    data = user_malloc(sizeof(OpenJoin_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memset(data, 0, sizeof(OpenJoin_t));

    if (!(install_code_len == INSTALL_CODE_SIZE_0 || install_code_len == INSTALL_CODE_SIZE_6 ||
          install_code_len == INSTALL_CODE_SIZE_8 || install_code_len == INSTALL_CODE_SIZE_12 ||
          install_code_len == INSTALL_CODE_SIZE_MAX)) {
        user_free(data);
        ERROR_TRACE("Install code must be 0, 6, 8, 12, or 16 bytes in length.\n");
        return -1;
    }

    if (install_code_len == 0) {
        data->joinType = DEFAULT_LINK_KEY_ONLY;
        USER_TRACE("join type: default_link_key_only\n");
    } else {
        PTR_NULL_CHK(install_code);
        data->joinType = USER_DEFINED_LINK_KEY_ONLY;
        memcpy(&data->userLinkKey.eui64, eui64, EUI64_LEN);
        installCodeToLinkKey(install_code_len, install_code, data->userLinkKey.linkKey);
        USER_TRACE("join type: user_defined_link_key_only\n");
    }

    data->discEnabled = 1;
    if (-1 == sendMsg((void *)data, OPEN_JOIN, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }
    return 0;
}

int16_t close_join_interface(void)
{
    OpenJoin_t *data = NULL;

    data = user_malloc(sizeof(OpenJoin_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }

    if (-1 == sendMsg((void *)data, CLOSE_JOIN, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }
    return 0;
}

int16_t del_dev_interface(Eui64_t *peui64, uint8_t endpoint)
{
    DevLeaveNwk_t *data;

    if (peui64 == NULL) return -1;

    data = user_malloc(sizeof(DevLeaveNwk_t));
    if (data == NULL) {
        ERROR_TRACE("malloc failed.");
        return -1;
    }
    memcpy(&data->eui64, peui64, MAX_EUI64_LEN);
    data->allowRejoin = 0;  // need to set to 0

    if (-1 == sendMsg((void *)data, DEV_LEAVE_NWK, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }
    return 0;
}

int16_t set_assn_interface(Eui64_t *prmtEui64,
                           Eui64_t *pdestEui64,
                           uint16_t clusterId,
                           uint8_t  srcEndpoint,
                           uint8_t  destEndpoint)
{
    SetAssn_t  *data;

    data = user_malloc(sizeof(SetAssn_t));
    if (NULL == data) {
        ERROR_TRACE("malloc failed!!");
        return -1;
    }

    memcpy(&data->remoteEui64, prmtEui64, MAX_EUI64_LEN);
    memcpy(&data->destEui64, pdestEui64, MAX_EUI64_LEN);
    data->srcEndpoint = srcEndpoint;
    data->destEndpoint = destEndpoint;
    data->clusterId = clusterId;

    if (-1 == sendMsg((void *)data, SET_ASSN, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }
    return 0;
}

int16_t lightswitch_set_interface(uint16_t value, Eui64_t eui64, uint8_t endpoint)
{
    uint8_t on_off;

    if (0 == value) {
        on_off = CLUSTER_ON_OFF_CMD_ID_OFF;
    } else {
        on_off = CLUSTER_ON_OFF_CMD_ID_ON;
    }

    if (-1 == cmd_ctrl(&eui64, CLUSTER_ID_ON_OFF, on_off, UNICAST, 0, NULL, 0)) {
        ERROR_TRACE("failed.");
        return -1;
    }
    return 0;
}

int16_t brightness_set_interface(uint16_t value, Eui64_t eui64, uint8_t endpoint)
{
    // emberAfFillCommandLevelControlClusterMoveToLevelWithOnOff(brightness, 0);
    // emberAfDeviceTableCommandSendWithEndpoint(eui64, endpoint);
    USER_TRACE("Set brightness to %d", value);
    if (-1 == cmd_ctrl(&eui64, CLUSTER_ID_LVL_CTRL, CLUSTER_LVL_CTRL_CMD_ID_MTL, UNICAST, 0, &value, 1)) {
        ERROR_TRACE("failed.");
        return -1;
    }
    return 0;
}

int16_t colorTemperature_set_interface(uint16_t value, Eui64_t eui64, uint8_t endpoint)
{
    // emberAfFillCommandColorControlClusterMoveToColorTemperature(colortemps, 0, 0, 0);
    // emberAfDeviceTableCommandSendWithEndpoint(eui64, endpoint);
    return 0;
}

int16_t permit_join_set_interface(uint16_t value, Eui64_t eui64, uint8_t endpoint)
{
    OpenJoin_t *data = NULL;
    uint8_t     msgId;

    if (1 == value) {
        data = user_malloc(sizeof(OpenJoin_t));
        if (data == NULL) {
            ERROR_TRACE("malloc failed.");
            return -1;
        }
        data->joinType    = DEFAULT_LINK_KEY_ONLY;
        data->discEnabled = 1;

        msgId = OPEN_JOIN;
    } else {
        msgId = CLOSE_JOIN;
    }

    if (-1 == sendMsg((void *)data, msgId, TO_STACK_MSG_Q)) {
        ERROR_TRACE("sendMsg failed.");
        user_free((void *)data);
        return -1;
    }
    return 0;
}
#endif //CLOUD_GATEWAY_ENABLE


