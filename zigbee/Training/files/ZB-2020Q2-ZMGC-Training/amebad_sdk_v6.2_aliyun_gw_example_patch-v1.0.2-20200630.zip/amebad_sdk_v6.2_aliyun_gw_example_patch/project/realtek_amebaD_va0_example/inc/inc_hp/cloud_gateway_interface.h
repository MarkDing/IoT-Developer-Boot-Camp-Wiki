#ifndef _cloud_gateway_interface_H_
#define _cloud_gateway_interface_H_

#include <platform/platform_stdlib.h>
#include "awss_dev_ap.h"
#include "dev_model_api.h"
#include "dm_wrapper.h"
#include "infra_cjson.h"
#include "board_io.h"
#include "flash_api.h"
#include "device_lock.h"

#if CLOUD_GATEWAY_ENABLE
#include "silabs-host-cmd.h"
#endif //CLOUD_GATEWAY_ENABLE

// use pritf() instead of HAL_Print() here to reduce heap usage
#define USER_TRACE(...)                                          \
    do {                                                            \
        printf("\n\r\033[1;32;40m%s.%d: ", __func__, __LINE__); \
        printf(__VA_ARGS__);                                    \
        printf("\033[0m");                                      \
    } while (0)
#define ERROR_TRACE(...)                                       \
    do {                                                       \
        printf("\n\r\033[31m%s.%d: ", __func__, __LINE__); \
        printf(__VA_ARGS__);                               \
        printf("\033[0m");                                 \
    } while (0)

#define PTR_NULL_CHK(p)                                \
    do {                                               \
        if (NULL == p) {                               \
            ERROR_TRACE("input pointer is NULL.\n\r"); \
            return -1;                                 \
        }                                              \
    } while (0)

#if CLOUD_GATEWAY_ENABLE
/*
 * ZNET stack related.
 */
#define EUI64_LEN                    MAX_EUI64_LEN
#define LINK_KEY_SIZE                sMAX_LINK_KEY_SIZE
#define INSTALL_CODE_SIZE_0          0
#define INSTALL_CODE_SIZE_6          6
#define INSTALL_CODE_SIZE_8          8
#define INSTALL_CODE_SIZE_12         12
#define INSTALL_CODE_SIZE_MAX        16
#define INSTALL_CODE_CRC_SIZE        2
#define INSTALL_CODE_STRING_SIZE_MAX (2 * INSTALL_CODE_SIZE_MAX + 1)
#define EUI64_STRING_SIZE            (2 * EUI64_LEN + 1)

#define CLUSTER_ID_ON_OFF   0x0006
#define CLUSTER_ID_LVL_CTRL 0x0008

#define CLUSTER_ON_OFF_CMD_ID_OFF     0x00
#define CLUSTER_ON_OFF_CMD_ID_ON      0x01
#define CLUSTER_ON_OFF_CMD_ID_TOGGLE  0x02
#define CLUSTER_LVL_CTRL_CMD_ID_MTL   0x00

#define CLUSTER_ON_OFF_ATTR_ID_ON_OFF 0x00

typedef TopDownMsg_t  FROM_CLOUD_MSG_T;
typedef BottomUpMsg_t FROM_STACK_MSG_T;
typedef Eui64_t EUI64_T;

typedef iotx_linkkit_dev_meta_info_t CLOUD_DEV_META_T;
typedef lite_cjson_t CJSON_T;

#endif //CLOUD_GATEWAY_ENABLE

typedef enum {
    OS_THREAD_PRIO_IDLE        = os_thread_priority_idle,        /* priority: idle (lowest) */
    OS_THREAD_PRIO_LOW         = os_thread_priority_low,         /* priority: low */
    OS_THREAD_PRIO_BELOWNORMAL = os_thread_priority_belowNormal, /* priority: below normal */
    OS_THREAD_PRIO_NORMAL      = os_thread_priority_normal,      /* priority: normal (default) */
    OS_THREAD_PRIO_ABOVENORMAL = os_thread_priority_aboveNormal, /* priority: above normal */
    OS_THREAD_PRIO_HIGH        = os_thread_priority_high,        /* priority: high */
    OS_THREAD_PRIO_REALTIME    = os_thread_priority_realtime,    /* priority: realtime (highest) */
    OS_THREAD_PRIO_ERROR       = os_thread_priority_error,       /* system cannot determine priority or thread has illegal priority */
} os_thread_priority_t;

typedef struct _os_thread_params {
    os_thread_priority_t priority;     /* initial thread priority */
    void *               stack_addr;   /* thread stack address malloced by caller, use system stack by NULL value. */
    int                  stack_size;   /* stack size requirements in bytes; 0 is default stack size */
    int                  detach_state; /* 0: not detached state; otherwise: detached state. */
    char *               name;         /* thread name. */
} os_thread_params_t;

#if CLOUD_GATEWAY_ENABLE

typedef enum {
    IOTX_CLOUD_DEV_TYPE_MASTER = IOTX_LINKKIT_DEV_TYPE_MASTER,
    IOTX_CLOUD_DEV_TYPE_SLAVE  = IOTX_LINKKIT_DEV_TYPE_SLAVE,
    IOTX_CLOUD_DEV_TYPE_MAX    = IOTX_LINKKIT_DEV_TYPE_MAX
} iotx_cloud_dev_type_t;

typedef enum {
    /* post property value to cloud */
    TO_CLOUD_MSG_POST_PROPERTY                  = ITM_MSG_POST_PROPERTY,

    /* post device info update message to cloud */
    TO_CLOUD_MSG_DEVICEINFO_UPDATE              = ITM_MSG_DEVICEINFO_UPDATE,

    /* post device info delete message to cloud */
    TO_CLOUD_MSG_DEVICEINFO_DELETE              = ITM_MSG_DEVICEINFO_DELETE,

    /* post raw data to cloud */
    TO_CLOUD_MSG_POST_RAW_DATA                  = ITM_MSG_POST_RAW_DATA,

    /* only for slave device, send login request to cloud */
    TO_CLOUD_MSG_LOGIN                          = ITM_MSG_LOGIN,

    /* only for slave device, send logout request to cloud */
    TO_CLOUD_MSG_LOGOUT                         = ITM_MSG_LOGOUT,

    /* only for slave device, send delete topo request to cloud */
    TO_CLOUD_MSG_DELETE_TOPO                    = ITM_MSG_DELETE_TOPO,

    /* query ntp time from cloud */
    TO_CLOUD_MSG_QUERY_TIMESTAMP                = ITM_MSG_QUERY_TIMESTAMP,

    /* only for master device, query topo list */
    TO_CLOUD_MSG_QUERY_TOPOLIST                 = ITM_MSG_QUERY_TOPOLIST,

    /* only for master device, qurey firmware ota data */
    TO_CLOUD_MSG_QUERY_FOTA_DATA                = ITM_MSG_QUERY_FOTA_DATA,

    /* only for master device, qurey config ota data */
    TO_CLOUD_MSG_QUERY_COTA_DATA                = ITM_MSG_QUERY_COTA_DATA,

    /* only for master device, request config ota data from cloud */
    TO_CLOUD_MSG_REQUEST_COTA                   = ITM_MSG_REQUEST_COTA,

    /* only for master device, request fota image from cloud */
    TO_CLOUD_MSG_REQUEST_FOTA_IMAGE             = ITM_MSG_REQUEST_FOTA_IMAGE,

    /* report subdev's firmware version */
    TO_CLOUD_MSG_REPORT_SUBDEV_FIRMWARE_VERSION = ITM_MSG_REPORT_SUBDEV_FIRMWARE_VERSION,

    /* get a device's desired property */
    TO_CLOUD_MSG_PROPERTY_DESIRED_GET           = ITM_MSG_PROPERTY_DESIRED_GET,

    /* delete a device's desired property */
    TO_CLOUD_MSG_PROPERTY_DESIRED_DELETE        = ITM_MSG_PROPERTY_DESIRED_DELETE,

    TO_CLOUD_MSG_MAX                            = IOTX_LINKKIT_MSG_MAX
} to_cloud_msg_type_t;

typedef enum _iot_cloud_sdk_log_level {
    CLOUD_SDK_LOG_NONE    = IOT_LOG_NONE,
    CLOUD_SDK_LOG_CRIT    = IOT_LOG_CRIT,
    CLOUD_SDK_LOG_ERROR   = IOT_LOG_ERROR,
    CLOUD_SDK_LOG_WARNING = IOT_LOG_WARNING,
    CLOUD_SDK_LOG_INFO    = IOT_LOG_INFO,
    CLOUD_SDK_LOG_DEBUG   = IOT_LOG_DEBUG,
} iot_cloud_sdk_log_level_t;

typedef enum { FROM_STACK_MSG_Q,
               TO_STACK_MSG_Q,
               CLOUD_MSG_Q } msg_g_t;

#endif //CLOUD_GATEWAY_ENABLE

void *user_malloc(size_t size);
void  user_free(void *ptr);
uint64_t user_update_sec(void);

void thread_sleep_ms(uint32_t ms);
int  thread_create(void **thread_handle, void *(*work_routine)(void *), void *arg, os_thread_params_t *os_thread_params,
                   int *stack_used);
void thread_delete(void *thread_handle);

uint16_t is_wifi_connected(void);
void     erase_wifi_fastcon_data(void);
void *   start_wifi_prov_thread(void *arg);

#if CLOUD_GATEWAY_ENABLE

int cloud_cjson_parse(const char *src, int src_len, lite_cjson_t *lite);
int cloud_cjson_object_item(lite_cjson_t *lite, const char *key, int key_len, lite_cjson_t *lite_item);
int cloud_cjson_is_object(lite_cjson_t *lite);
int cloud_cjson_is_string(lite_cjson_t *lite);
int cloud_cjson_is_number(lite_cjson_t *lite);

int16_t get_master_meta(CLOUD_DEV_META_T *pmaster_meta);
void    cloud_handler_register(void);
void    cloud_login_setting(void);
int     iot_cloud_report(int devid, to_cloud_msg_type_t msg_type, unsigned char *payload, int payload_len);
int     iot_cloud_open(iotx_cloud_dev_type_t dev_type, CLOUD_DEV_META_T *meta_info);
int     iot_cloud_connect(int devid);
int     iot_cloud_close(int devid);
void    iot_cloud_yield(int timeout_ms);
void    iot_cloud_sdk_set_log_level(iot_cloud_sdk_log_level_t level);
void    iot_cloud_sdk_memory_dum(iot_cloud_sdk_log_level_t level);

int16_t sendMsg(void *data, uint8_t id, msg_g_t msg_q);
int16_t recv_msg_from_q(uint8_t msg_q, FROM_CLOUD_MSG_T *msg);
int16_t create_cloud_msg_q(void);
void    remove_cloud_msg_q(void);

int16_t form_network_interface(void);
int16_t leave_network_interface(void);
int16_t permit_join_interface(uint16_t install_code_len, uint8_t *install_code, EUI64_T *eui64);
int16_t close_join_interface(void);
int16_t del_dev_interface(EUI64_T *peui64, uint8_t endpoint);
int16_t lightswitch_set_interface(uint16_t value, EUI64_T eui64, uint8_t endpoint);
int16_t brightness_set_interface(uint16_t value, EUI64_T eui64, uint8_t endpoint);
int16_t colorTemperature_set_interface(uint16_t value, EUI64_T eui64, uint8_t endpoint);
int16_t permit_join_set_interface(uint16_t value, EUI64_T eui64, uint8_t endpoint);

#endif //CLOUD_GATEWAY_ENABLE

#endif
