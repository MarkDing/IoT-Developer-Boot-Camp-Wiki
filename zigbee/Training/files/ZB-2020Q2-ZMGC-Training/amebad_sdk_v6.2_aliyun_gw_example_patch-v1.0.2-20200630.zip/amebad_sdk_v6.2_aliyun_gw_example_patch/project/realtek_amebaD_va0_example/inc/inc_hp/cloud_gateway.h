#ifndef _cloud_gateway_H_
#define _cloud_gateway_H_

#include "infra_defs.h"
#include "board_io.h"
#include "wdt_api.h"

#define WIFI_PROVISION_ENABLE           1  ///< enable wifi provisioning for GW
#define WIFI_PROV_AWSS_DEV_AP_ENABLE    1  ///< wifi provisioning method: device AP, need Aliyun's Intelligent Cloud App to go with
#define BOARD_IO_ENABLE                 1  ///< enable board io control

// 0: Disalbed watchdog timer
// >0:Enable watchdog timer with timeout in ms
#define WDT_TIMEOUT_MS                  60000 // 60 seconds

// 0: living.aliyun.com
// 1: iot.console.aliyun.com
#define IOT_CONSOLE_ALIYUN_PLATFORM     0

void start_cloud_gateway(void);
void start_connect_default_wifi(void);
void start_wifi_provision(void);
void start_button_polling(void);

#endif
