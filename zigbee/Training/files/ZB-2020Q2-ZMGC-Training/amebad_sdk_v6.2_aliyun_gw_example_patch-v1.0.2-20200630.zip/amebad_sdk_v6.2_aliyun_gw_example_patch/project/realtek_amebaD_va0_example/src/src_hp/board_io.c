#include "device.h"
#include "gpio_api.h"
#include "pwmout_api.h"
#include "timer_api.h"

#include "cloud_gateway.h"

/*********************************************************************************
*	compile option defines
*********************************************************************************/
#define ENABLE_NCP_RESET        1   // enable/disable NCP reset control
#define ENABLE_NCP_BOOTLOAD     1   // enable/disable NCP bootload control
#define ENABLE_LED_TRACE        0   // enable/disable LED trace output
#define ENABLE_KEY_TRACE        1   // enable/disable Button trace output
#define LED_BLINKING_GTMR       1   // LED blinking uses 1:GTimer, 0:PWM Timer

/*
3-WIRE PTA
-	NCP_REQ:	PA26 	(ext 1.5K PD)
-	NCP_PRI: 	PB1 	(ext 1.5K PD)
-	NCP_GNT:	PA27 	(ext  10K PU) (note NORMAL_MODE_SEL and SWD_DATA)
NCP-CTRL
-	NCP_RST:	PA28    (ext 10K PU)
-	NCP_BTL:    PB21	(ext 10K PU)
NCP_UART
-	HOST_TX:	PA12	(NCP_RX)
-	HOST_RX:	PB13	(NCP_TX)
-	HOST_RTS:	PA14	(NCP_CTS)
-	HOST_CTS:	PA15	(NCP_RTS)
LOG_UART
-	LOG_TX:		PA7		(ext 10K PU) (UART_DOWNLOAD: 1:boot from flash, 0:download image from UART)
-	LOG_RX:		PA8
KEYs
-	KEY_CFG:	PB2		(ext 10K PU)
LEDs
-	LED_R:		PA25
-	LED_B:  	PA28 	(also SWD_CLK)
-	LED_G: 		PA30
*/
/*********************************************************************************
*	pin mapping defines
*********************************************************************************/
// NCP control
#define GPIO_NCP_NRESET_PIN		PB_3    // Reset NCP
#define GPIO_NCP_BOOTLD_PIN		PB_21   // NCP bootsel
// KEY(s)
#define GPIO_KEY_CONFIG_PIN		PB_2    // Config button
// LED(s)
#define GPIO_LED_R_PIN			PA_25   // PWM4
#define GPIO_LED_G_PIN  		PA_28   // PWM6
#define GPIO_LED_B_PIN			PA_30   // PWM7
#define NUM_LEDS				3       // number of LEDs

/*********************************************************************************
*	defines
*********************************************************************************/
// LED brinking timings (in ms)
#if LED_BLINKING_GTMR
// AmebaD GTimer period < 65535ms
#define FAST_BLINK_PERIOD       200
#define FAST_BLINK_WIDTH        100
#define SLOW_BLINK_PERIOD       2000
#define SLOW_BLINK_WIDTH        100
#else
// AmebaD PWM timer period must < 419ms
#define FAST_BLINK_PERIOD       200
#define FAST_BLINK_WIDTH        100
#define SLOW_BLINK_PERIOD       400
#define SLOW_BLINK_WIDTH        100
#endif

// Button detection timings (in ms)
#define SHORT_PRESS_THRESHOLD   500
#define PRESSED_AND_HELD_3S     3000
#define PRESSED_AND_HELD_8S     8000
#define MAX_KEY_COUNT           65535

/*********************************************************************************
*	macro function defines
*********************************************************************************/
#if ENABLE_LED_TRACE
  #define LED_TRACE(...)                                        \
    do {                                                        \
        printf("\n\r\033[1;32;40m%s.%d: ", __func__, __LINE__); \
        printf(__VA_ARGS__);                                    \
        printf("\033[0m");                                      \
    } while (0)
#else
  #define LED_TRACE(...)
#endif

#if ENABLE_KEY_TRACE
  #define KEY_TRACE(...)                                        \
    do {                                                        \
        printf("\n\r\033[1;32;40m%s.%d: ", __func__, __LINE__); \
        printf(__VA_ARGS__);                                    \
        printf("\033[0m");                                      \
    } while (0)
#else
  #define KEY_TRACE(...)
#endif

/*********************************************************************************
*	enums
*********************************************************************************/
// LED pin mode:
// GPIO for on/off or blinking
enum{
	LED_OUT = 0,
	LED_BLK
};

// LED index(by color):
enum{
	RED = 0,
	GREEN,
	BLUE
};

// Button state
enum{
	BUTTON_PRESSED = 0,
	BUTTON_RELEASE
};

/*********************************************************************************
*	global
*********************************************************************************/
PinName  led_pin[NUM_LEDS] =  {GPIO_LED_R_PIN, GPIO_LED_G_PIN, GPIO_LED_B_PIN};
uint8_t  led_cfg[NUM_LEDS];
#if LED_BLINKING_GTMR
// In order to achieve Green LED and Blue LED blinking together,
// Green LED is shareing the Blue LED's timer.
// Useage: calling Blue LED blink will only result in Blue LED blinking;
//         calling Green LED blink will result in both Blue and Green LED blinking (check the timer callback);
// Attention: To stop BLUE_GREEN blinking completely, need to call onoff for BLUE once before other LED operation
uint8_t  led_tmr[NUM_LEDS] = {TIMER2, TIMER3, TIMER3}; //only 2 gtimers available
volatile uint32_t led_onoff_us[NUM_LEDS][2];
gtimer_t gtmr_led[NUM_LEDS];
#else
pwmout_t pwm_led[3];
#endif
gpio_t   gpio_led[3];
gpio_t   gpio_keyCfg;

/*********************************************************************************
 *	function
 *********************************************************************************/
/**
 * @brief reset NCP
 * 
 * @param[in] enterBootLoader: 0 boots to NCP app, 1 boots to bootloader for DFU
 */
void ncp_hw_reset(int enterBootLoader)
{
#if BOARD_IO_ENABLE
    gpio_t gpio_ncp_btlmode, gpio_ncp_nreset;

    #if ENABLE_NCP_BOOTLOAD
    // NCP Boot Loader control
    gpio_init(&gpio_ncp_btlmode, GPIO_NCP_BOOTLD_PIN);
    gpio_dir(&gpio_ncp_btlmode,  PIN_OUTPUT);	// Output
    gpio_mode(&gpio_ncp_btlmode, PullNone);		// No pull
    // bootloaer to loader (active-high)
    gpio_write(&gpio_ncp_btlmode, (enterBootLoader? 1:0));	
    #endif

    #if ENABLE_NCP_RESET
    Pinmux_Swdoff();                            // Turn off SWD func
    // Init NCP _reset pin
    gpio_init(&gpio_ncp_nreset, GPIO_NCP_NRESET_PIN);
    gpio_dir(&gpio_ncp_nreset,  PIN_OUTPUT);	// Output
    gpio_mode(&gpio_ncp_nreset, PullNone);		// No pull
    // Reset NCP
    gpio_write(&gpio_ncp_nreset, 0);            // NCP nRESET=low
    for (int32_t i=0; i<100000; i++) asm("nop");// ~2ms
    gpio_write(&gpio_ncp_nreset, 1);            // NCP nRESET=high
    gpio_dir(&gpio_ncp_nreset,  PIN_INPUT);	    // Input (allow mini-simplicity to reset NCP)
    #endif
#endif //BOARD_IO_ENABLE
}

/**
 * @brief init the three LEDs to the designated states
 * 
 * @param[in] org_led_on: 0 is off, 1 is on
 * @param[in] grn_led_on: 0 is off, 1 is on
 * @param[in] blu_led_on: 0 is off, 1 is on
 */
void init_board_key_led(int16_t red_led_on, int16_t grn_led_on, int16_t blu_led_on)
{
#if BOARD_IO_ENABLE
    uint8_t i;

    // CONFIG key
    gpio_init(&gpio_keyCfg, GPIO_KEY_CONFIG_PIN);
    gpio_dir (&gpio_keyCfg, PIN_INPUT);		// Input
    gpio_mode(&gpio_keyCfg, PullNone);		// No pull

    // LEDs control
    for (i=0; i<(sizeof(led_pin)/sizeof(PinName)); i++) {
        // init GPIO
        gpio_init(&gpio_led[i], led_pin[i]);
        gpio_dir (&gpio_led[i], PIN_OUTPUT);	// Output
        gpio_mode(&gpio_led[i], PullNone);		// No pull
        led_cfg[i] = LED_OUT;
    }
    gpio_write(&gpio_led[RED],   !red_led_on);	// (active-low)
    gpio_write(&gpio_led[GREEN], !grn_led_on);	// (active-low)
    gpio_write(&gpio_led[BLUE],  !blu_led_on);	// (active-low)
#endif //BOARD_IO_ENABLE
}

#if LED_BLINKING_GTMR
void led_timer_timeout_handler(uint32_t id)
{
    uint8_t pin_state;

    if (id >= NUM_LEDS) {
        LED_TRACE("Wrong LED ID!");
        return;
    }

    pin_state = !gpio_read(&gpio_led[id]);

    // toggle pin high/low
    gpio_write(&gpio_led[id], pin_state); // (active-low)
    if (id == GREEN) {
        // Green LED shares BLUE's timer, so toggle the Blue LED too
        gpio_write(&gpio_led[BLUE], pin_state);
    }

    // reload pin on/off duration to timer
    gtimer_reload(&gtmr_led[id], led_onoff_us[id][pin_state & 0x01]);
    gtimer_start(&gtmr_led[id]);
}
#endif

/**
 * @brief set led pin to gpio output mode set led on/off
 *
 * @param[in] led: led index
 * @param[in] state: 0 is off, 1 is on
 */
void led_onoff(int led, int state)
{
#if BOARD_IO_ENABLE
    if (led_cfg[led] != LED_OUT) {
        #if LED_BLINKING_GTMR
        // stop GTimer
        if (led_tmr[led]) {
            gtimer_stop(&gtmr_led[led]);
            gtimer_deinit(&gtmr_led[led]);
        }
        #else
        // stop PWM
        pwmout_stop(&pwm_led[led]);
        pwmout_free(&pwm_led[led]);
        // init GPIO
        gpio_init(&gpio_led[led], led_pin[led]);
        gpio_dir (&gpio_led[led], PIN_OUTPUT); //outupt
        gpio_mode(&gpio_led[led], PullNone);   //no pull
        #endif
        led_cfg[led] = LED_OUT;
    }
    gpio_write(&gpio_led[led], !state);  //(active-low)
#endif //BOARD_IO_ENABLE
}

/**
 * @brief set led pin to pwm output mode set blink period and pluse width
 *
 * @param[in] led: led index
 * @param[in] period_ms: blink period in ms
 * @param[in] pulsewidth_ms: blink on pluse width in ms
 */
void led_blink(int led, int period_ms, int pulsewidth_ms)
{
#if BOARD_IO_ENABLE
    if (led_cfg[led] != LED_BLK) {
        #if LED_BLINKING_GTMR
        gpio_write(&gpio_led[led], 0); // led-on (active-low)
        // init GTimer
        if (led_tmr[led]) gtimer_init(&gtmr_led[led], led_tmr[led]);
        #else
        // de-init gpio
        gpio_dir(&gpio_led[led], PIN_INPUT); //input(Hi-Z)
        gpio_deinit(&gpio_led[led]);
        // init PWM
        pwmout_init(&pwm_led[led], led_pin[led]);
        pwmout_set_polarity(&pwm_led[led], 0); //active-low
        pwmout_stop(&pwm_led[led]);
        #endif
        led_cfg[led] = LED_BLK;
    }
    #if LED_BLINKING_GTMR
    if (led_tmr[led]) {
        led_onoff_us[led][0] = pulsewidth_ms*1000;
        led_onoff_us[led][1] = (period_ms-pulsewidth_ms)*1000;
        gtimer_start_periodical(&gtmr_led[led],
                                led_onoff_us[led][0],
                                (void*)led_timer_timeout_handler,
                                (uint32_t)led);
    }
    #else
    pwmout_period_ms(&pwm_led[led], period_ms);
    pwmout_pulsewidth_ms(&pwm_led[led], pulsewidth_ms);
    pwmout_start(&pwm_led[led]);
    #endif
#endif //BOARD_IO_ENABLE
}

/**
 * @brief set the LEDs' on/off state
 * 
 * @param[in] led_evt: check LED_EVENT_T
 * @return 0:succeeded, -1: failed
 */
int16_t led_control(LED_EVENT_T led_evt)
{
#if BOARD_IO_ENABLE
    static uint8_t led_evt_prev = LED_OFF;

    LED_TRACE("led_evt: %d, led_evt_prev: %d", led_evt, led_evt_prev);
    if (led_evt_prev >= LED_PRIVILEGE_START && led_evt < LED_PRIVILEGE_START) {
        LED_TRACE("LED ctl failed due to privilege in use.");
        return -1;
    }
    switch (led_evt) {
         case LED_OFF:
            LED_TRACE("All LEDs off");
            led_onoff(RED,  OFF);
            led_onoff(GREEN,OFF);
            led_onoff(BLUE, OFF);
            break;
        case LED_RED_OFF:
        case LED_ZB_NWK_OFF:
            LED_TRACE("Red LED off");
            led_onoff(RED, OFF);
            break;
        case LED_GREEN_OFF:
        case LED_POWER_OFF:
        case LED_CLOUD_DISCONNECTED:
            LED_TRACE("Green LED off");
            led_onoff(GREEN, OFF);
            break;
        case LED_BLUE_OFF:
        case LED_WIFI_OFF:
        case LED_WIFI_PROV_END:
            LED_TRACE("Blue LED off");
            led_onoff(BLUE, OFF);
            break;
        case LED_RED_ON:
        case LED_ZB_NWK_ERR:
            LED_TRACE("Red LED on");
            led_onoff(RED, ON);
            break;
        case LED_GREEN_ON:
        case LED_POWER_ON:
            LED_TRACE("Green LED on");
            led_onoff(GREEN, ON);
            break;
        case LED_BLUE_ON:
        case LED_WIFI_ERR:
            LED_TRACE("Blue LED on");
            led_onoff(BLUE, ON);
            break;
        case LED_BLUE_GREEN_ON:
        case LED_FATCTORY_RESET_ZIGBEE_STARTUP:
            LED_TRACE("Blue and Green LEDs on");
            led_onoff(BLUE, ON);
            led_onoff(RED,  OFF);
            led_onoff(GREEN, ON);
            break;
        case LED_FATCTORY_RESET_ZIGBEE_END:
            // To stop BLUE_GREEN blinking completely, need to call onoff for BLUE once before other LED operation
            // in order to trigger BLUE's timer init in the next possible blink operation,
            // otherwise the BLUE blink timer (TIMER3) will always call the GREEN blink's callback,
            // causing BLUE_GREEN fast blinking after setting BLUE blink only
            led_onoff(BLUE,  OFF);
            break;
        case LED_FATCTORY_RESET_ZIGBEE_WIFI_END:
        case LED_FATCTORY_RESET_ZIGBEE_WIFI_STARTUP:
        case LED_ALL_ON:
            LED_TRACE("All LEDs on");
            led_onoff(RED, ON);
            led_onoff(BLUE, ON);
            led_onoff(GREEN, ON);
           break;
        case LED_WIFI_PROV_START:
            LED_TRACE("Blue LED fast-blinking");
            led_blink(BLUE, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            break;
        case LED_WIFI_CONNECTED:
            LED_TRACE("Blue LED slow-blinking");
            led_blink(BLUE, SLOW_BLINK_PERIOD, SLOW_BLINK_WIDTH);
            break;
        case LED_ZB_NWK_ON:
        case LED_ZB_CLOSE_JOIN:
            LED_TRACE("Red LED slow-blinking");
            led_blink(RED, SLOW_BLINK_PERIOD, SLOW_BLINK_WIDTH);
            break;
        case LED_ZB_PERMIT_JOIN:
            LED_TRACE("Red LED fast-blinking");
            led_blink(RED, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            break;
        case LED_CLOUD_CONNECTED:
            LED_TRACE("Green LED on");
            led_onoff(GREEN, ON);
            break;
        case LED_FATCTORY_RESET_ZIGBEE:
            LED_TRACE("Blue and Green LED fast-blinking");
            led_blink(BLUE, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            // call breen blink after blue
            led_blink(GREEN, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            break;
        case LED_FATCTORY_RESET_ZIGBEE_WIFI:
            LED_TRACE("All LEDs fast-blinking");
            led_blink(RED, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            led_blink(BLUE, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            // call breen blink after blue
            led_blink(GREEN, FAST_BLINK_PERIOD, FAST_BLINK_WIDTH);
            break;
        default:
            break;
    }
    if (led_evt == LED_FATCTORY_RESET_ZIGBEE_END) {
        // set evt_pre to 0 to exit privilege mode
        led_evt_prev = LED_OFF;
    } else {
        led_evt_prev = led_evt;
    }
#endif //BOARD_IO_ENABLE
    return 0;
}

/**
 * @brief return whether the Config button is pressed
 * 
 * @return 0: not pressed, 1: pressed
 */
int16_t is_ConfigButton_pressed(void)
{
#if BOARD_IO_ENABLE
    // pressed:  low (0)
    // released: high(1)
    return !(gpio_read(&gpio_keyCfg));
#else
    return 0;
#endif //BOARD_IO_ENABLE
}

/**
 * @brief poll button(s) and get any key event
 * 
 * @param[in] poll_interval_ms: key polling interval
 * @return: key event
 */
KEY_EVENT_T get_button_poll_event(int poll_interval_ms)
{
#if BOARD_IO_ENABLE
    static uint16_t press_count = 0;
    static uint8_t  wait_release_3s = 0;
    static uint8_t  wait_release_8s = 0;
    static uint8_t  last_keystate = BUTTON_RELEASE;

    KEY_EVENT_T ret = KEY_NONE;
    int keystate;

    keystate = gpio_read(&gpio_keyCfg);
    if (keystate == BUTTON_RELEASE) {
        // detect button release action
        if (last_keystate == BUTTON_PRESSED) {
            if (press_count < (SHORT_PRESS_THRESHOLD/poll_interval_ms)) {
                ret = KEY_CONFIG_PRESSED;
                KEY_TRACE("CONFIG key presssed\n\r");
            } else if (press_count >= (PRESSED_AND_HELD_3S/poll_interval_ms)
                       && press_count < (PRESSED_AND_HELD_8S/poll_interval_ms)) {
                ret = KEY_CONFIG_PRESSED_HELD_3S;
                KEY_TRACE("CONFIG key held 3 seconds\n\r");
            }
        }
        press_count = 0;
        wait_release_3s = 0;
        wait_release_8s = 0;
    } else {
        //printf(".");
        if (press_count < MAX_KEY_COUNT) press_count++;
        // detect button held timing
        if (!wait_release_3s && press_count >= (PRESSED_AND_HELD_3S/poll_interval_ms)) {
            KEY_TRACE("CONFIG key pressing 3 seconds\n\r");
            ret = KEY_CONFIG_PRESSING_3S;
            wait_release_3s = 1;
        }
        if (!wait_release_8s && press_count >= (PRESSED_AND_HELD_8S/poll_interval_ms)) {
            KEY_TRACE("CONFIG key held 8 seconds\n\r");
            ret = KEY_CONFIG_PRESSED_HELD_8S;
            wait_release_8s = 1;
        }
    }
    last_keystate = keystate;

    return ret;
#else
    return KEY_NONE;
#endif //BOARD_IO_ENABLE
}
