#ifndef _hashing_H_
#define _hashing_H_

int installCodeToLinkKey(int installCodeLength, unsigned char *installCode, unsigned char *hashResult);

#endif
