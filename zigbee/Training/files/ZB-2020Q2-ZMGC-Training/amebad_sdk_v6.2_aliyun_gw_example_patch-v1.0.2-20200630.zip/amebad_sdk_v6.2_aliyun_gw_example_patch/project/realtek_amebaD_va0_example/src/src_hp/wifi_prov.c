#include "cloud_gateway.h"
#include "cloud_gateway_interface.h"

#include <lwip_netconf.h>
#include <platform_opts.h>

#include "wifi_conf.h"
#include "wifi_constants.h"
#include "wifi_structures.h"

/*********************************************************************************
 *	Wi-Fi related
 *********************************************************************************/
uint16_t is_wifi_connected(void)
{
    return (uint16_t)((!wifi_is_up(RTW_STA_INTERFACE) || wifi_is_connected_to_ap() != RTW_SUCCESS) ? 0 : 1);
}

void erase_wifi_fastcon_data(void)
{
#if CONFIG_EXAMPLE_WLAN_FAST_CONNECT
    Erase_Fastconnect_data();
#endif
}

#if WIFI_PROVISION_ENABLE

#if WIFI_PROV_AWSS_DEV_AP_ENABLE
void *start_dev_ap_wifi_prov_thread_handle = NULL;

void *start_dev_ap_wifi_prov_thread(void *arg)
{
    int16_t ret;

    // thread_sleep_ms(1000);
    USER_TRACE("Enable Wi-Fi");
    if (wifi_on(RTW_MODE_STA) < 0) {
        ERROR_TRACE("ERROR: wifi_on failed");
        goto exit;
    }

    USER_TRACE("Starting device AP");
    ret = awss_dev_ap_start();
    if (0 != ret) {
        ERROR_TRACE("Start device AP WiFi provisioning fail\n");
        // return ret;
    }

    USER_TRACE("Stoping device AP");
    awss_dev_ap_stop();

exit:
    thread_delete(start_dev_ap_wifi_prov_thread_handle);

    return NULL;
}

void start_dev_ap_prov_wifi_provision(void)
{
    int user_stacksize = 0;
    int res;
    os_thread_params_t user_thread = {OS_THREAD_PRIO_NORMAL, NULL, 2 * 1024, 0, "start_dev_ap_wifi_prov_thread"};
    USER_TRACE("thread_create(\"%s\", stack_size=%d, priority=%d)\n", user_thread.name, user_thread.stack_size,
                  user_thread.priority);
    res = thread_create(&start_dev_ap_wifi_prov_thread_handle, start_dev_ap_wifi_prov_thread, NULL, &user_thread,
                        &user_stacksize);
    if (res < 0) {
        USER_TRACE("%s thread_create failed\n", __FUNCTION__);
    }
}
#endif //WIFI_PROV_AWSS_DEV_AP_ENABLE

void *start_wifi_prov_thread_handle = NULL;

void *start_wifi_prov_thread(void *arg)
{
    USER_TRACE("start wifi provisioning...");

    while (!wifi_is_up(RTW_STA_INTERFACE)) {
        thread_sleep_ms(500);
    }
    led_control(LED_WIFI_PROV_START);

#if WIFI_PROV_AWSS_DEV_AP_ENABLE
    start_dev_ap_prov_wifi_provision();
#endif

exit:
    thread_delete(start_wifi_prov_thread_handle);

    return NULL;
}

#endif //WIFI_PROVISION_ENABLE
