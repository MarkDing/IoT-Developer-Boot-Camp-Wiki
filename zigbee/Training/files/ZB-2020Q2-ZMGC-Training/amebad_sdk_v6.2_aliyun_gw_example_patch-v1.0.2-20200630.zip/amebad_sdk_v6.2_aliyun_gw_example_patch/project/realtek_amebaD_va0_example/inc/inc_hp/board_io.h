#ifndef _BOARD_IO_H_
#define _BOARD_IO_H_

typedef enum led_event {
    LED_OFF = 0,
    LED_RED_OFF,
    LED_GREEN_OFF,
    LED_BLUE_OFF,
    LED_RED_ON,
    LED_GREEN_ON,
    LED_BLUE_ON,
    LED_BLUE_GREEN_ON,
    LED_ALL_ON,
    LED_POWER_OFF,
    LED_POWER_ON,
    LED_WIFI_OFF,
    LED_WIFI_ERR,
    LED_WIFI_PROV_START,
    LED_WIFI_PROV_END,
    LED_WIFI_CONNECTED,
    LED_ZB_NWK_OFF,
    LED_ZB_NWK_ERR,
    LED_ZB_NWK_ON,
    LED_ZB_PERMIT_JOIN,
    LED_ZB_CLOSE_JOIN,
    LED_CLOUD_CONNECTED,
    LED_CLOUD_DISCONNECTED,
    LED_PRIVILEGE_START = 0xF0,
    LED_FATCTORY_RESET_ZIGBEE = 0xFA,
    LED_FATCTORY_RESET_ZIGBEE_STARTUP = 0xFB,
    LED_FATCTORY_RESET_ZIGBEE_END = 0xFC,
    LED_FATCTORY_RESET_ZIGBEE_WIFI = 0xFD,
    LED_FATCTORY_RESET_ZIGBEE_WIFI_STARTUP = 0xFE,
    LED_FATCTORY_RESET_ZIGBEE_WIFI_END = 0xFF
} LED_EVENT_T;

typedef enum key_event {
    KEY_NONE = 0,
    KEY_CONFIG_PRESSED,
    KEY_CONFIG_PRESSING_3S,
    KEY_CONFIG_PRESSED_HELD_3S,
    KEY_CONFIG_PRESSED_HELD_8S
} KEY_EVENT_T;

void ncp_hw_reset(int enterBootLoader);
void init_board_key_led(int16_t org_led_on, int16_t grn_led_on, int16_t blu_led_on);

int16_t led_control(LED_EVENT_T led_evt);
int16_t is_ConfigButton_pressed(void);
KEY_EVENT_T get_button_poll_event(int poll_interval_ms);

#endif
