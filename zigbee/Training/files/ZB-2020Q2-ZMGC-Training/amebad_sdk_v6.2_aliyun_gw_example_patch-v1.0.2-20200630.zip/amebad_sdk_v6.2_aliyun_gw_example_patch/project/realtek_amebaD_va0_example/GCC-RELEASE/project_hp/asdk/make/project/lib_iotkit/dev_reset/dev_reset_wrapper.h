#ifndef _DEV_RESET_WRAPPER_H_
#define _DEV_RESET_WRAPPER_H_

int HAL_Snprintf(char *str, const int len, const char *fmt, ...);

#endif

