
/***************************************************************************//**
 * @file
 * @brief APIs and defines for the message queue for FreeRTOS.
 *******************************************************************************
 * # License
 * <b>Copyright 2018 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef SILABS_MSG_H
#define SILABS_MSG_H
#define MAX_MSG_NAME 32
struct _msgObj;

typedef bool (txFunc) (struct _msgObj *, void *, TickType_t);

typedef struct _msgInfo {
  char name[MAX_MSG_NAME];
  QueueHandle_t handler;
} MsgInfo;

typedef struct _msgObj {
  txFunc * send;
  txFunc * recv;
  uint16_t (*itemsInQueue)(struct _msgObj *);
  MsgInfo info;
} MsgObj;

MsgObj * createMsg(uint16_t itemSize, uint16_t queueSize, char * name);
void removeMsg(MsgObj * msgObj);
MsgObj * findMsgByName(char * name);

#endif //SILABS_MSG_H
