#include <lwip_netconf.h>
#include <string.h>
#include "infra_config.h"
#include "infra_defs.h"
#include "lwip/ip_addr.h"
#include "main.h"
#include "platform_opts.h"
#include "wifi_conf.h"
#include "wrappers_defs.h"

#ifdef DEV_BIND_ENABLED
#include "dev_bind_wrapper.h"
#endif

#include "wifi_constants.h"

#if defined(WIFI_PROVISION_ENABLED)
/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */

#include "iot_import_awss.h"

extern int error_flag;

/**
 * @brief   获取配网服务(`AWSS`)的超时时间长度, 单位是毫秒
 *
 * @return  超时时长, 单位是毫秒
 * @note    推荐时长是60,0000毫秒
 */
int HAL_Awss_Get_Timeout_Interval_Ms(void)
{
    return 30 * 60 * 1000;
}

/**
 * @brief   获取在每个信道(`channel`)上扫描的时间长度, 单位是毫秒
 *
 * @return  时间长度, 单位是毫秒
 * @note    推荐时长是200毫秒到400毫秒
 */
int HAL_Awss_Get_Channelscan_Interval_Ms(void)
{
    return 250;
}

/**
 * @brief   设置Wi-Fi网卡工作在监听(Monitor)模式, 并在收到802.11帧的时候调用被传入的回调函数
 *
 * @param[in] cb @n A function pointer, called back when wifi receive a frame.
 */
void HAL_Awss_Open_Monitor(_IN_ awss_recv_80211_frame_cb_t cb)
{
}

/**
 * @brief   设置Wi-Fi网卡离开监听(Monitor)模式, 并开始以站点(Station)模式工作
 */
void HAL_Awss_Close_Monitor(void)
{
}

/**
 * @brief   设置Wi-Fi网卡切换到指定的信道(channel)上
 *
 * @param[in] primary_channel @n Primary channel.
 * @param[in] secondary_channel @n Auxiliary channel if 40Mhz channel is supported, currently
 *              this param is always 0.
 * @param[in] bssid @n A pointer to wifi BSSID on which awss lock the channel, most HAL
 *              may ignore it.
 */
void HAL_Awss_Switch_Channel(
            _IN_ char primary_channel,
            _IN_OPT_ char secondary_channel,
            _IN_OPT_ uint8_t bssid[ETH_ALEN])
{
    //wifi_set_channel
    if (primary_channel == 0) {
        HAL_TRACE("Designated Channel ID is 0, won't change");
    } else {
        HAL_TRACE("Set Channel to %d", primary_channel);
        wifi_set_channel(primary_channel);
    }
}

/**
 * @brief   要求Wi-Fi网卡连接指定热点(Access Point)的函数
 *
 * @param[in] connection_timeout_ms @n AP connection timeout in ms or HAL_WAIT_INFINITE
 * @param[in] ssid @n AP ssid
 * @param[in] passwd @n AP passwd
 * @param[in] auth @n optional(AWSS_AUTH_TYPE_INVALID), AP auth info
 * @param[in] encry @n optional(AWSS_ENC_TYPE_INVALID), AP encry info
 * @param[in] bssid @n optional(NULL or zero mac address), AP bssid info
 * @param[in] channel @n optional, AP channel info
 * @return
   @verbatim
     = 0: connect AP & DHCP success
     = -1: connect AP or DHCP fail/timeout
   @endverbatim
 * @see None.
 * @note
 *      If the STA connects the old AP, HAL should disconnect from the old AP firstly.
 *      If bssid specifies the dest AP, HAL should use bssid to connect dest AP.
 */
int HAL_Awss_Connect_Ap(
            _IN_ uint32_t connection_timeout_ms,
            _IN_ char ssid[HAL_MAX_SSID_LEN],
            _IN_ char passwd[HAL_MAX_PASSWD_LEN],
            _IN_OPT_ enum AWSS_AUTH_TYPE auth,
            _IN_OPT_ enum AWSS_ENC_TYPE encry,
            _IN_OPT_ uint8_t bssid[ETH_ALEN],
            _IN_OPT_ uint8_t channel)
{
    int      ret   = -1;
    uint16_t retry = 0;

    HAL_TRACE("Enable Wi-Fi");
    if (wifi_on(RTW_MODE_STA) < 0) {
        HAL_ERR_TRACE("ERROR: wifi_on failed");
        return -1;
    }

    if (channel == 0) {
        HAL_TRACE("Designated Channel ID is 0, won't change");
    } else {
        HAL_TRACE("Set Channel to %d", channel);
        wifi_set_channel(channel);
    }

    while (ret == -1 && retry++ < 3) {
        HAL_TRACE("Connect to AP \"%s\" use STA mode..., try %d", ssid, retry);
        // todo: need a translation for security type from awws to RTW
        if (wifi_connect(ssid, RTW_SECURITY_WPA_AES_PSK, passwd, strlen(ssid), strlen(passwd), -1, NULL) != RTW_SUCCESS) {
            HAL_ERR_TRACE("wifi_connect failed");
            ret = -1;
        } else {
            HAL_TRACE("Connected to AP \"%s\" use STA mode...", ssid);

            LwIP_DHCP(0, DHCP_START);
            if (error_flag == RTW_NO_ERROR) {
                HAL_TRACE("DHCP success");
                ret = 0;
            } else {
                // DHCP fail, might caused by timeout or the AP did not enable DHCP server
                if (error_flag == RTW_DHCP_FAIL) {
                    HAL_ERR_TRACE("DHCP fail, might caused by timeout or the AP did not enable DHCP server");
                }
                ret = -1;
            }
        }
    }
    return ret;
}

/**
 * @brief check system network is ready(get ip address) or not.
 *
 * @param None.
 * @return 0, net is not ready; 1, net is ready.
 * @see None.
 * @note None.
 */
int HAL_Sys_Net_Is_Ready()
{
    return 0;
}

/**
 * @brief   在当前信道(channel)上以基本数据速率(1Mbps)发送裸的802.11帧(raw 802.11 frame)
 *
 * @param[in] type @n see enum HAL_Awss_frame_type, currently only FRAME_BEACON
 *                      FRAME_PROBE_REQ is used
 * @param[in] buffer @n 80211 raw frame, include complete mac header & FCS field
 * @param[in] len @n 80211 raw frame length
 * @return
   @verbatim
   =  0, send success.
   = -1, send failure.
   = -2, unsupported.
   @endverbatim
 * @see None.
 * @note awss use this API send raw frame in wifi monitor mode & station mode
 */
int HAL_Wifi_Send_80211_Raw_Frame(_IN_ enum HAL_Awss_Frame_Type type,
                                  _IN_ uint8_t *buffer, _IN_ int len)
{
    // no one calls it
    return 0;
}


/**
 * @brief   在站点(Station)模式下使能或禁用对管理帧的过滤
 *
 * @param[in] filter_mask @n see mask macro in enum HAL_Awss_frame_type,
 *                      currently only FRAME_PROBE_REQ_MASK & FRAME_BEACON_MASK is used
 * @param[in] vendor_oui @n oui can be used for precise frame match, optional
 * @param[in] callback @n see awss_wifi_mgmt_frame_cb_t, passing 80211
 *                      frame or ie to callback. when callback is NULL
 *                      disable sniffer feature, otherwise enable it.
 * @return
   @verbatim
   =  0, success
   = -1, fail
   = -2, unsupported.
   @endverbatim
 * @see None.
 * @note awss use this API to filter specific mgnt frame in wifi station mode
 */
int HAL_Wifi_Enable_Mgmt_Frame_Filter(
            _IN_ uint32_t filter_mask,
            _IN_OPT_ uint8_t vendor_oui[3],
            _IN_ awss_wifi_mgmt_frame_cb_t callback)
{
    // no one calls it
    return 0;
}

/**
 * @brief   启动一次Wi-Fi的空中扫描(Scan)
 *
 * @param[in] cb @n pass ssid info(scan result) to this callback one by one
 * @return 0 for wifi scan is done, otherwise return -1
 * @see None.
 * @note
 *      This API should NOT exit before the invoking for cb is finished.
 *      This rule is something like the following :
 *      HAL_Wifi_Scan() is invoked...
 *      ...
 *      for (ap = first_ap; ap <= last_ap; ap = next_ap){
 *        cb(ap)
 *      }
 *      ...
 *      HAL_Wifi_Scan() exit...
 */
int HAL_Wifi_Scan(awss_wifi_scan_result_cb_t cb)
{
    // no one calls it
    return 0;
}

/**
 * @brief   获取所连接的热点(Access Point)的信息
 *
 * @param[out] ssid: array to store ap ssid. It will be null if ssid is not required.
 * @param[out] passwd: array to store ap password. It will be null if ap password is not required.
 * @param[out] bssid: array to store ap bssid. It will be null if bssid is not required.
 * @return
   @verbatim
     = 0: succeeded
     = -1: failed
   @endverbatim
 * @see None.
 * @note
 *     If the STA dosen't connect AP successfully, HAL should return -1 and not touch the ssid/passwd/bssid buffer.
 */
int HAL_Wifi_Get_Ap_Info(
            _OU_ char ssid[HAL_MAX_SSID_LEN],
            _OU_ char passwd[HAL_MAX_PASSWD_LEN],
            _OU_ uint8_t bssid[ETH_ALEN])
{
    HAL_TRACE("to get AP info");
    if (wifi_is_connected_to_ap() != RTW_SUCCESS) {
        HAL_TRACE("\n\rNot connected to AP yet!\n");
        return -1;
    }
    if (ssid != NULL && wext_get_ssid(WLAN0_NAME, (unsigned char *)ssid) < 0) {
        HAL_TRACE("\n\rWIFI disconnected");
        return -1;
    }
    HAL_TRACE("SSID: %s", ssid);
    return 0;
}

#include "netif.h"
extern struct netif xnetif[];
void dhcps_init(struct netif * pnetif);
void dhcps_deinit(void);
/* @brief   打开当前设备热点，并把设备由SoftAP模式切换到AP模式
 */
int HAL_Awss_Open_Ap(const char *ssid, const char *passwd, int beacon_interval, int hide)
{
#if CONFIG_LWIP_LAYER
    struct ip_addr ipaddr;
    struct ip_addr netmask;
    struct ip_addr gw;
    struct netif * pnetif = &xnetif[0];
#endif
    int            timeout = 20;
    volatile int   ret     = RTW_SUCCESS;
    rtw_security_t security_type;

    int str_len = strlen(passwd);
    if (str_len == 0) {
        security_type = RTW_SECURITY_OPEN;
    } else {
        if (str_len <= RTW_MAX_PSK_LEN &&
            str_len >= RTW_MIN_PSK_LEN) {
            security_type = RTW_SECURITY_WPA2_AES_PSK;

        } else if (str_len == 5) {
            security_type = RTW_SECURITY_WEP_PSK;
        } else {
            HAL_ERR_TRACE("Error: password should be 64 hex characters or 8-63 ASCII characters");
            return -1;
        }
    }

#if CONFIG_LWIP_LAYER
    dhcps_deinit();
#if LWIP_VERSION_MAJOR >= 2
    IP4_ADDR(ip_2_ip4(&ipaddr), GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
    IP4_ADDR(ip_2_ip4(&netmask), NETMASK_ADDR0, NETMASK_ADDR1, NETMASK_ADDR2, NETMASK_ADDR3);
    IP4_ADDR(ip_2_ip4(&gw), GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
    netif_set_addr(pnetif, ip_2_ip4(&ipaddr), ip_2_ip4(&netmask), ip_2_ip4(&gw));
#else
    IP4_ADDR(&ipaddr, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
    IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1, NETMASK_ADDR2, NETMASK_ADDR3);
    IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
    netif_set_addr(pnetif, &ipaddr, &netmask, &gw);
#endif
#ifdef CONFIG_DONT_CARE_TP
    pnetif->flags |= NETIF_FLAG_IPSWITCH;
#endif
#endif

    /*********************************************************************************
	*	1. Disable Wi-Fi			
	*********************************************************************************/
    HAL_TRACE("Disable Wi-Fi");
    wifi_off();
    vTaskDelay(20);

    /*********************************************************************************
	*	2. Enable Wi-Fi with AP mode			
	*********************************************************************************/
    HAL_TRACE("Enable Wi-Fi with AP mode");
    if (wifi_on(RTW_MODE_AP) < 0) {
        HAL_ERR_TRACE("Wifi on failed!");
        return -1;
    }

#if defined(CONFIG_ENABLE_WPS_AP) && CONFIG_ENABLE_WPS_AP
    wpas_wps_dev_config(pnetif->hwaddr, 1);
#endif
    /*********************************************************************************
	*	3. Start AP			
	*********************************************************************************/
    HAL_TRACE("Starting AP ...");
    //ssid = "RTL_AP";
    ;
    //password = "12345678";
    int channel = 1;
    if (hide) {
        if (wifi_start_ap_with_hidden_ssid((char *)ssid, security_type, (char *)passwd, strlen(ssid), strlen(passwd), channel) < 0) {
            HAL_ERR_TRACE("wifi_start_ap (hidden) failed\n");
            return -1;
        }
    } else {
        if (wifi_start_ap((char *)ssid, security_type, (char *)passwd, strlen(ssid), strlen(passwd), channel) < 0) {
            HAL_ERR_TRACE("wifi_start_ap failed\n");
            return -1;
        }
    }
    HAL_TRACE("Started AP\n");

    /*********************************************************************************
	*	4. Start DHCP			
	*********************************************************************************/
#if CONFIG_LWIP_LAYER
    HAL_TRACE("Starting DHCP ...");
    //LwIP_UseStaticIP(pnetif);
    dhcps_init(pnetif);
#endif

    return 0;
}

/* @brief   关闭当前设备热点，并把设备由SoftAP模式切换到Station模式
*/
int HAL_Awss_Close_Ap(void)
{
    if (wifi_is_up(RTW_STA_INTERFACE)) {
        HAL_TRACE("Already ini station mode");
        return 0;
    }

    HAL_TRACE("to switch from AP to station mode");
    wifi_off();

    if (wifi_on(RTW_MODE_STA) < 0) {
        HAL_ERR_TRACE("ERROR: wifi_on failed");
        return -1;
    }
    return 0;
}

#endif  /* #if defined(HAL_AWSS) */

#ifdef DEV_BIND_ENABLED

/**
 * @brief   获取Wi-Fi网口的MAC地址, 格式应当是"XX:XX:XX:XX:XX:XX"
 *
 * @param   mac_str : 用于存放MAC地址字符串的缓冲区数组
 * @return  指向缓冲区数组起始位置的字符指针
 */
char *HAL_Wifi_Get_Mac(_OU_ char mac_str[HAL_MAC_LEN])
{
    //strcpy(mac_str, "18:FE:34:12:33:44");
    wifi_get_mac_address(mac_str);
    return mac_str;
}
#endif

