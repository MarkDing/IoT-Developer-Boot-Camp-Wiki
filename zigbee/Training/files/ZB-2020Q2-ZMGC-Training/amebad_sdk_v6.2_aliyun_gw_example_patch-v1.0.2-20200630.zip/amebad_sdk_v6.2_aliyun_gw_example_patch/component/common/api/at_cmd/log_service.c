#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "FreeRTOS.h"
#if defined(configUSE_WAKELOCK_PMU) && (configUSE_WAKELOCK_PMU == 1)
#include "freertos_pmu.h"
#endif
#include "log_service.h"
#include "task.h"
#include "semphr.h"
#include "main.h"
//#include "wifi_util.h"
#include "atcmd_wifi.h"
#if (defined(CONFIG_EXAMPLE_UART_ATCMD) && CONFIG_EXAMPLE_UART_ATCMD) || (defined(CONFIG_EXAMPLE_SPI_ATCMD) && CONFIG_EXAMPLE_SPI_ATCMD) 
#include "atcmd_lwip.h"
#endif
#if defined(CONFIG_PLATFORM_8710C)
#include <platform_opts_bt.h>
#endif
#include "osdep_service.h"

#include "platform_opts.h"
#if LOGSEV_ZIGBEE_CLI_CMD
#include "msg.h"
#include "silabs-host-cmd.h"

#define MAX_DEVICE 100
#define DEFAULT_MAX_REPORTING_TIME 10
#define DEFAULT_MIN_REPORTING_TIME 0
#endif //LOGSEV_ZIGBEE_CLI_CMD

#if SUPPORT_LOG_SERVICE
//======================================================
struct list_head log_hash[ATC_INDEX_NUM];

extern void at_wifi_init(void);
extern void at_fs_init(void);
extern void at_sys_init(void);
extern void at_ethernet_init(void);
extern void at_google_init(void);
extern void at_transport_init(void);
//extern void at_app_init(void);
extern void at_mp_init(void);
extern void at_bt_init(void);
extern void at_qr_code_init(void);
extern void at_isp_init(void);
#if (CONFIG_JOYLINK || CONFIG_GAGENT || CONFIG_QQ_LINK || 	\
	(defined(CONFIG_AIRKISS_CLOUD) && CONFIG_AIRKISS_CLOUD) || CONFIG_ALINK || \
	(defined(CONFIG_HILINK) && CONFIG_HILINK) || (defined(CONFIG_MIIO) && CONFIG_MIIO))
extern void at_cloud_init(void);
#endif
void at_log_init(void);

char log_buf[LOG_SERVICE_BUFLEN];

#if LOGSEV_ZIGBEE_CLI_CMD
DevInfo_t deviceInfoTable[MAX_DEVICE];
Eui64_t ncpEui;
static const char * deviecStatusText[] = {
  "Joined",
  "Unresponsive",
  "Leave Sent",
  "Left",
};

typedef struct _cmdStruct {
  uint32_t cmdIndex;
  char * cmdStr;
  char * usage;
} CmdStruct_t;

static const CmdStruct_t z2Cmd[] = {
  {
    0,
    "print\0",
    "z2 print\r\n\0"
  },
  {
    1,
    "create\0",
    "z2 create\r\n\0"
  },
  {
    2,
    "leave\0",
    "z2 leave\r\n\0"
  },
  {
    3,
    "open\0",
    "z2 open ...\r\n\0",
  },
  {
    4,
    "close\0",
    "z2 close\r\n\0"
  },
  {
    17,
    "ncpupdate\0",
    "z2 ncpupdate <file size>\r\n\0"
  },
  {
    14,
    "ota-reload\0",
    "z2 ota-reload\r\n\0",
  },
#if LOGSEV_PROCESS_UP_MSG
  {
    5,
    "cmd\0",
    "z2 cmd u <devIdx> 0x<2 byte: clusterId> 0x<1 byte: cmdId> <1 byte:dataLen> 0x<data0> .. 0x<data n>\r\nz2 cmd m 0x<2 bytes: multicast addr> 0x<2 byte: clusterId> 0x<1 byte: cmdId> <1 byte:dataLen> 0x<data0> .. 0x<data n>\r\nz2 cmd b 0x<2 bytes: broadcast addr> 0x<2 byte: clusterId> 0x<1 byte: cmdId> <1 byte:dataLen> 0x<data0> .. 0x<data n>\r\n\0"},
  {
    6,
    "zcl-send\0",
    "z2 zcl-send u <devIdx> <endpoint> 0x<2 byte: clusterId> <dataLen> 0x<data0> .. 0x<data n>\r\nz2 zcl-send m 0x<2 bytes: multicast addr> <endpoint> 0x<2 byte: clusterId> <dataLen> 0x<data0> .. 0x<data n>\r\nz2 zcl-send b 0x<2 bytes: boardcast addr> <endpoint> 0x<2 byte: clusterId> <dataLen> 0x<data0> .. 0x<data n>\r\n\0"
  },
  {
    7,
    "del-entry\0",
    "z2 del-entry <devIdx>\r\n\0"
  },
  {
    8,
    "set-assn\0",
    "z2 set-assn <devIdx> 0x<2 byte: clusterId>\r\n\0"
  },
  {
    9,
    "clr-assn\0",
    "z2 clr-assn <devIdx> 0x<2 byte: clusterId>\r\n\0"
  },
  {
    10,
    "get-nwk\0",
    "z2 get-nwk\r\n\0"
  },
  {
    11,
    "report\0",
    "z2 report <devIdx> 0x<1byte: type> 0x<2 byte: clusterId> 0x<2 byte: attrId> 0x<2 byte: manuId>\r\n\0"
  },
  {
    12,
    "read\0",
    "read <devIdx> 0x<2 byte: clusterId> 0x<2 byte: attrId> 0x<2 byte: manuId>\r\n\0"
  },
  {
    13,
    "write\0",
    "z2 write <devIdx>  0x<1byte: type> 0x<2 byte: clusterId> 0x<2 byte: attrId> 0x<2 byte: manuId> <dataLen> 0x<data 0> .. 0x<data n>\r\n\0"
  },
  {
    15,
    "ota-notify\0",
    "z2 ota-notify <devIdx> 0x<2 byte: manuId> 0x<2 byte: imageId> 0x<4 byte: version>\r\n\0"
  },
  {
    16,
    "dev-leave\0",
    "z2 dev-leave <devIdx> <allowRejoin>\r\n\0"
  }
#endif //LOGSEV_PROCESS_UP_MSG
};

#define CMD_TABLE_SIZE (sizeof(z2Cmd) / sizeof(CmdStruct_t))

static void printCmdStr(void)
{
  for (uint16_t i = 0; i < CMD_TABLE_SIZE; i++) {
    printf("    %s\r\n", z2Cmd[i].cmdStr);
  }
}
#endif //LOGSEV_ZIGBEE_CLI_CMD

#if CONFIG_LOG_HISTORY
char log_history[LOG_HISTORY_LEN][LOG_SERVICE_BUFLEN];
static unsigned int log_history_count = 0;
#endif
xSemaphoreHandle log_rx_interrupt_sema = NULL;
#if CONFIG_LOG_SERVICE_LOCK
xSemaphoreHandle log_service_sema = NULL; 
#endif
extern xSemaphoreHandle	uart_rx_interrupt_sema;

#if CONFIG_INIC_EN
extern unsigned char inic_cmd_ioctl;
#endif

//#if defined (__ICCARM__)
//#pragma section=".data.log_init"
//
//unsigned int __log_init_begin__;
//unsigned int __log_init_end__;
//#elif defined ( __CC_ARM   ) || defined(__GNUC__)
#if defined (__ICCARM__) || defined ( __CC_ARM   ) || defined(__GNUC__)
//#pragma section=".data.log_init"
log_init_t* __log_init_begin__;
log_init_t* __log_init_end__;
log_init_t log_init_table[] = {

#if CONFIG_WLAN
	at_wifi_init,
#endif

	//	at_fs_init,

#if (CONFIG_PLATFORM_AMEBA_X == 1)
	at_sys_init,
#endif	
	at_log_init,
	//	at_app_init,
#if CONFIG_ETHERNET  
	at_ethernet_init,
#endif  

#if (defined(CONFIG_GOOGLE_NEST) && CONFIG_GOOGLE_NEST)
	at_google_init,
#endif 

#if CONFIG_TRANSPORT  
	at_transport_init,
#endif

#if defined(CONFIG_ATCMD_MP) && CONFIG_ATCMD_MP
	at_mp_init,
#endif

#if defined(CONFIG_BT) && CONFIG_BT
	at_bt_init,
#endif
        
#if defined(CONFIG_ISP) && CONFIG_ISP
        at_isp_init,
#endif

#if (CONFIG_JOYLINK || CONFIG_GAGENT || CONFIG_QQ_LINK || (defined(CONFIG_AIRKISS_CLOUD) && \
	CONFIG_AIRKISS_CLOUD) || CONFIG_ALINK || (defined(CONFIG_HILINK) && CONFIG_HILINK) || (defined(CONFIG_MIIO) && CONFIG_MIIO))
	at_cloud_init,
#endif	
};
#else
#error "not implement, add to linker script"
extern unsigned int __log_init_begin__;
extern unsigned int __log_init_end__;
#endif

#if defined(__GNUC__) || defined(CONFIG_PLATFORM_8710C)
#define USE_STRSEP

#if defined(CONFIG_PLATFORM_8710C)
#if defined(CONFIG_BUILD_NONSECURE)
#if !defined(__GNUC__)
#include "strproc.h"
#endif
#define _strsep strsep
#else
#undef USE_STRSEP
#endif
#endif
#endif

#if LOGSEV_ZIGBEE_CLI_CMD
#define DEBUG_TRACE(...) \
    do { \
        printf("\n\r\033[1;32;40m%s.%d: ", __func__, __LINE__); \
        printf(__VA_ARGS__); \
        printf("\033[0m"); \
    } while (0)
#define ERROR_TRACE(...) \
    do { \
        printf("\n\r\033[31m%s.%d: ", __func__, __LINE__); \
        printf(__VA_ARGS__); \
        printf("\033[0m"); \
    } while(0)

#define PTR_NULL_CHK(p) \
    do {\
        if (NULL == p) {\
            ERROR_TRACE("input pointer is NULL.\n\r");\
            return -1;\
        }\
    } while(0)
#endif //LOGSEV_ZIGBEE_CLI_CMD

static xTaskHandle CreatedTask;
//======================================================
int hash_index(char *str)
{
    unsigned int seed = 131; // 31 131 1313 13131 131313 etc..
    unsigned int hash = 0;

    while (*str)
    {
        hash = hash * seed + (*str++);
    }

    return (hash & 0x7FFFFFFF);	
}

void log_add_new_command(log_item_t *new)
{
	int index = hash_index(new->log_cmd)%ATC_INDEX_NUM;
	
	list_add(&new->node, &log_hash[index]);
}
void start_log_service(void);
void log_service_init(void)
{
	unsigned int i;
	
//#if defined (__ICCARM__)
//	log_init_t *log_init_table;
//	__log_init_begin__ = (unsigned int)__section_begin(".data.log_init");
//	__log_init_end__ = (unsigned int)__section_end(".data.log_init");
//	log_init_table = (log_init_t *)__log_init_begin__;
//#elif defined(__CC_ARM) || defined(__GNUC__)
#if defined (__ICCARM__) || defined(__CC_ARM) || defined(__GNUC__)
	__log_init_begin__ = log_init_table;
	__log_init_end__ = __log_init_begin__ + sizeof(log_init_table)/sizeof(log_init_t);
#else
	#error "not implement"
#endif
		
	
	for(i=0;i<ATC_INDEX_NUM;i++)
		INIT_LIST_HEAD(&log_hash[i]);
	
	for(i=0;i<(unsigned int)(__log_init_end__-__log_init_begin__); i++)
		log_init_table[i]();

  	/* Initial uart rx swmaphore*/
	vSemaphoreCreateBinary(log_rx_interrupt_sema);
	xSemaphoreTake(log_rx_interrupt_sema, 1/portTICK_RATE_MS);
#if CONFIG_LOG_SERVICE_LOCK
	log_service_lock_init();
#endif
	start_log_service();
}

//sizeof(log_items)/sizeof(log_items[0])
void log_service_add_table(log_item_t *tbl, int len)
{
	int i;
	for(i=0;i<len;i++)
		log_add_new_command(&tbl[i]);	
}

void* log_action(char *cmd)
{
	int search_cnt=0;
	int index = hash_index(cmd)%ATC_INDEX_NUM;
	struct list_head *head = &log_hash[index];
	struct list_head *iterator;
	log_item_t *item;
	void *act = NULL;
	
	list_for_each(iterator, head) {
		item = list_entry(iterator, log_item_t, node);
		search_cnt++;
		if( strcmp(item->log_cmd, cmd) == 0){
			//printf("%s match %s, search cnt %d\n\r", cmd, item->log_cmd, search_cnt);
			act = (void*)item->at_act;
			break;
		}
	}
	
	return act;
}

void* log_handler(char *cmd)
{
	log_act_t action=NULL;
	char buf[LOG_SERVICE_BUFLEN];
	memset(buf, 0, LOG_SERVICE_BUFLEN);
	char *copy=buf;
	char *token = NULL;
	char *param = NULL;
	char tok[5] = {0};//'\0'
#if CONFIG_LOG_HISTORY
	strcpy(log_history[((log_history_count++)%LOG_HISTORY_LEN)], log_buf);
#endif
	strncpy(copy, cmd,LOG_SERVICE_BUFLEN-1);

#if defined(USE_STRSEP)
	token = _strsep(&copy, "=");
	param = copy;
#else
	token = strtok(copy, "=");
	param = strtok(NULL, "\0");
#endif
	if(token && (strlen(token) <= 4))
		strcpy(tok, token);
	else{
		//printf("\n\rAT Cmd format error!\n");
		return NULL;
	};
	//printf(" Command %s \n\r ", tok);
	//printf(" Param %s \n\r", param);
	action = (log_act_t)log_action(tok);
        
	if(action){	
		action(param);
	} 
	return (void*)action;

}

int parse_param(char *buf, char **argv)
{

	int argc = 1;
	char str_buf[LOG_SERVICE_BUFLEN];
	memset(str_buf, 0, LOG_SERVICE_BUFLEN);
	int str_count = 0;
	int buf_cnt = 0;
    static char temp_buf[LOG_SERVICE_BUFLEN];
    char *buf_pos = temp_buf;
    memset(temp_buf, 0, sizeof(temp_buf));

	if(buf == NULL)
		goto exit;
	strcpy(temp_buf, buf);
	
	while((argc < MAX_ARGC) && (*buf_pos != '\0')) {
		while((*buf_pos == ',') || (*buf_pos == '[') || (*buf_pos == ']')){
			if((*buf_pos == ',') && (*(buf_pos+1) == ',')){
				argv[argc] = NULL;
				argc++;
			}
			*buf_pos = '\0';
			buf_pos++;
		}

		if(*buf_pos == '\0')
			break;
		else if(*buf_pos == '"'){
			memset(str_buf,'\0',LOG_SERVICE_BUFLEN);
			str_count = 0;
			buf_cnt = 0;
			*buf_pos = '\0';
			buf_pos ++;         
			if(*buf_pos == '\0')
			break;
		    argv[argc] = buf_pos;
			while((*buf_pos != '"')&&(*buf_pos != '\0')){
				if(*buf_pos == '\\'){
		        buf_pos ++;
					buf_cnt++;
				}
				str_buf[str_count] = *buf_pos;
				str_count++;
				buf_cnt++;
			    buf_pos ++;
			}
			*buf_pos = '\0';
			memcpy(buf_pos-buf_cnt,str_buf,buf_cnt);
		}
		else{
			argv[argc] = buf_pos;
		}
		argc++;
		buf_pos++;

		while( (*buf_pos != ',')&&(*buf_pos != '\0')&&(*buf_pos != '[')&&(*buf_pos != ']') )
			buf_pos++;
	}
exit:
	return argc;
}

unsigned char  gDbgLevel = AT_DBG_ERROR;
unsigned int   gDbgFlag  = 0xFFFFFFFF;
void at_set_debug_level(unsigned char newDbgLevel)
{
    gDbgLevel = newDbgLevel;
}

void at_set_debug_mask(unsigned int newDbgFlag)
{
	gDbgFlag = newDbgFlag;
}

#if SUPPORT_INTERACTIVE_MODE
extern char uart_buf[64];
void legency_interactive_handler(unsigned char argc, unsigned char **argv)
{
	/* To avoid gcc warnings */
	( void ) argc;
	( void ) argv;
#if 0 //defined(CONFIG_PLATFORM_8195A)
   if(argc<1)
	{
		DiagPrintf("Wrong argument number!\r\n");
		return;
	}


	DiagPrintf("Wlan Normal Mode\n");

	WlanNormal( argc, argv);
#else
   strncpy(uart_buf, log_buf, 63);//uart_buf[64]
   xSemaphoreGive(uart_rx_interrupt_sema);
#endif
}
#endif

#if CONFIG_WLAN
#ifndef WLAN0_NAME
  #define WLAN0_NAME		"wlan0"
#endif
#ifndef WLAN1_NAME
  #define WLAN1_NAME		"wlan1"
#endif
extern int wext_private_command(const char *ifname, char *cmd, int show_msg);
int mp_commnad_handler(char *cmd)
{
	char buf[64];
	char *token = NULL;
	memset(buf, 0, 64);
	
	//strcpy(buf, cmd);
        strncpy(buf, cmd, (64-1));
	token = strtok(buf, " ");
	if(token && (strcmp(buf, "iwpriv") == 0)){
		token = strtok(NULL, "");
		wext_private_command(WLAN0_NAME, token, 1);
		return 0;
	}
	return -1;
}
#endif
void print_help_msg(void){
#if CONFIG_WLAN
extern void print_wlan_help(void);
        print_wlan_help();
#endif
//add other help message print here
}

int print_help_handler(char *cmd){
	if(strcmp(cmd, "help") == 0){
                print_help_msg();
                return 0;
	}
        return -1;
}

#if CONFIG_LOG_SERVICE_LOCK
void log_service_lock(void)
{
	rtw_down_sema(&log_service_sema);
}

u32 log_service_lock_timeout(u32 ms)
{
	return rtw_down_timeout_sema(&log_service_sema, ms);
}

void log_service_unlock(void)
{
	rtw_up_sema(&log_service_sema);
}

void log_service_lock_init(void){
	rtw_init_sema(&log_service_sema, 1);
}
#endif

#if LOGSEV_ZIGBEE_CLI_CMD
static int16_t sendMsg(void *data, TopDownMsgId_t id)
{
  TopDownMsg_t msg;
  MsgObj *     obj;

  obj = findMsgByName(GW_DOWN_QUEUE_NAME);
  if (NULL == obj) {
    printf("msg send error: msg Q not exist\r\n");
    return -1;
  }
  msg.id   = id;
  msg.data = data;
  msg.seq  = 0;
  if (obj->send(obj, &msg, 0) == false) {
    printf("msg send error\r\n");
    return -1;
  }
  return 0;
}

void create_network(void)
{
  CreateNwk_t *data;

  data         = malloc(sizeof(CreateNwk_t));
  data->random = 1;
  sendMsg((void *)data, CREATE_NWK);
}

void clearDeviceTable(void)
{
  for (int i = 0; i < MAX_DEVICE; i++) {
    memset(&deviceInfoTable[i], 0, sizeof(DevInfo_t));
  }
}

void leave_network(void)
{
  sendMsg(NULL, LEAVE_NWK);
  clearDeviceTable();
}

static unsigned char convert_hex_char_to_byte(unsigned char c)
{
  if (c >= 'A' && c <= 'F') {
    return c - 'A' + 0x0A;
  } else if (c >= 'a' && c <= 'f') {
    return c - 'a' + 0x0A;
  } else if (c >= '0' && c <= '9') {
    return c - '0';
  }
  return 0xFF;
}

// Transform a string of hex characters into an array of bytes.
// Returns number of bytes parsed on success, or -1 on error.
static int16_t parse_hex_byte_string(char *input_string, char *return_data, int16_t max_byte_length)
{
  uint16_t i;
  int16_t  length = strnlen(input_string, (max_byte_length * 2) + 1  // NULL terminator
                                             + 2);                  // '0x' prefix

  if (length >= 2 && input_string[0] == '0' && (input_string[1] == 'x' || input_string[1] == 'X')) {
    // Skip '0x' prefix
    input_string += 2;
    length -= 2;
  }

  if (length > (max_byte_length * 2)) {
    ERROR_TRACE("Input string (%d) cannot be longer than %d\n", length, max_byte_length);
    return -1;
  }

  if (length % 2 != 0) {
    ERROR_TRACE("Input string must be an even number of hex characters.\n");
    return -1;
  }

  int byte_array_index = 0;
  for (i = 0; i < length; i += 2) {
    unsigned char a = convert_hex_char_to_byte((unsigned char)input_string[i]);
    unsigned char b = convert_hex_char_to_byte((unsigned char)input_string[i + 1]);
    if (a != 0xFF && b != 0xFF) {
      return_data[byte_array_index] = (a << 4) | b;
      byte_array_index++;
    } else {
      ERROR_TRACE("Invalid hex character '%C' for input string\n",
                  (a == 0xFF
                       ? input_string[i]
                       : input_string[i + 1]));
      return -1;
    }
  }
  return length / 2;
}

#define EUI64_LEN      MAX_EUI64_LEN
#define LINK_KEY_SIZE  sMAX_LINK_KEY_SIZE
#define INSTALL_CODE_SIZE_0    0
#define INSTALL_CODE_SIZE_6    6
#define INSTALL_CODE_SIZE_8    8
#define INSTALL_CODE_SIZE_12   12
#define INSTALL_CODE_SIZE_MAX  16
#define INSTALL_CODE_CRC_SIZE  2
#define INSTALL_CODE_STRING_SIZE_MAX  (2*INSTALL_CODE_SIZE_MAX+1)
#define EUI64_STRING_SIZE             (2*EUI64_LEN+1)
static int16_t open_network_interface(uint16_t install_code_len, uint8_t *install_code, Eui64_t *eui64)
{
  OpenJoin_t *data = NULL;

  data = malloc(sizeof(OpenJoin_t));
  if (data == NULL) {
    ERROR_TRACE("malloc failed.");
    return -1;
  }
  memset(data, 0, sizeof(OpenJoin_t));

  if (!(install_code_len == INSTALL_CODE_SIZE_0 || install_code_len == INSTALL_CODE_SIZE_6 || install_code_len == INSTALL_CODE_SIZE_8 || install_code_len == INSTALL_CODE_SIZE_12 || install_code_len == INSTALL_CODE_SIZE_MAX)) {
    free(data);
    ERROR_TRACE("Install code must be 0, 6, 8, 12, or 16 bytes in length.\n");
    return -1;
  }

  if (install_code_len == 0) {
    data->joinType = DEFAULT_LINK_KEY_ONLY;
    DEBUG_TRACE("\n\rjoin type: default_link_key_only");
  } else {
    PTR_NULL_CHK(install_code);
    data->joinType = USER_DEFINED_LINK_KEY_ONLY;
    memcpy(&data->userLinkKey.eui64, eui64, EUI64_LEN);
    installCodeToLinkKey(install_code_len, install_code, data->userLinkKey.linkKey);
    DEBUG_TRACE("\n\rjoin type: user_defined_link_key_only");
  }

  data->discEnabled = 1;
  if (-1 == sendMsg((void *)data, OPEN_JOIN)) {
    ERROR_TRACE("sendMsg failed.");
    free((void *)data);
    return -1;
  }
  return 0;
}

void cloud_permit_join_set_ctx(uint16_t value);
void open_network(char * eui, char * ic)
{
  int     install_code_len, eui64_len, code_str_len, eui64_str_len;
  uint8_t install_code_string[INSTALL_CODE_STRING_SIZE_MAX];
  uint8_t eui64_string[EUI64_STRING_SIZE];
  uint8_t install_code[INSTALL_CODE_SIZE_MAX];
  Eui64_t eui64;

  if (ic != NULL) {
    code_str_len = strlen(ic);
    eui64_str_len = strlen(eui);

    memset(install_code_string, 0, INSTALL_CODE_STRING_SIZE_MAX);
    memcpy(install_code_string, ic, code_str_len);
    install_code_len = parse_hex_byte_string((char *)install_code_string, (char *)(install_code), INSTALL_CODE_SIZE_MAX);

    if (install_code_len == -1) {
      ERROR_TRACE("Install code parse error.");
      return;
    }

    memset(eui64_string, 0, EUI64_STRING_SIZE);
    memcpy(eui64_string, eui, eui64_str_len);
    eui64_len = parse_hex_byte_string((char *)eui64_string, (char *)(eui64.uuid), EUI64_LEN);
    if (eui64_len != EUI64_LEN) {
      ERROR_TRACE("eui64 parsing error.");
      return;
    }
  } else {
    install_code_len = 0;
  }
  open_network_interface(install_code_len, install_code, &eui64);
  #if CLOUD_GATEWAY_ENABLE
  cloud_permit_join_set_ctx(1);
  #endif //CLOUD_GATEWAY_ENABLE
}

void close_network(void)
{
  sendMsg(NULL, CLOSE_JOIN);
  #if CLOUD_GATEWAY_ENABLE
  cloud_permit_join_set_ctx(0);
  #endif //CLOUD_GATEWAY_ENABLE
}

static void set_assn(uint16_t clusterId, uint8_t deviceIndex, bool setClr)
{
  SetAssn_t * data;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  data = malloc(sizeof(SetAssn_t));
  memcpy(data->remoteEui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  memcpy(data->destEui64.uuid, ncpEui.uuid, 8);
  data->clusterId = clusterId;
  data->srcEndpoint = deviceInfoTable[deviceIndex].endpoint;
  data->destEndpoint = 1;
  if (setClr) {
    sendMsg((void *)data, SET_ASSN);
  } else {
    sendMsg((void *)data, CLR_ASSN);
  }
}

#if CLOUD_GATEWAY_ENABLE
extern void cloud_permit_join_set_ctx(uint16_t value); // used by cloud gateway
#endif //CLOUD_GATEWAY_ENABLE

static void zcl_send(ZclPacket_t * packet,
                     uint8_t deviceIndex,
                     uint16_t addr,
                     SendType_t type)
{
  ZclSend_t * data;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  data = malloc(sizeof(ZclSend_t));
  memcpy(data->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  memcpy(&(data->packet), packet, sizeof(ZclPacket_t));
  data->sendType = type;
  data->destination = addr;
  sendMsg((void *)data, ZCL_SEND);
}

static void cmd_ctl(uint16_t clusterId,
                    uint8_t cmdId,
                    SendType_t type,
                    uint8_t deviceIndex,
                    uint16_t addr,
                    uint8_t * data,
                    uint8_t len)
{
  CmdCtrl_t * ctrl;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  ctrl = malloc(sizeof(CmdCtrl_t));
  ctrl->sendType = type;
  memcpy(ctrl->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  ctrl->endpoint = deviceInfoTable[deviceIndex].endpoint;
  ctrl->clusterId = clusterId;
  ctrl->cmdId = cmdId;
  ctrl->destination = addr;
  if ((data) && (len > 0)) {
    memcpy(ctrl->data, data, len);
    ctrl->dataLen = len;
  } 
  sendMsg((void *)ctrl, CMD_CTRL);
}

static void get_network(void)
{
  sendMsg(NULL, GET_NWK);
}

static void send_report(uint16_t clusterId,
                        uint8_t deviceIndex,
                        uint16_t attributeId,
                        uint16_t manuId,
                        uint8_t type)
{
  SetReport_t * data;

  data = malloc(sizeof(SetReport_t));
  data->clusterInfo.clusterId = clusterId;
  data->clusterInfo.clusterType = SERVER;
  data->endpoint = deviceInfoTable[deviceIndex].endpoint;
  memcpy(data->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  data->setAttrReport.attributeId = attributeId;
  data->setAttrReport.manufacturerId = manuId;
  data->setAttrReport.dataType = type;
  data->setAttrReport.maxReportTime = DEFAULT_MAX_REPORTING_TIME;
  data->setAttrReport.minReportTime = DEFAULT_MIN_REPORTING_TIME;
  data->setAttrReport.reportableChange[0] = 0x01;
  sendMsg((void *)data, SET_REPORT);

}

static void read_attr(uint16_t clusterId,
                        uint8_t deviceIndex,
                        uint16_t attributeId,
                        uint16_t manuId)
{
  AttrRead_t * read;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  read = malloc(sizeof(AttrRead_t));
  memcpy(read->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  read->endpoint = deviceInfoTable[deviceIndex].endpoint;
  read->attrId = attributeId;
  read->clusterInfo.clusterId = clusterId;
  read->clusterInfo.clusterType = SERVER;
  read->clusterInfo.manufacturerId = manuId;
  sendMsg((void *)read, ATTR_READ);
}

static void write_attr(uint16_t clusterId,
                      uint8_t deviceIndex,
                        uint16_t attributeId,
                        uint16_t manuId,
                        uint8_t type,
                        uint8_t * data,
                        uint8_t len)
{
  AttrWrite_t * write;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  write = malloc(sizeof(AttrWrite_t));
  memcpy(write->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  write->endpoint = deviceInfoTable[deviceIndex].endpoint;
  write->attrId = attributeId;
  write->attrType = type;
  write->clusterInfo.clusterId = clusterId;
  write->clusterInfo.clusterType = SERVER;
  write->clusterInfo.manufacturerId = manuId;
  memcpy(write->data, data, len);
  write->dataLen = len;
  sendMsg((void *)write, ATTR_WRITE);
}

static void ota_notify(uint8_t deviceIndex, uint16_t manuId, uint16_t imageId, uint32_t ver)
{
  OtaNotify_t * notify;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  notify = malloc(sizeof(OtaNotify_t));
  memcpy(notify->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  notify->firmwareVersion = ver;
  notify->imageTypeId = imageId;
  notify->manufacturerId = manuId;
  sendMsg((void *)notify, OTA_IMAGE_NOTIFY);
}

static void del_table(uint8_t deviceIndex)
{
  DevTableDel_t * data;

  if (deviceIndex >= MAX_DEVICE) {
    printf("wrong device index:%d\r\n", deviceIndex);
    return;
  }
  data = malloc(sizeof(DevTableDel_t));
  memcpy(data->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  sendMsg((void *)data, DEV_TABLE_DEL);
}

static void dev_leave(uint8_t deviceIndex, uint8_t allowRejoin)
{
  DevLeaveNwk_t * devLeave;

  devLeave = malloc(sizeof(DevLeaveNwk_t));
  memcpy(devLeave->eui64.uuid, deviceInfoTable[deviceIndex].eui64.uuid, 8);
  devLeave->allowRejoin = allowRejoin;
  sendMsg((void *)devLeave, DEV_LEAVE_NWK);
}

static void send_ncpupdate(uint32_t fileSize)//test
{
  NcpUpdateFile_t * file;

  file = malloc(sizeof(NcpUpdateFile_t));
  file->fileSize = fileSize;
  sendMsg((void *)file, NCP_UPDATE);
}

void printEui(Eui64_t * eui)
{
  printf("[");
  for (int i = 0; i < 8; i ++) {
    printf("%2X", eui->uuid[i]);
  }
  printf("]\r\n");
}

void printNwkSettings(NwkSettings_t* data)
{
  printf("ncp: ");
  memcpy(ncpEui.uuid, &(data->ncpEui64), 8);
  printEui(&ncpEui);
  printf("panId: %4X\r\n", data->panId);
  printf("channel: %d\r\n", data->channel);
  printf("power: %d\r\n", data->power);
  printf("stack ver: %s\r\n", data->ncpStackVersion);
}

void printNwkStatus(NwkStatus_t * data)
{
  if (data->status == NO_NWK) {
    printf("status: %s\r\n", "NO NWK");
  } else if (data->status == NWK_DOWN) {
    printf("status: %s\r\n", "NWK _DOWN");
  } else if ((data->status == NWK_UP)) {
    printf("status: %s\r\n", "NWK _UP");
  }
}

static void printDevStatus(DevStatusChanged_t* data)
{
  printEui(&(data->eui64));
  printf("  new status: %s\r\n", deviecStatusText[data->devState]);
}

uint8_t isEntryEmpty(DevInfo_t * entry)
{
  uint8_t * data = (uint8_t *) entry;
  int j = 0;
  while (j < sizeof(DevInfo_t)) {
    if (*data != 0) {
      return 0;
    }
    j++;
    data++;
  }
  return 1;
}

uint8_t findEmptyIndex(void)
{
  for (int i = 0; i < MAX_DEVICE; i++) {
    if (isEntryEmpty(&deviceInfoTable[i])) {
      return i;
    }
  }
  return 0xFF;
}

void printDevJoined(DevJoined_t * data)
{
  uint8_t index;

  printEui(&(data->eui64));

  for (int j = 0; j < data->endpointNum; j++) {
    index = findEmptyIndex();
    if (index == 0xFF) {
      printf("table full!\r\n");
      return;
    }
    memcpy(&(deviceInfoTable[index].eui64), &(data->eui64), sizeof(Eui64_t));
    printf("ep: %d\r\n", data->endPoints[j].endpoint);
    deviceInfoTable[index].endpoint = data->endPoints[j].endpoint;
    printf("   deviceId: %d\r\n", data->endPoints[j].devType);
    for (int i = 0; i < data->endPoints[j].clusterNum; i++) {
      printf("   cluster: %d, ", data->endPoints[j].clusters[i].clusterId);
      printf("%s\r\n",
             data->endPoints[j].clusters[i].clusterType == CLIENT ? "CLIENT" : "SERVER");
    }
  }
}

uint8_t findIndexByEui(Eui64_t * pEui)
{
  for (int i = 0; i < MAX_DEVICE; i++) {
    if (strncmp(pEui->uuid, deviceInfoTable[i].eui64.uuid, MAX_EUI64_LEN) == 0) {
      return i;
    }
  }
  return 0xFF;
}

uint8_t findIndexByEuiAndEp(Eui64_t * pEui, uint8_t ep)
{
  for (int i = 0; i < MAX_DEVICE; i++) {
    if ((strncmp(pEui->uuid, deviceInfoTable[i].eui64.uuid, MAX_EUI64_LEN) == 0)
        && (deviceInfoTable[i].endpoint == ep)) {
      return i;
    }
  }
  return 0xFF;
}

void removeDevice(DevLeft_t * data)
{
  uint8_t index;

  printf("removing device:");
  printEui(&(data->eui64));
  while ((index = findIndexByEui(&(data->eui64))) != 0xFF) {
    memset(&deviceInfoTable[index], 0, sizeof(DevInfo_t));
  }
}

void addDeviceTable(DevInfo_t * data)
{
  uint8_t index;

  printEui(&(data->eui64));
  printf("ep:%d\r\n", data->endpoint);
  if (findIndexByEuiAndEp(&(data->eui64), data->endpoint) != 0xFF) {
    printf("device already existed\r\n");
  } else {
    index = findEmptyIndex();
    memcpy(&deviceInfoTable[index], data, sizeof(DevInfo_t));
  }
}

void printDeviceTable(void)
{
  for (int i = 0; i < MAX_DEVICE; i++) {
    if (isEntryEmpty(&deviceInfoTable[i])) {
      continue;
    }
    printf("index %d, ep:%d, ", i, deviceInfoTable[i].endpoint);
    printEui(&(deviceInfoTable[i].eui64));
  }
}

static void printAttrMsg(AttrMsg_t * dataPtr)
{
  printf("AttrMsg:\r\n");
  printEui(&(dataPtr->eui64));
  if (dataPtr->manufacturerId != NULL_MANUFACTURER_CODE) {
    printf("   manuId: 0x%4X\r\n", dataPtr->manufacturerId);
  }
  printf("   attrType: 0x%2X\r\n", dataPtr->attrType);
  printf("   cluster id: 0x%4x:\r\n", dataPtr->clusterId);
  printf("   attr id: 0x%4x\r\n", dataPtr->attrId);
  printf("   endpoint: %d\r\n", dataPtr->endpoint);
  printf("   data: [");
  for (int i = 0; i < dataPtr->dataLen; i++) {
    printf("%2X ", dataPtr->data[i]);
  }
  printf("]\r\n");
}

static void printCmdMsg(CmdRecv_t * dataPtr)
{
  printf("CmdMsg:\r\n");
  printEui(&(dataPtr->eui64));
  if (dataPtr->manufacturerId != NULL_MANUFACTURER_CODE) {
    printf("   manuId: 0x%4X\r\n", dataPtr->manufacturerId);
  }
  printf("   cluster id: 0x%4x:\r\n", dataPtr->clusterId);
  printf("   endpoint: %d\r\n", dataPtr->endpoint);
  printf("   cmd id: 0x%4x\r\n", dataPtr->cmdId);
  printf("   data: [");
  for (int i = 0; i < dataPtr->dataLen; i++) {
    printf("%2X ", dataPtr->data[i]);
  }
  printf("]\r\n");
}

static void printZclMsg(ZclMsg_t * dataPtr)
{
  printf("ZclMsg:\r\n");
  printEui(&(dataPtr->eui64));
  printf("   cluster id: 0x%4x:\r\n", dataPtr->packet.clusterId);
  printf("   endpoint: %d\r\n", dataPtr->packet.endpoint);
  printf("   frame: [");
  for (int i = 0; i < dataPtr->packet.len; i++) {
    printf("%2X ", dataPtr->packet.frame[i]);
  }
  printf("]\r\n");
}

static void printSetAssnRsp(SetAssnRsp_t * dataPtr)
{
  printf("SetAssnRsp:\r\n");
  printEui(&(dataPtr->eui64));
  printf("   cluster id: 0x%4x:\r\n", dataPtr->clusterId);
  printf("   endpoint: %d\r\n", dataPtr->endpoint);
  printf("   status :%d\r\n", dataPtr->status);
}

static void printNcpRsp(NcpUpdateRsp_t * dataPtr)
{
  printf("NcpUpdateRsp: ");
  printf("%s\r\n", (dataPtr->status == 0) ? "success" : "failed");
}

static void printNcpStatus(NcpResetStatus_t * dataPtr)
{
  printf("NcpStatus: ");
  printf("%s\r\n", (dataPtr->status == 0) ? "success" : "failed");
}
static void printSetReportRsp(SetAssnRsp_t * dataPtr)
{
  printf("SetAssnRsp:\r\n");
  printEui(&(dataPtr->eui64));
  printf("   cluster id: 0x%4x:\r\n", dataPtr->clusterId);
  printf("   endpoint: %d\r\n", dataPtr->endpoint);
  printf("   status :%d\r\n", dataPtr->status);
}

static void printIasZoneDisc(IasZoneDisc_t * dataPtr)
{
  printf("IasZoneDics:\r\n");
  printEui(&(dataPtr->eui64));
  printf((dataPtr->zoneState == 1) ? "   enrolled\r\n" : "   not enrolled\r\n");
  if (dataPtr->zoneState == 1) {
    printf("   ep: %d\r\n",dataPtr->endpoint);
    printf("   zone id: 0x%2X\r\n",dataPtr->zoneId);
    printf("   zone type: 0x%2X\r\n",dataPtr->zoneType);
  }
}

static void printOtaStatus(OtaStatus_t * data)
{
  static const char * str[] = {"finished", "in progress", "failed"};

  printf("=====OTA STATUS REPORT=====\r\n");
  printEui(&(data->eui64));
  printf("  bytes sent: %d\r\n", data->bytesSent);
  printf("  imageId: 0x%4X\r\n", data->imageTypeId);
  printf("  version: 0x%8X\r\n", data->firmwareVer);
  printf("  manuId: 0x%4X\r\n", data->manufacturerId);
  printf("  Status: %s\r\n", str[data->status]);
  printf("===========================\r\n");
}

void getMsg(BottomUpMsg_t *upMsg)
{
  switch (upMsg->id) {
    case NWK_SETTINGS:
      printf("got up msg NWK_SETTINGS\r\n");
      printNwkSettings((NwkSettings_t*)(upMsg->data));
      break;
    case NWK_STATUS:
      printf("got up msg NWK_STATUS\r\n");
      printNwkStatus((NwkStatus_t*)(upMsg->data));
      break;
    case DEV_JOINED:
      printf("got up msg DEV_JOINED\r\n");
      printDevJoined((DevJoined_t*)(upMsg->data));
      break;
    case DEV_LEFT:
      printf("got up msg DEV_LEFT\r\n");
      removeDevice((DevLeft_t*)(upMsg->data));
      break;
    case DEV_STATUS_CHANGED:
      printf("got up msg DEV_STATUS_CHANGED\r\n");
      printDevStatus((DevStatusChanged_t*)(upMsg->data));
      break;
    case DEV_INFO:
      printf("got up msg DEV_INFO\r\n");
      addDeviceTable((DevInfo_t *)(upMsg->data));
      break;
    case ATTR_MSG:
      printf("got up msg ATTR_MSG\r\n");
      printAttrMsg((AttrMsg_t *)(upMsg->data));
      break;
    case ZCL_MSG:
      printf("got up msg ZCL MSG\r\n");
      printZclMsg((ZclMsg_t *)(upMsg->data));
      break;
    case CMD_RECV:
      printf("got up msg CMD RECV\r\n");
      printCmdMsg((CmdRecv_t *)(upMsg->data));
      break;
    case SET_ASSN_RSP:
      printf("got up msg SET ASSN RSP\r\n");
      printSetAssnRsp((SetAssnRsp_t *)(upMsg->data));
    break;
    case SET_REPORT_RSP:
      printf("got up msg SET REPORT RSP\r\n");
      printSetReportRsp((SetReportRsp_t *)(upMsg->data));
    break;
    case IAS_ZONE_DISC:
      printf("got up msg IAS ZONE DISC\r\n");
      printIasZoneDisc((IasZoneDisc_t *)(upMsg->data));
    break;
    case OTA_STATUS:
      printf("got up msg OTA STATUS\r\n");
      printOtaStatus((OtaStatus_t *)(upMsg->data));
    break;
    case NCP_UPDATE_RSP:
      printf("got up msg NCP UPDATE RSP\r\n");
      printNcpRsp((NcpUpdateRsp_t *)(upMsg->data));
    break;
    case NCP_RESET_STATUS:
      printf("got up msg NCP STATUS\r\n");
      printNcpStatus((NcpResetStatus_t *)(upMsg->data));
    default:
      break;
  }
  if (upMsg->data) {
    free(upMsg->data);
  }
}

void z3test(char *buf)
{
  uint8_t deviceIndex = 0;
  uint8_t endpoint;
  uint16_t clusterId;
  char *cmdToken = NULL;
  uint16_t index;

  if (!(cmdToken = strtok(buf, " \r\n"))) {
    printCmdStr();
    return;
  }

  for (index = 0; index < CMD_TABLE_SIZE; index++) {
    if (strncmp(z2Cmd[index].cmdStr, cmdToken, strlen(z2Cmd[index].cmdStr)) == 0) {
      break;
    }
  }
  if (index == CMD_TABLE_SIZE) {
    printCmdStr();
    return;
  }
  switch (z2Cmd[index].cmdIndex) {
    case 0://print table
      printDeviceTable();
      break;
    case 1://CREATE_NWK
      create_network();
      break;
    case 2://LEAVE_NWK
      leave_network();
      break;
    case 3://OPEN_JOIN
    {
      char * eui, * ic, * token;

      if (!(token = strtok(NULL, " \r\n"))) {
        open_network(NULL, NULL);
        break;;
      }  else {
        eui = token;
      }
      if (!(token = strtok(NULL, " \r\n"))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      ic = token;
      open_network(eui, ic);
      break;
    }
    case 4://CLOSE_JOIN
      close_network();
      break;
    case 5://CMD_CTRL
      {
        uint8_t cmdId = 0;
        uint8_t dataLen = 0;
        uint8_t data[255] = {0};
        char * token, type;
        uint16_t addr = 0;
        SendType_t ctrlType = UNICAST;

        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "%c", &type);
        if (type == 'u') {
          if (!(token = strtok(NULL, " \r\n"))) {
            printf("%s", z2Cmd[index].usage);
            return;
          }
          ctrlType = UNICAST;
          sscanf(token, "%hhu", &deviceIndex);
        } else if (type == 'm') {
          if (!(token = strtok(NULL, " \r\n"))) {
            printf("%s", z2Cmd[index].usage);
            return;
          }
          ctrlType = MULTICAST;
          sscanf(token, "0x%4hX", &addr);
        } else if (type == 'b') {
          if (!(token = strtok(NULL, " \r\n"))) {
            printf("%s", z2Cmd[index].usage);
            return;
          }
          ctrlType = BROADCAST;
          sscanf(token, "0x%4hX", &addr);
        } else {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "0x%4hu", &clusterId);
        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "0x%2hhu", &cmdId);
        if ((token = strtok(NULL, " "))) {
          if (sscanf(token, "%hhu", &dataLen) == 1) {
            for (int i = 0; i < dataLen; i++) {
              if (!(token = strtok(NULL, " "))) {
                printf("wrong data length!\r\n");
                return;
              }
              sscanf(token, "0x%2hhX", &data[i]);
            }
            cmd_ctl(clusterId, cmdId, ctrlType, deviceIndex, addr, data, dataLen);
          } else {
            printf("wrong data length!\r\n");
          }
        } else {
          cmd_ctl(clusterId, cmdId, ctrlType, deviceIndex, addr, NULL, 0);
        }
        break;
      }
      break;
    case 6://ZCL_SEND
    {
      ZclPacket_t packet;
      uint8_t len;
      char * token, type;
      SendType_t ctrlType;
      uint16_t addr = 0;

      if (!(token = strtok(NULL, " \r\n"))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%c", &type);
      if (type == 'u') {
        ctrlType = UNICAST;
        if (!(token = strtok(NULL, " \r\n"))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "%hhu", &deviceIndex);
        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "%hhu", &endpoint);
      } else if (type == 'm') {
        ctrlType = MULTICAST;
        if (!(token = strtok(NULL, " \r\n"))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "0x%4hX", &addr);
      } else if (type == 'b') {
        ctrlType = BROADCAST;
        if (!(token = strtok(NULL, " \r\n"))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "0x%4hX", &addr);
      } else {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &clusterId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      if (sscanf(token, "%hhu", &len) == 1) {
        for (int i = 0; i < len; i++) {
          if (!(token = strtok(NULL, " "))) {
            printf("wrong data length!\r\n");
            return;
          }
          sscanf(token, "0x%2hhX", &packet.frame[i]);
        }
        packet.clusterId = clusterId;
        packet.endpoint = endpoint;
        packet.len = len;
        zcl_send(&packet, deviceIndex, addr, ctrlType);
      }
      break;
    }
    case 7://DEV_TABLE_DEL
    {
      char * token;

      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &deviceIndex);
      del_table(deviceIndex);
    }
      break;
    case 8://SET_ASSN
      {
        char * token;

        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "%hhu", &deviceIndex);
        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "0x%4hX", &clusterId);
        set_assn(clusterId, deviceIndex, 1);
        break;
      }
      break;
    case 9://CLR_ASSN
      {
        char * token;

        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "%hhu", &deviceIndex);
        if (!(token = strtok(NULL, " "))) {
          printf("%s", z2Cmd[index].usage);
          return;
        }
        sscanf(token, "0x%4hX", &clusterId);
        set_assn(clusterId, deviceIndex, 0);
        break;
      }
      break;
    case 10://GET_NWK
      get_network();
      break;
    case 11://SET_REPORT
    {
      uint16_t attributeId;
      uint16_t manuId;
      uint8_t type;
      char * token;
    //  ZCL_BOOLEAN_ATTRIBUTE_TYPE                        = 0x10, // Boolean
    //  ZCL_BITMAP8_ATTRIBUTE_TYPE                        = 0x18, // 8-bit bitmap
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &deviceIndex);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%2hhX", &type);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &clusterId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &attributeId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &manuId);
      send_report(clusterId, deviceIndex, attributeId, manuId, type);
    }
      break;
    case 12: //ATTR_READ
    {
      uint16_t attributeId;
      uint16_t manuId;
      char * token;

      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &deviceIndex);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &clusterId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &attributeId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &manuId);
      read_attr(clusterId, deviceIndex, attributeId, manuId);
      break;
    }
    case 13: //ATTR_WRITE
    {
      uint16_t attributeId;
      uint16_t manuId;
      uint8_t type, len;
      uint8_t data[256] = {0};
      char * token;

      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &deviceIndex);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%2hhX", &type);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &clusterId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &attributeId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &manuId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &len);
      for (int i = 0; i < len; i++) {
        if (!(token = strtok(NULL, " "))) {
          printf("wrong data length!\r\n");
          return;
        }
        sscanf(token, "0x%2hhX", &data[i]);
      }
      write_attr(clusterId, deviceIndex, attributeId, manuId, type, data, len);
      break;
    }
    case 14: //OTA_FILE_RELOAD
      sendMsg(NULL, OTA_FILE_RELOAD);
      break;
    case 15: //OTA_IMAGE_NOTIFY
    {
      uint16_t imageId;
      uint16_t manuId;
      uint32_t ver;
      char * token;
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &deviceIndex);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &manuId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%4hX", &imageId);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "0x%8X", &ver);
      ota_notify(deviceIndex, manuId, imageId, ver);
      break;
    }
    case 16: //DEV_LEAVE_NWK
    {
      uint8_t allowRejoin;
      char * token;
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &deviceIndex);
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%hhu", &allowRejoin);
      dev_leave(deviceIndex, allowRejoin);
      break;
    }
    case 17: //NCP_UPDATE
    {
      uint32_t size = 0;
      char * token;
      if (!(token = strtok(NULL, " "))) {
        printf("%s", z2Cmd[index].usage);
        return;
      }
      sscanf(token, "%u", &size);
      send_ncpupdate(size);
      break;
    }
    default:
      printCmdStr();
      break;
  }
}

int z3_cli_handler (char * buf)
{
  int len = strlen(buf + 3);

  if (strncmp(buf, "z3 ", 3) == 0) {
    strncpy(buf, buf+3, len);
    buf[len] = '\n';
    buf[len + 1] = 0;
    emberSerialAmebaWrite(buf);
    return 0;
  } else if (strncmp(buf, "z2 ", 3) == 0){
    strncpy(buf, buf+3, len);
    buf[len] = '\n';
    buf[len + 1] = 0;
    z3test(buf);
    return 0;
  } else {
    return -1;
  }
}
#endif //LOGSEV_ZIGBEE_CLI_CMD

void log_service(void *param)
{
	/* To avoid gcc warnings */
	( void ) param;
	
#if defined(configENABLE_TRUSTZONE) && (configENABLE_TRUSTZONE == 1)
	rtw_create_secure_context(configMINIMAL_SECURE_STACK_SIZE);
#endif
	_AT_DBG_MSG(AT_FLAG_COMMON, AT_DBG_INFO, "\n\rStart LOG SERVICE MODE\n\r");
	_AT_DBG_MSG(AT_FLAG_COMMON, AT_DBG_INFO, "\n\r# ");        
	while(1){
#if LOGSEV_PROCESS_UP_MSG && LOGSEV_ZIGBEE_CLI_CMD
		while(xSemaphoreTake(log_rx_interrupt_sema, 50) != pdTRUE) {
            MsgObj *recvObj;
            BottomUpMsg_t upMsg;
            recvObj = findMsgByName(GW_UP_QUEUE_NAME);
            if (!recvObj) {
              continue;
            } 
            while (recvObj->recv(recvObj, &upMsg, 0) == true) {
                getMsg(&upMsg);
            }
        }
#else
		while(xSemaphoreTake(log_rx_interrupt_sema, portMAX_DELAY) != pdTRUE);
#endif //LOGSEV_PROCESS_UP_MSG && LOGSEV_ZIGBEE_CLI_CMD

#if CONFIG_LOG_SERVICE_LOCK
		log_service_lock();
#endif
		if(log_handler((char *)log_buf) == NULL){
#if CONFIG_WLAN
			if(mp_commnad_handler((char *)log_buf) < 0)
#endif                        
		{
		#if LOGSEV_ZIGBEE_CLI_CMD
			if (z3_cli_handler((char *)log_buf) < 0) {
			#if SUPPORT_INTERACTIVE_MODE
				print_help_handler((char *)log_buf);
				legency_interactive_handler(NULL, NULL);
			#else
				if(print_help_handler((char *)log_buf) < 0){
					at_printf("\r\nunknown command '%s'", log_buf);
				}
			#endif
			}
		#else
		#if SUPPORT_INTERACTIVE_MODE
			print_help_handler((char *)log_buf);
			legency_interactive_handler(NULL, NULL);
		#else
			if(print_help_handler((char *)log_buf) < 0){
				at_printf("\r\nunknown command '%s'", log_buf);
			}
		#endif
		#endif //LOGSEV_ZIGBEE_CLI_CMD
		}
	}
	log_buf[0] = '\0';
#if CONFIG_INIC_EN
		inic_cmd_ioctl = 0;
#endif
		_AT_DBG_MSG(AT_FLAG_COMMON, AT_DBG_ALWAYS, "\n\r[MEM] After do cmd, available heap %d\n\r", xPortGetFreeHeapSize());
		_AT_DBG_MSG(AT_FLAG_COMMON, AT_DBG_ALWAYS, "\r\n\n#\r\n"); //"#" is needed for mp tool
#if (defined(CONFIG_EXAMPLE_UART_ATCMD) && CONFIG_EXAMPLE_UART_ATCMD)
		if(atcmd_lwip_is_tt_mode())
			at_printf(STR_END_OF_ATDATA_RET);
		else
			at_printf(STR_END_OF_ATCMD_RET);
#endif
#if CONFIG_LOG_SERVICE_LOCK
		log_service_unlock();
#endif
#if defined(configUSE_WAKELOCK_PMU) && (configUSE_WAKELOCK_PMU == 1)
		pmu_release_wakelock(PMU_LOGUART_DEVICE);
#endif
	}
}

#define STACKSIZE               1280
void start_log_service(void)
{
	xTaskHandle CreatedTask;
	int result;

#if defined(CONFIG_USE_TCM_HEAP) && CONFIG_USE_TCM_HEAP
	/*********************************************************************
	 *                                                                                                                         
	 * ATCMD V2 supports commands for SSL                                                                                     
	 * It will cause problems while doing SSL operations if the stack is placed in TCM region   
	 *
	 *********************************************************************/
	void *stack_addr = NULL;
#if (ATCMD_VER == ATVER_1) || ((ATCMD_VER == ATVER_2)&&(ATCMD_SUPPORT_SSL == 0))
	extern void *tcm_heap_malloc(int size);
	stack_addr = tcm_heap_malloc(STACKSIZE * sizeof(int));

	if(stack_addr == NULL){
	}
#endif

	result = xTaskGenericCreate(
			log_service,
			( signed portCHAR * ) "log_service",
			STACKSIZE,
			NULL,
			tskIDLE_PRIORITY + 5,
			&CreatedTask,
			stack_addr,
			NULL);
#else		
	result = xTaskCreate( log_service, ( const portCHAR * ) "log_service", STACKSIZE, NULL, tskIDLE_PRIORITY + 5, &CreatedTask );
#endif
   
	if(result != pdPASS) {
		printf("\n\r%s xTaskCreate failed", __FUNCTION__);
	}

}

void fAT_exit(void *arg){
	/* To avoid gcc warnings */
	( void ) arg;
	
	printf("\n\rLeave LOG SERVICE");
	vTaskDelete(NULL);
}
#if CONFIG_LOG_HISTORY
void fAT_log(void *arg){
        int i = 0;
        printf("[AT]log history:\n\n\r");
        if(log_history_count > LOG_HISTORY_LEN){
          for(i=0; i<4; i++)
            printf("  %s\n\r", log_history[((log_history_count+i)%LOG_HISTORY_LEN)]);
        }
        else{
          for(i=0; i<(log_history_count-1); i++)
            printf("  %s\n\r", log_history[i]);
        }
}
#endif
log_item_t at_log_items[ ] = {
      {"AT--", fAT_exit,{NULL, NULL}},
#if CONFIG_LOG_HISTORY
      {"AT??", fAT_log,{NULL,NULL}},
#endif
      {"ATxx", fAT_exit,{NULL, NULL}}    
};
void at_log_init(void)
{
	log_service_add_table(at_log_items, sizeof(at_log_items)/sizeof(at_log_items[0]));
}
log_module_init(at_log_init);
#endif
